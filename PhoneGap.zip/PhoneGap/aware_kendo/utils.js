/*  Parses XML string and returns XML Document */
function parseXMLDocument (xmlStr)
{
	if (typeof DOMParser != "undefined") 
	{   
         // Mozilla, Firefox, and related browsers   
		return (new DOMParser()).parseFromString(xmlStr, "text/xml");   
    }   
    else if (typeof ActiveXObject != "undefined") 
    {   
         // Internet Explorer.   
         var doc = new ActiveXObject("Microsoft.XMLDOM");  
         doc.loadXML(xmlStr);          // Parse text into it   
         return doc;                   // Return it   
    }   
    else 
    {   
         // As a last resort, try loading the document from a data: URL   
         // This is supposed to work in Safari.
         var url = "data:text/xml;charset=utf-8," + encodeURIComponent(xmlStr);   
         var request = new XMLHttpRequest();   
         request.open("GET", url, false);   
         request.send(null);   
         return request.responseXML;   
     }   
}

/** Return value of the attribute with the specified name. If an attribute is not found and the default value is specified
** returns the default value
*/
function getAttributeValue (node, attrName, defaultValue)
{
	for (var i = 0; i < node.attributes.length; ++i)
	{
		if (node.attributes [i].name == attrName)
		{
			return node.attributes [i].value;
		}
	}	
	
	// attribute not found
	return defaultValue;
}

/** Same as getAttributeValue but converts to integer
*/
function getIntegerValue (node, attrName, defaultValue)
{
	var value = getAttributeValue (node, attrName, null);
	if (value != null)
		return parseInt (value);
	else
		return defaultValue;
}

/** Same as getAttributeValue but converts to boolean
*/
function getBooleanValue (node, attrName, defaultValue)
{
	var value = getAttributeValue (node, attrName, null);
	if (! value)
		return defaultValue;
		
	return value.toLowerCase () == "true";
}

/** Return child nodes of the specified type */
function getFirstLevelChildNodes (parentNode, childType)
{
	if (! parentNode.childNodes)
		return null;
		
	var childNodes = new Array ();
	for (var i = 0; i < parentNode.childNodes.length; ++ i)
	{
		if (parentNode.childNodes [i].nodeName == childType)
			childNodes.push (parentNode.childNodes [i]);
	}
	
	return childNodes;
}

// In some browsers long text is broken into several child nodes. This function gets the value across such nodes
function getTextNodeValue (node)
{
	var result = "";
	for (var i = 0; i < node.childNodes.length; ++ i)
	{
		result += node.childNodes [i].nodeValue;
	}
	
	return result;
}

function arrayIndexOf (array, item)
{
	for (var i = 0; i < array.length; ++ i)
	{
		if (array[i] === item)
			return i;
	}
	
	return -1;
}

function EXT_apply (object, config) 
{
    var property;

    if (object) {
        for (property in config) {
            object[property] = config[property];
        }
    }

    return object;
}

function EXT_applyIf (object, config) 
{
    var property;

    if (object) {
        for (property in config) {
            if (object[property] === undefined) {
                object[property] = config[property];
            }
        }
    }

    return object;
}

function htmlEncode(value)
{
	return value ? $("<textarea/>").text(value).html().replace(/"/g, '&quot;') : "";
}

function htmlDecode(value) 
{
	return value ? $("<textarea/>").html(value).text().replace(/&quot;/g, '"') : "";
}

function getObjectReference (refValue)
{
	var idx = refValue.indexOf (":");
	if (idx <= 0)
		return null;
	
	return { objectName: refValue.substring (0, idx), objectId: refValue.substring (idx + 1) };			
}

//check if there is a column data starting with BAS_OPER_UNAPPLICABLE. If not operation is not defined for this item
//(may not be applicable)
function operationApplicable (record, operName)
{
	var value = record.get ('BAS_OPER_APPLICABILITY');
	return isOperationApplicable (value, operName);
}

function isOperationApplicable (value, operName)
{
	if (! value)
		return true;
		
	// unapplicable operations are separated by @ delimited
   	var unapplicableOpers = value.split ("@");
   	if (! unapplicableOpers)
		return true;
			
	for (var i = 0; i < unapplicableOpers.length; ++ i)
	{
		if (unapplicableOpers [i] == operName)
			return false;
	}
		
	return true;
}

//Return true if the given string is mentioned in the string delimited by @
function containedInDelimitedString (str, delimitedStr)
{
	if (! str || ! delimitedStr)
		return false;
		
   	var s = delimitedStr.split ("@");	
   	if (! s || s.length == 0)
   		return false;
   		   	
	for (var i = 0; i < s.length; ++ i)
	{
		if (s [i] == str)
			return true;
	}
	
	return false;
}

function cloneObj (obj)
{
	var c = {};
	for (var k in obj)
		c[k] = obj[k];
	
	return c;
}

function cloneArray (a)
{
	if (! a)
		return null;
		
	var temp = new Array ();
	var l = a.length;
	for (var i = 0; i < l; ++ i)
		temp.push (cloneObj (a [i]));
		
	return temp;
}

//Convert value of the grid to number
function convertToNumber (value)
{
	if (typeof value == 'number')
		return value;  // already a number
	
	if (! value || value == "")
		return 0;
	
	// a bit of a hack - consider currency formats
	if (value.indexOf ("$") == 0)
		value = value.substring(1);
	
	return value.indexOf (".") >= 0 ? parseFloat (value) : parseInt (value);
}

function getImageSource ()
{
	return "aware_kendo/resources/images/";
}

//build a string that can represent context of queries
//context represents either an array of XML nodes (object references) or an array of selection objects
function buildQueryContextString (context)
{
	var s = "";
	if (context)
	{
		for (var i = 0; i < context.length; ++ i)
		{
			var objectName = null, objectId = null;
			if (context[i].objectName)
			{
				objectName = context[i].objectName;
				objectId   = context[i].objectId;
			}
			else
			{
				objectName = getAttributeValue (context [i], "object_name", null);
				objectId   = getAttributeValue (context [i], "object_id", null);
			}
			
			if (objectName && objectId)
			{
				if (i > 0)
					s += ",";  // delimiter
					
				s += objectName;
				s += ":";
				s += objectId;
			}
		}
	}
	
	return s;
}

function parseWidthHeight (value)
{
	var v = value + "";
	if (v.indexOf ("%") > 0 || v.indexOf ("px") > 0 || v.indexOf ("calc") >= 0)
		return v;
	
	return v + "px";
}

function toKendoDateFormat (format)
{
	return format.replace ("a", "tt");
}

