// This class parses XML document representing the layout of the Calendar/Scheduler
var AwareApp_CalendarParser = AwareApp_BaseParser.extend(
{
	init: function (xmlDoc, inWindow)
	{
		this.m_firstLoad = true;
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);
	},

	// used in preview framework
	reset: function ()
	{
		this.m_tools = null;
		this.m_toolbars = null;
		this.m_panelHeader = null;
		this.m_panelOpers = null;
		this.m_extParams = null;
		
		this.init (this.m_xmlDoc, false);
		
		this.m_multipleResourceFields = null;
		this.m_editAttrs = null;
	},
	
	parse: function ()
	{
		var nodes = this.m_xmlDoc.getElementsByTagName ("calendar_layout");
		if (! nodes || nodes.length != 1)
			return null;
			
		var calNode = nodes [0];
		
		nodes = calNode.getElementsByTagName ("calendar_options");
		if (! nodes || nodes.length != 1)
			return null;
			
		var coNode = nodes [0];
		
		var queryStrNodes = getFirstLevelChildNodes (calNode, "query_string");
		if (! queryStrNodes || queryStrNodes.length != 1)
			return null;
		
		this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		
		this.m_objectRefNodes = calNode.getElementsByTagName ("object_reference");
		
	    this.m_queryName       = getAttributeValue (calNode, "query_name", null);
	   	this.m_queryOnName     = getAttributeValue (calNode, "query_on_name", null);
	   	this.m_isGroupName     = getBooleanValue   (calNode, "is_group_name", false);
	   	this.m_refOwnerName    = getAttributeValue (calNode, "ref_owner_name", null);
	   	this.m_refOwnerId      = getAttributeValue (calNode, "ref_owner_id", null);
	   	this.m_refAttrName     = getAttributeValue (calNode, "ref_attr_name", null);
	   	this.m_formName        = getAttributeValue (calNode, "form_name", null);
	   	this.m_sectionName     = getAttributeValue (calNode, "section_name", null);
		this.m_refreshProcs    = getAttributeValue (calNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (calNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue   (calNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue (calNode, "refresh_impl_proc", null);
	   	this.m_createProcName  = getAttributeValue (coNode, "create_proc", null);
	   	this.m_createProcTarget= getAttributeValue (coNode, "create_proc_target", null);
	   	this.m_editProcName    = getAttributeValue (coNode, "edit_proc", null);
	   	this.m_editProcTarget  = getAttributeValue (coNode, "edit_proc_target", null);
	   	this.m_createNotAllowed= getBooleanValue   (coNode, "create_not_allowed", false);
	   	this.m_editNotAllowed  = getBooleanValue   (coNode, "edit_not_allowed", false);
	   	this.m_deleteNotAllowed= getBooleanValue   (coNode, "delete_not_allowed", false);
		this.m_dateTimeFormat  = getAttributeValue (calNode, "date_time_format", "dd/MM/yyyy HH:mm");	
		this.m_timeFormat      = getAttributeValue (calNode, "time_format", "HH:mm");	
		var mobile             = getBooleanValue   (calNode, "mobile_rendering", false);
		var startWorkTime      = getIntegerValue   (coNode, "start_time", -1);
		var endWorkTime        = getIntegerValue   (coNode, "end_time", -1);
		var workHoursOnly      = getBooleanValue   (coNode, "working_hours_only", false);
		var colWidth           = getIntegerValue   (coNode, "max_column_width", -1);
		var allowMove          = getBooleanValue   (coNode, "allow_move", false);
		var allowResize        = getBooleanValue   (coNode, "allow_resize", false);
		var showToday          = getBooleanValue   (coNode, "show_today", false);
		var vertical           = getBooleanValue   (coNode, "vertical_orientation", false);
		this.m_pagingOnClient  = getBooleanValue   (coNode, "paging_on_client", false);
		var gotoDate           = getAttributeValue (coNode, "go_to_date", null);
		this.m_gotoFirst       = getBooleanValue   (coNode, "go_to_first", false);
		var rowHeight          = getIntegerValue   (coNode, "row_height", -1);
	   	var startDay           = this.getStartDay  (coNode);	
		var width              = getIntegerValue   (calNode, "panel_width",  -1);
		var height             = getAttributeValue (calNode, "panel_height", null);
		
		if (height && height == "Align")
			this.m_alignToBottom = true;
		else
			this.m_panelHeight = height;

	   	if (! this.m_previewMode)
	   		this.m_previewMode = getBooleanValue (calNode, "preview_mode", false);
	   	
	   	this.parseViews (coNode);
		
	   	// This is server's datetime format
		this.m_dateTimeFormat = toKendoDateFormat (this.m_dateTimeFormat);
		
		var resources = this.getResources (coNode);
		
		var rn = calNode.getElementsByTagName ("resizing_options");
		if (rn && rn.length > 0)
			this.m_resizingNode = rn [0];

		var rsn = calNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		
		if (! this.m_refAttrName)
		{
			var tn = getFirstLevelChildNodes (calNode, "tour");
			if (tn && tn.length > 0)
				this.m_tourNode = tn [0];
		}
		
		var dsConfig = this.getDataSourceConfig (calNode, coNode, resources);
		
		this.m_itemOpers = this.getItemOperations (calNode);
		
		this.m_widgetId = "AW_CALENDAR_" + Math.floor (Math.random () * 100001);	
		
		var panelConfig = this.getPanelConfig (calNode, this.m_widgetId, "calendar");
		if (width > 0)
			panelConfig.width = width;
		
		var widgets = new Array ();
		
		if (this.m_itemOpers && this.m_itemOpers.length > 0)
		{
			panelConfig.bodyContent = this.prepareContextMenu (this.m_itemOpers, this.m_widgetId, widgets);
		}
		
		this.m_panel = new AwareApp_Panel (panelConfig);
		
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
		var wc = {
			dataSource: dsConfig,
			mobile: mobile,
			views: [],
			workWeekStart: startDay,
			showWorkHours: workHoursOnly,
			currentTimeMarker: showToday,
			eventTemplate: this.getEventTemplate ()
		};
		if (this.m_panelHeight)
		{
			wc.height = this.m_panelHeight;
		}
		
		if (! this.m_gotoFirst)
		{
			if (gotoDate)
			{
				try
				{
					wc.date = kendo.parseDate (gotoDate, this.m_dateTimeFormat);
				}
				catch (e)
				{}
			}
			if (! wc.date)
			{
				wc.date = new Date ();
			}
		}
		
		this.setupEvents (wc);
		
		if (resources)
		{
			this.setResources (wc, resources, vertical);
		}
		if (startWorkTime > 0)
		{
			var d = new Date ();
			d.setHours (startWorkTime);
			d.setMinutes (0);
			wc.workDayStart = d;
		}
		if (endWorkTime > 0)
		{
			var d = new Date ();
			d.setHours (endWorkTime);
			d.setMinutes (0);
			wc.workDayEnd = d;
		}
		if (rowHeight > 0)
		{
			wc.eventHeight = rowHeight;
		}
		
		if (this.m_editNotAllowed && this.m_createNotAllowed)
		{
			wc.editable = false;
		}
		else
		{
			wc.editable = { 
				update:  ! this.m_editableNotAllowed, 
				destroy: ! this.m_deleteNotAllowed, 
				create:  ! this.m_createNotAllowed,
				move:    allowMove,
				resize:  allowResize
			};
		}
		
		this.setupViews (wc, colWidth);
		
		if (this.m_showSaveSettingsButton)
		{
			this.setState (wc);
		}
		
    	widgets.push ({
    		type:   "scheduler",
    		id:     this.m_widgetId,
    		config: wc
    	});
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
   	
		if (this.m_resizingNode)
		{
			this.addResizeWidgets (this.m_resizingNode, panelMarkup, widgets);
		}
		
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		this.runInitScript (calNode, wc, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;
	},
	
	getWidget: function ()
	{
		return $("#" + this.m_widgetId).data("kendoScheduler");		
	},
	
	setOnlineMode: function (online, deferred)
	{
		this.m_onlineModeDeferred = deferred;
		
		this.getWidget().dataSource.online(online)
	},
	
	parseViews: function (coNode)
	{
		this.m_views = new Array ();
		
		var viewNodes = coNode.getElementsByTagName ("calendar_view");
		if (viewNodes)
		{
			for (var i = 0; i < viewNodes.length; ++ i)
			{
				var node = viewNodes [i];
				var view = {
					type:       getAttributeValue (node, "type", "month"),
					dateFormat: getAttributeValue (node, "date_format", null)
				};
				
				var isDefault = getBooleanValue (node, "is_default", false);
				if (isDefault)
					view.selected = true;
				
				var minorTick = getIntegerValue (node, "minor_tick", -1);
				if (minorTick > 0)
					view.minorTick = minorTick;
				
				var majorTick = getIntegerValue (node, "major_tick", -1);
				if (majorTick > 0)
					view.majorTick = majorTick;
				
				var minorTimeFormat = getAttributeValue (node, "minor_tick_format");
				if (minorTimeFormat)
					view.minorTimeFormat = toKendoDateFormat (minorTimeFormat);
				
				var majorTimeFormat = getAttributeValue (node, "major_tick_format");
				if (majorTimeFormat)
					view.majorTimeFormat = toKendoDateFormat (majorTimeFormat);
				
				this.m_views.push (view);
			}
		}
	},
	
	setupEvents: function (wc)
	{
		var me = this;
		if (this.m_multipeResourceFields)
		{
			wc.dataBinding = function (e)
			{
				me.onDataBinding (this, e);
			}
		}
		if (this.m_gotoFirst)
		{
			wc.dataBound = function (e) 
			{
				me.onDataBound (this, e);
			}
		}

		// key up on moving events brings up the editor - prevent it
		wc.moveStart = function () {
			me.m_inMove = true;
		};
		wc.moveEnd = function () {
			me.m_inMove = false;
		};
		wc.edit = function (e) {
			if (me.m_inMove)
				e.preventDefault ();
		}
	},
	
	getResources: function (coNode)
	{
		var resources = new Array ();
		
		var resNodes = coNode.getElementsByTagName ("resource");
		if (resNodes)
		{
			for (var i = 0; i < resNodes.length; ++ i)
			{
				var refAttrName = getAttributeValue (resNodes[i], "ref_attr_name", null);
				if (refAttrName)
				{
					var r = {
						field:          refAttrName,
						multiple:       getBooleanValue   (resNodes[i], "multiple", false),
						title:          getAttributeValue (resNodes[i], "title", null),
						dataSource:     this.getResourceDataSourceConfig (refAttrName),
						dataTextField:  "BAS_DISPLAYED_FIELD",
						dataValueField: "BAS_REF_VALUE"
					};
					resources.push (r);
					
					if (r.multiple)
					{
						if (! this.m_multipleResourceFields)
							this.m_multipleResourceFields = new Array ();
						
						this.m_multipleResourceFields.push (r.field);
					}
				}
			}
		}
		
		return resources.length > 0 ? resources : null;
	},
	
	setResources: function (wc, resources, vertical)
	{
		wc.resources = resources;
		var resNames = new Array ();
		for (var i = 0; i < resources.length; ++ i)
			resNames.push (resources[i].field);
		
		wc.group = {
			resources:   resNames,
			orientation: (vertical ? "horizontal" : "vertical")  // opposite of the server meaning
		};
	},
	
	getFields: function (coNode, resources)
	{
		var fields = {};
		this.addField ("BAS_REF_VALUE", fields, false);
		this.addField ("BAS_OPER_APPLICABILITY", fields, false);
		this.addField ("bas_style", fields, false);
		this.addField ("bas_titleDecor", fields, false);
		
        fields.title       =         { field: "Subject/text()", defaultValue: "No title", validation: { required: true } };
        fields.start       =         { field: "StartTime/text()", type: "date",  validation: { required: true}};
        fields.end         =         { field: "EndTime/text()", type: "date",  validation: { required: true}};
        fields.description =         { field: "Description/text()" };
        fields.isAllDay    =         { field: "AllDayEvent/text()", type: "boolean" };
        fields.recurrenceId=         { field: "RecID/text()" };
        fields.recurrenceRule =      { field: "RecRule/text()" };
        fields.recurrenceException = { field: "RecExc/text()" };
        
        if (resources)
        {
        	for (var i = 0; i < resources.length; ++ i)
        	{
        		var fieldName = resources[i].field;
        		this.addField (fieldName, fields, true);
        	}
        }
        
        /* custom fields */
        var editAttrNodes = coNode.getElementsByTagName ("edit_attribute");
        if (editAttrNodes)
        {
			this.m_editRecurrence = getBooleanValue (coNode, "edit_recurrence", true);
        	for (var i = 0; i < editAttrNodes.length; ++ i)
        	{
        		var node = editAttrNodes[i];
        		var attrName = getAttributeValue (node, "name", null);
        		if (attrName)
        		{
        			if (! fields[attrName] && 
        				attrName != "Subject" && 
        				attrName != "StartTime" && 
        				attrName != "EndTime" && 
        				attrName != "Description" && 
        				attrName != "AllDayEvent" &&
        				attrName != "RecID" &&
        				attrName != "RecRule" &&
        				attrName != "RecExc")
        			{
        				var required = getBooleanValue   (node, "required", false);
        				var title    = getAttributeValue (node, "title", null);
        				
        				var fc = { field: attrName + "/text()", editable: true, nullable: true };
        				
        				var format = null;
        				var dataType = getAttributeValue (node, "data_type",  null);
        				if (dataType)
        				{
        					if (dataType == "number")
        						fc.type = "number";
        					else if (dataType == "date")
        						fc.type = "date";
        					
        					if (fc.type == "date" || fc.type == "number" || dataType == "datetime")
        					{
        						format = getAttributeValue (node, "format",  null);
        					}
        				}
        				
        				if (required)
        				{
        					fc.validation = { required: true };
        				}
        				
        				fields [attrName] = fc;
        				
        				var selectRefNode = null;
        				var selectRefNodes = node.getElementsByTagName ("select_ref");
        				if (selectRefNodes && selectRefNodes.length > 0)
        				{
        					selectRefNode = selectRefNodes [0];
        				}
        				
            			if (! this.m_editAttrs)
            				this.m_editAttrs = new Array ();
            			
            			var ea = { attrName: attrName, title: title, dataType: dataType, required: required, selectRefNode: selectRefNode };
            			if (format)
            				ea.format = format;
            			
            			var cn = node.getElementsByTagName ("static_choices");
            			if (cn && cn.length > 0)
            			{
            				ea.staticChoicesNode = cn [0];
            			}
            			else
            			{
							var dcn = node.getElementsByTagName ("dynamic_choices");
							if (dcn && dcn.length > 0)
								ea.dynamicChoicesNode = dcn [0];
						}
						
            			this.m_editAttrs.push (ea);          			
        			}
        		}
        	}
        }
        
        return fields;
	},
	
	addField: function (fieldName, fields, editable)
	{
		fields [fieldName] = { field: fieldName + "/text()", editable: editable };
	},
	
	getDataSourceConfig: function (mainNode, coNode, resources)
	{
		var fields = this.getFields (coNode, resources);
		
		if (this.m_previewMode)
		{
			return this.getPreviewStore (mainNode, fields);
		}
		
		var me = this;
		var dsConfig = {
			transport:       this.getTransport (),
            schema:          this.getSchema (fields),
            batch:           true,
            serverPaging:    (this.m_pagingOnClient === true ? false : true),
            sync: function (e)
            {
            	me.recordUpdated ();
            },
            error: function (e)
            {
            	me.handleDataSourceError (e.errors ? e.errors : e.errorThrown);
            },
            parse: function (response)
            {
            	me.preprocessResponse (response);
            	return response;
            }
		};
		
		if (! AwareApp.localStorageDisabled ())
			dsConfig.offlineStorage = this.m_widgetId;
		
		return dsConfig;
	},
	
	getTransport: function ()
	{
		var params = this.getTransportParams ();
		
		var t = AwareApp.createAwareTransport (params);
		if (! this.m_editNotAllowed)
		{
			var uParams = cloneObj (params);
			uParams.actionType = "sync_kendo_data_action";
			uParams.updateType = "update";
			
			if (this.m_queryOnName)
			{
				uParams.query_on_name = this.m_queryOnName;
			}
			t.update = {
				url:     t.read.url,	
				timeout: 3600000,
				data:    uParams
			};
		}

		if (! this.m_deleteNotAllowed)
		{
			var dParams = cloneObj (params);
			dParams.actionType   = "sync_kendo_data_action";
			dParams.updateType   = "delete";
			
			// Remove info about references - we need calendar events themselves to be deleted
			delete dParams.ref_attr_name;
			delete dParams.ref_owner_name;
			delete dParams.ref_owner_id;
			
			t.destroy = {
				url:     t.read.url,	
				timeout: 3600000,
				data:    dParams
			};			
		}
		
		if (! this.m_createNotAllowed)
		{
			var cParams = cloneObj (params);
			cParams.actionType   = "sync_kendo_data_action";
			cParams.updateType   = "create";
			if (this.m_queryOnName)
			{
				cParams.query_on_name = this.m_queryOnName;
			}
			t.create = {
				url:     t.read.url,	
				timeout: 3600000,
				data:    cParams
			};
		}
		
		var me = this;
		t.parameterMap = function (data, type)
		{
			return me.encodeDataSourceData (data, type);
		}
		
		return t;
	},
	
	getTransportParams: function ()
	{
		var params = { 
			actionType:    'run_query_action', 
			query_string:  this.m_queryStr, 
			from_calendar: 'true',
			force_all:     'true'
		};    	
		if (this.m_refAttrName)
		{
			params.ref_attr_name      = this.m_refAttrName;
			params.ref_owner_name     = this.m_refOwnerName;
			params.ref_owner_id       = this.m_refOwnerId;
			params.form_name          = this.m_formName;
			params.section_name       = this.m_sectionName;
		}
		if (this.m_formParent)
		{
			params.form_id = this.m_formParent.getFormId ();	
		}
		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}
		if (this.m_queryName)
		{
			params.query_name = this.m_queryName;
		}
		return params;	    
	},
	
	getSchema: function (fields)
	{
        return {
        	type:  "xml",
        	data:  "/root/run_query_action_return/run_query_action_success/dataset/row",
        	total: "/root/run_query_action_return/run_query_action_success/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields
            },
            errors : "/root/run_query_action_return/failure/text()"
        };
	},
	
	recordUpdated: function ()
	{
		if (this.m_onlineModeDeferred)
		{
			// finished sync'ing for this datasource
			this.m_onlineModeDeferred.resolve ();
			this.m_onlineModeDeferred = null;
		}		
	},
	
	handleDataSourceError: function (msg)
	{
    	this.getWidget ().cancelEvent ();
    	
    	if (msg)
    	{
			if (msg.indexOf ("@@") == 0)
			{
				// This is a special message to indicate sync errors when going into the online mode after being offline
				// What follows is the URL of the log
				AwareApp.registerOnlineSyncLog (msg);
			}
			else
			{
				alert (msg);
			}
    	}
		else
		{
			console.log ("data source error");
		}
	},
	
	encodeDataSourceData: function (data, operType)
	{
		var map = {};
		for (var param in data)
		{
			if (operType != "read")
			{
				if (param == "models")
				{
					this.encodeInlineEditingValues (map, data[param]);
				}
				else
				{
					map[param] = data[param];
				}
			}
			else	
			{
				this.encodeStandardDataParam (map, data, param, operType);
			}
		}
		
		if (this.m_onlineModeDeferred)
		{
			map.online_mode_sync = "true";
		}
		if (this.m_inRefresh)
		{
			map ["in_refresh"] = true;
		}
		if (this.m_gotoFirst && this.m_firstLoad)
		{
			// Need to get first record that does not fit into current calendar boundaries
			map ["no_calendar_filter"] = true;
			map ["start"] = "1";
			map ["pageSize"] = "1";
		}
		
		return map;
	},
	
	encodeStandardDataParam: function (map, data, param, operType)
	{
		if (! map.startDate && ! this.m_pagingOnClient)
		{
			// We have to take one day more day on both sides because one day may not work for different timezones
			var view    = this.getWidget().view ();
			var sd      = view.startDate ();
			var prevDay = new Date(sd.getTime () - 86400000);
			var ed      = view.endDate ();
			var nextDay = new Date(ed.getTime () + 86400000);

			map.startDate = kendo.toString (prevDay, "MM-dd-yyyy");
			map.endDate   = kendo.toString (nextDay,   "MM-dd-yyyy");
		}
		
		map[param] = data[param];
	},
	
	encodeInlineEditingValues: function (map, models)
	{
		for (var i = 0; i < models.length; ++ i)
		{
			var model = models[i];
			for (var attrName in model)
			{
				// ignore decorations and special fields
				if (attrName != "BAS_OPER_APPLICABILITY" && attrName != "bas_style" && attrName != "bas_titleDecor" && attrName != "startTimezone" && attrName != "endTimezone")
				{
					var value = model [attrName];
					this.encodeInlineEditingValue(map, attrName, i, value);
				}
			}
		}
	},
	
	encodeInlineEditingValue: function (map, an, idx, value)
	{
		var v = value;
		if (value instanceof Date)
		{
			v = kendo.toString (value, this.m_dateTimeFormat);
		}
		else if (value && $.isPlainObject (value))
		{
			// If value is from a combo box for some strange reason Kendo sends an object rather than primitive value
			// For static choices the attribute is "value" for dynamic choices - "name", for select references - BAS_REF_VALUE
			for (var key in value)
			{
				if (key == "value" || key == "name" || key == "BAS_REF_VALUE")
					v = value[key];
			}
		}

		// Map to server attribute names
		var attrName = an;
		if (attrName == "start")
		{
			attrName = "StartTime";
		}
		else if (attrName == "end")
		{
			attrName = "EndTime";
		}
		else if (attrName == "title")
		{
			attrName = "Subject";
		}
		else if (attrName == "description")
		{
			attrName = "Description";
		}
		else if (attrName == "isAllDay")
		{
			attrName = "AllDayEvent";
			v = (value === true ? "on" : "off");
		}
		else if (attrName == "recurrenceRule")
		{
			attrName = "RecRule";
		}
		else if (attrName == "recurrenceException")
		{
			attrName = "RecExc";
		}
		else if (attrName == "recurrenceId")
		{
			attrName = "RecID";
			if (v)
			{
				// server needs id only
				var objRef = getObjectReference (v);
				if (objRef)
					v = objRef.objectId;
			}
		}

		map ["m" + idx + "_" + attrName] = v;
	},

	getResourceDataSourceConfig: function (refAttrName)
	{
		var fields = {};
		this.addField ("BAS_DISPLAYED_FIELD", fields, false);
		this.addField ("BAS_REF_VALUE", fields, false);
		
		var params = { 
			actionType:    'get_scheduler_data_action', 
			ref_attr_name:  refAttrName, 
			query_name:     this.m_queryName
		};
		
		return {
			transport: AwareApp.createAwareTransport (params),
            schema: {
            	type:  "xml",
            	data:  "/root/get_scheduler_data_action_return/dataset/row",
            	total: "/root/get_scheduler_data_action_return/dataset/total/text()",
                model: {
                	id:     "BAS_REF_VALUE",
                    fields: fields
                },
                errors : "/root/get_scheduler_data_action_return/failure/text()"
            },
            offlineStorage:  this.m_widgetId + "_res",
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true,
            error: function (e)
            {
            	alert (e.errors ? e.errors : e.errorThrown);
            }
		};		
	},
	
	onDataBinding: function (scheduler, e)
	{
		// multiple resources need to be represented as arrays but server sends them as delimited strings, so convert to arrays
		for (var i = 0; i < this.m_multipleResourceFields.length; ++ i)
		{
			var fieldName = this.m_multipleResourceFields[i];
			var value = scheduler.dataSource.get (fieldName);
			scheduler.dataSource.set (fieldName, value.split ("@"));
		}
	},
	
	onDataBound: function (scheduler, e)
	{
		if (this.m_gotoFirst && this.m_firstLoad)
		{
			if (scheduler.dataSource.total () > 0)
			{
				var first = scheduler.dataSource.at (0);
				scheduler.date (first.get ("start"));
			}
		}
		
		this.m_firstLoad = false;
	},
	
	setupViews: function (widgetConfig, colWidth)
	{
		for (var i = 0; i < this.m_views.length; ++ i)
		{
			var view = this.m_views[i];
			
			var vc = { 
				type:     view.type,
				selected: view.selected
			};
			
			if (view.minorTick)
				vc.minorTickCount = view.minorTick;
			if (view.majorTick)
				vc.majorTick = view.majorTick;
			
			if (view.dateFormat)
			{
			      vc.dateHeaderTemplate = kendo.template("<strong>#=kendo.toString(date, '" + view.dateFormat + "')#</strong>");				
			}
			
			if (view.minorTimeFormat)
			{
				vc.minorTimeHeaderTemplate = kendo.template("<strong>#=kendo.toString(date, '" + view.minorTimeFormat + "')#</strong>");
			}
			if (view.majorTimeFormat)
			{
				vc.majorTimeHeaderTemplate = kendo.template("<strong>#=kendo.toString(date, '" + view.majorTimeFormat + "')#</strong>");
			}
			
			if (colWidth > 0 && view.type.indexOf ("timeline") == 0)
				vc.columnWidth = colWidth;
			
			widgetConfig.views.push (vc);
		}
		
		if (widgetConfig.views.length == 0)
		{
			widgetConfig.views = [ { type: "month", selected: true}, { type: "week"}, { type: "day"} ];
		}
	},
	
	getEventTemplate: function ()
	{
		var me = this;
		var tf = (this.m_timeFormat ? this.m_timeFormat : "HH:mm");
		return function (dataItem) {
			var title = dataItem.title, titleDecor = dataItem.bas_titleDecor, style = dataItem.bas_style, start = dataItem.start, end = dataItem.end, descr = dataItem.description;

			if (! descr || descr.length == 0)
				descr = kendo.toString (start, tf) + "-" + kendo.toString (end, tf) + " " + title;
			
			var html = "<div title='" + descr + "' class='aw-cal-event'";
			if (style)
				html += " style='" + style + "'";

			html += ">";
			if (titleDecor)
				html += $('<div/>').html(titleDecor).text();
			html += title;
			html += "</div>";
			return html;
		};
	},
	
	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("objectFormProvidedByProcess", this);
		AwareApp.deregisterListener ("objectsDeleted", this);
		AwareApp.deregisterListener ("formSaved", this);
		AwareApp.deregisterListener ("objectUpdated", this);
		AwareApp.deregisterListener ("referencesAdded", this);
		AwareApp.deregisterListener ("processFinished", this);
		AwareApp.deregisterListener ("processCancelled", this);
		AwareApp.deregisterListener ("providedFormShown", this);
		
		// clear local storage
		if (! AwareApp.localStorageDisabled ())
			localStorage.removeItem (this.m_widgetId);
		
		this.m_kendoOrigFields = null;
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	registerListeners: function ()
	{   	
		AwareApp.registerListener ("objectFormProvidedByProcess", this);
		AwareApp.registerListener ("objectsDeleted", this);
		AwareApp.registerListener ("formSaved", this);
		AwareApp.registerListener ("objectUpdated", this);
		AwareApp.registerListener ("referencesAdded", this);
		AwareApp.registerListener ("processFinished", this);
		AwareApp.registerListener ("processCancelled", this);
		AwareApp.registerListener ("providedFormShown", this);
	},
	
	afterRender: function ()
	{
      	var scheduler = this.getWidget ();
        
      	// enable editing on single click
      	if (! this.m_createNotAllowed || ! this.m_editNotAllowed)
      	{
      		this.handleSingleClick (scheduler);
      	}
      	
		if (this.m_renderScript)
		{
			var widget = scheduler;
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for calendar " + this.getQueryName () + " " + e);
			}
		}
		
		if (this.m_alignToBottom)
		{
			this.alignToBottom ();
		}
		else if (! this.m_panelHeight)
		{
			// still need to wait for calendar to display itself properly
			var me = this;
			setTimeout (function () {
				me.resizeToEnclosing ();
			}, 400);
		}
	},
	
	resizeToEnclosing: function ()
	{
		var p = this.getResizeToEnclosingPanel ();
		if (p)
		{
			var w = this.getWidget ();
			var ep = p.panel;
			var wrapperEl = $("#" + this.m_widgetInfo.wrapperId),
				dataArea = w.element;

			// for some reason calculations are 5 pixels off
			dataArea.height(dataArea.innerHeight () + ep.innerHeight() - wrapperEl.innerHeight() - 5);
			w.resize ();
		}
	},
	
	doAlignToBottom: function (params)
	{
		// Align to the bottom of the screen determined by the edge of the enclosing frame
		var frame = $("#" + params.frameId);
		if (frame && frame.length > 0)
		{
			var dataArea = this.getWidget ().element;
			
			dataArea.height (frame.offset ().top + frame.innerHeight() - dataArea.offset().top - params.margin);
		}	
	},
	
	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_CalendarParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	handleSingleClick: function (scheduler)
	{
  		var me = this;
      	scheduler.wrapper.on("mouseup touchend", ".k-scheduler-table td, .k-event", function(e) {
      		var target = $(e.target);
	
      		if(e.button != 0 || target.hasClass("k-si-close"))
      		{
      			// delete or right button
      			return;
      		}

      		target = $(e.currentTarget);
      		if (target.hasClass ("k-event-drag-hint"))
      		{
      			// we are in drag and drop
      			return;
      		}
      		
      		var event = null;
      		if(target.hasClass("k-event")) 
      		{
      			event = scheduler.occurrenceByUid(target.data("uid"));
      		}
      		else
      		{
       			var task = target.children (".k-task"); 
      			if (task.length > 0)
      			{
      				// agenda view
      				event = scheduler.occurrenceByUid(task.data("uid"));
      			}
      		}
      		
      		if(event) 
      		{
      			if (! me.m_editNotAllowed)
      			{
      				if (! operationApplicable (event, "Edit"))
      				{
      			        var config = {
  			                title:  AwareApp.Locale["C_Error"],
  			                msg:    AwareApp.Locale["C_SchedOperApplicable"],
  			                btnOK:  true
  			            };
  			            	
  			     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
      					return;
      				}
      				
     				if (me.m_editProcName)
     				{
      					me.editAppointment (event);
     				}
      				else
      				{
     					me.prepareForEditEvent (scheduler);
      					scheduler.editEvent(event);
      				}
      			}
      		}
      		else
      		{	
      			if (! me.m_createNotAllowed)
      			{
	      			var slot = scheduler.slotByElement(target[0]);
	      			if (me.m_createProcName)
	      			{
	      				me.createAppointment (slot.startDate, slot.endDate);
	      			}
	      			else
	      			{
     					me.prepareForEditEvent (scheduler);
		      			var e = {
		      				start: slot.startDate,
		      				end: slot.endDate
		      			};
		      			
		      			// initial values for resources
     					var res = scheduler.resourcesBySlot (slot);
     					if (res)
     					{
     						for (var key in res)
     							e[key] = res[key];
     					}
     					
		      			scheduler.addEvent(e);
	      			}
      			}
      		}
        });		
	},
	
	prepareForEditEvent: function (scheduler)
	{
		// This is really a hack where we override Kendo's fields method of the scheduler's editor to add our custom fields
		if (this.m_editAttrs && ! this.m_kendoOrigFields)
		{
			this.m_kendoOrigFields = scheduler._editor.fields;
			var me = this;
			scheduler._editor.fields = function (editors, model) {
				var columns = me.m_kendoOrigFields.call (this, editors, model);
				for (var i = 0; i < me.m_editAttrs.length; ++ i)
				{
					var ea = me.m_editAttrs[i];
					
					var c = { field: ea.attrName, title: ea.title };
					if (ea.format)
						c.format = ea.format;
					
					var awField = null;
					if (ea.selectRefNode)
					{
						var config = {
							name:       ea.attrName,  // without name validation doesn't display error messages
							attrName:   ea.attrName,
							allowBlank: ! ea.required,
							attrValue:  model.get (ea.attrName)
						};
						
						var refValue = model.get ('BAS_REF_VALUE');
						awField = AwareApp.FieldCreator.createSelectReference (ea.selectRefNode, config);
					}
					else if (ea.dataType == "datetime")
					{
						awField = new AwareApp_DateTimeField ({
							fullFormat: ea.format,
							dateFormat: ea.format,
							name:       ea.attrName,  // without name validation doesn't display error messages
							timeFormat: "HH:mm",
							allowBlank: ! ea.required,
							attrValue:  model.get (ea.attrName)
						});
					}
					else if (ea.staticChoicesNode)
					{
						var editable = getBooleanValue (ea.staticChoicesNode, "choices_editable", false);
						if (! editable)
						{
							// for some reason editable drop downs do not display the existing values (Bug in Kendo??). Not editable work fine
							// So for editable ones use the default text box
							var config = {
								editable: editable,
								choices:  AwareApp.FieldCreator.getStaticChoices (ea.staticChoicesNode),
								name:       ea.attrName,  // without name validation doesn't display error messages
								allowBlank: ! ea.required,
								attrValue:  model.get (ea.attrName)
							}
							awField = new AwareApp_ComboField (config);
						}
					}
					else if (ea.dynamicChoicesNode)
					{
						var qsNodes = ea.dynamicChoicesNode.getElementsByTagName ("query_string");
						if (qsNodes && qsNodes.length > 0)
						{
							var attrName = getAttributeValue (ea.dynamicChoicesNode, "attr_name", null);
							var queryStr = getTextNodeValue (qsNodes [0]); 
							
							var config = {
								editable:   true,
								name:       ea.attrName,  // without name validation doesn't display error messages
								allowBlank: ! ea.required,
								attrValue:  model.get (ea.attrName)
							}
							config.objRefNodes = ea.dynamicChoicesNode.getElementsByTagName ("object_reference");
							config.dcStore = AwareApp.FieldCreator.createStoreForDynamicChoices (config, attrName, queryStr);
							
							awField = new AwareApp_ComboField (config);
						}
					}
					
					if (awField)
					{
						me.assignEditor(awField, c);
					}
					
					columns.push (c);
				}

				return columns;
			};
		}
	},
	
	assignEditor: function (awField, c)
	{
		// This is nearly the same as in queryLayoutParser
		var markup = awField.getInlineEditingMarkup (true);
		c.editor = function (container, options) {
			// this is required by inline custom editor framework
			markup.inputElem.attr ("data-bind", "value:" + options.field);
			if (options.format)
				markup.inputElem.attr ("data-format", options.format);  // needed for datetime
			
			var html = $('<div />').append(markup.inputElem).html(); 
			$(html).appendTo (container);
			
			AwareApp.startWidgets (markup.widgets);
		};		
	},

	prepareContextMenu: function (itemOpers, widgetId, widgets)
	{
		var id = widgetId + "_cm";
		
		var items = new Array ();
		for (var i = 0; i < itemOpers.length; ++ i)
		{
			var oper = itemOpers[i];			
			var b = this.getOperationButton (oper, false);
			if (b)
				items.push (b);
		}
		
		var me = this;
		widgets.push ({
			type: "contextmenu",
			id:   id,
			config: {
				target: "#" + widgetId,
				dataSource: items,
		        filter: ".k-event",
                select: function(e) {
                	e.preventDefault ();
                	me.onContextMenu ($(e.item), $(e.target));
                }
			}
		});
		
		return "<ul id='" + id + "'></ul>";
	},
	
	onContextMenu: function (menuItem, selItem)
	{
		var text = menuItem.text ();
		for (var i = 0; i < this.m_itemOpers.length; ++ i)
		{
			var oper = this.m_itemOpers[i];
			if (oper.operName == text)
			{
				this.runItemOperation(oper, this.getWidget ().occurrenceByUid (selItem.data("uid")));
				break;
			}
		}
	},
	
	getKeyForState: function ()
	{
		var key =  this.m_refAttrName ?
		           AwareApp.STATE_PREFIX + "R" + "@" + this.m_refOwnerName + "@" + this.m_refAttrName :
		           AwareApp.STATE_PREFIX + "Q" + "@" + this.m_queryName;
		           
		// size has to be less than the length in the database
		return key.length <= 240 ? key : key.substring (0, 240);
	},

	getTourElementSelector: function (sectionId)
	{
		var tourElem = this.m_tourElements [sectionId];
		if (! tourElem)
			return null;
		
		if (tourElem.type == "oper")	
		{
			return "#" + tourElem.id;
		}
		
		return null;
	},
	
	// Create a new appointment. If the date is given - for the given date
	createAppointment: function (startDate, endDate)
	{
		this.m_pendingEdit = { startDate: (startDate ? startDate : new Date ()), endDate: endDate };
			
		var context = this.getQueryContext ();				
		action = new AwareApp_StartProcessExecutionAction (
					this.m_createProcName, 
					context, 
					null, 
					AwareApp_VPParser.prototype.toRenderOption (this.m_createProcTarget), 
					null, 
					this);
		
		action.run ();
	},
	
	// notification function that gets called when the process started by us has actually started
	processStarted: function (inDocumentDownload, noRefresh, procReply)
	{
		if (procReply && procReply.widgetInfo && this.m_pendingEdit && this.m_pendingEdit.startDate)	
		{
			this.initStartEndTime (procReply.widgetInfo.parser);
			this.m_pendingEdit = null;
		}
	},
	
	initStartEndTime: function (formParser)
	{
		if (this.m_pendingEdit && formParser.getField)
		{
    		var sf = formParser.getField ("StartTime");
    		if (sf)
    		{
    			sf.setValue (this.m_pendingEdit.startDate);
    		}
    		var ef = formParser.getField ("EndTime");
    		if (ef)
    		{
    			ef.setValue (this.m_pendingEdit.endDate);
    		}
		}
	},
	
	editAppointment: function (apptRecord)
	{
		this.m_pendingEdit = { editRecord: apptRecord };
		
		var action = new AwareApp_StartProcessExecutionAction (
							this.m_editProcName, 
							this.getContextForOperation(null, apptRecord), 
							null, 
							AwareApp_VPParser.prototype.toRenderOption (this.m_editProcTarget), 
							null, 
							null);		
		action.run ();
	},
	
	deleteAppointment: function (operName, apptRecord)
	{
		if (apptRecord && ! operationApplicable (apptRecord, operName))
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_SchedOperApplicable"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return null;
		}
		
		if (! window.confirm (AwareApp.Locale["C_GridConfDel"]))
			return false;

		var objRef = (apptRecord ? getObjectReference (apptRecord.id) : null);
		if (! objRef)
			return;
		
		var action = new AwareApp_DeleteObjectsAction ([ objRef ]);			
		action.run ();
		
		return true;
	},
	
	getContextForOperation: function (oper, apptRecord)
	{
		var context = new Array ();
		
		if (apptRecord)
		{
			var objRef = getObjectReference (apptRecord.id);
			if (objRef)
				context.push (objRef);
		}
		
		if (oper && oper.operType == "delete_object")
		{
		}
		else
		{
			var queryContext = this.getQueryContext ();
			if (queryContext)
			{
				for (var i = 0; i < queryContext.length; ++ i)
					context.push (queryContext [i]);
			}
		}
		
		return context.length == 0 ? null : context;
	},
	
	operationSupported: function (oper)
	{
		if ((oper.operType == "import_ics" || oper.operType == "export_ics") && kendo.support.mobileOS)
		{
			return false;
		}
		
		return true;
	},
	
	runItemOperation: function (oper, apptRecord)
	{
		if (apptRecord && ! operationApplicable (apptRecord, oper.operName))
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_SchedOperApplicable"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return null;
		}
		
		this.runOperation (this.getContextForOperation(oper, apptRecord), oper);
	},
	
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "objectsDeleted")
		{
			if (eventInfo && eventInfo.length > 0)
			{
				for (var i = 0; i < eventInfo.length; ++ i)
				{
					if (this.ourAppointment (eventInfo [i]))
					{
						this.refreshData ();
						break;
					}
				}
			}
		}
		else if (eventName == "referencesAdded")
		{
			if (this.m_refOwnerName && this.m_refOwnerId && this.m_refAttrName &&
				this.m_refOwnerName == eventInfo.refOwnerName &&
				this.m_refOwnerId   == eventInfo.refOwnerId &&
				this.m_refAttrName  == eventInfo.refAttrName)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processFinished")
		{
			if (eventInfo && 
			   ((this.m_createProcName && eventInfo.processName == this.m_createProcName) ||
			    (this.m_editProcName && eventInfo.processName == this.m_editProcName)))
			{
				this.refreshData ();
			}
			else if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processCancelled")
		{
			this.m_pendingEdit = null;
		}
		else if (eventName == "calSyncFinished")
		{
			AwareApp.deregisterListener ("calSyncFinished", this);
			
			var a = new AwareApp_CalSyncResultsAction (this, this.m_syncType);
			a.run ();
		}
		else if (eventName == "importICSFinished")
		{
			AwareApp.deregisterListener ("importICSFinished", this);
			var a = new AwareApp_ImportICSResultsAction (this);
			a.run ();
		}
		else if (eventName == "providedFormShown")
		{
			if (eventInfo && eventInfo.widgetInfo && eventInfo.widgetInfo.parser && this.m_pendingEdit)
			{
				this.initStartEndTime (eventInfo.widgetInfo.parser);
				this.m_pendingEdit = null;
			}
		}
	},
	
	ourAppointment: function (eventInfo)
	{
		return eventInfo && eventInfo.objectName == this.m_queryOnName && ! this.m_isGroupName;
	},
	
	getStartDay: function (coNode)
	{
		var firstDay = getAttributeValue (coNode, "first_day_of_week", "Monday");
		if (firstDay == "Sunday")
			return 0;
		if (firstDay == "Tuesday")
			return 2;
		if (firstDay == "Wednesday")
			return 3;
		if (firstDay == "Thursday")
			return 4;
		if (firstDay == "Friday")
			return 5;
		if (firstDay == "Saturday")
			return 6;
			
		return 1;
	},
	
	exportPDF: function ()
	{
		this.getWidget().saveAsPDF ();
	},
	
	syncCalendar: function (oper)
	{
		var apiIdAttrName = null, apiSecretAttrName = null;
		if (oper.params)
		{
			var s = oper.params.split ("@");
			if (s && s.length >= 2)
			{
				if (s[0] != "null" && s[1] != "null")
				{
					apiIdAttrName     = s[0];
					apiSecretAttrName = s[1];
				}
			}
		}
		
		var syncType = (oper.operType == "cf_sync" ? "cf" : "gc");
		if (! AwareApp.calendarAccessAuthorized (syncType))
		{
			var a = new AwareApp_CalendarAuthorizationAction (apiIdAttrName, apiSecretAttrName, syncType);
			a.run ();
			
			var me = this;
			var id = setInterval (
					function () { 
						var cga = new AwareApp_CheckCalendarAuthorizationAction (syncType, id, function () { this.syncCalendar (oper); }, me);
						cga.run ();
					}, 
					1000);
		}
		else
		{
			var a = new AwareApp_GetCalendarsAction (this, apiIdAttrName, apiSecretAttrName, syncType, oper.params);
			a.run ();			
		}
	},
	
	handleSyncCalendars: function (cals, apiIdAttrName, apiSecretAttrName, syncType, params)
	{
		if (cals.length == 0)
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_GCSNoCalendars"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
    		return;
		}
		
		new AwareApp_CalendarSyncParser (this, cals, apiIdAttrName, apiSecretAttrName, syncType, params).parse ();
	},
	
	syncWithCalendar: function (calendarId, direction, apiIdAttrName, apiSecretAttrName, syncType, params)
	{
		var a = new AwareApp_CalendarSyncAction (this, calendarId, direction, apiIdAttrName, apiSecretAttrName, syncType, params);
		a.run ();
		
		this.m_syncType = syncType;
		
		AwareApp.registerListener ("calSyncFinished", this);
		
		AwareApp.startProgressBar (
	           	AwareApp.Locale["C_GCSInProgress"],
	           	AwareApp.Locale["C_GCSWait"],
	           	true,
				"cal_sync_action", 
				"calSyncFinished", 
				null,
				function () {}
		);
	},
	
	syncFinished: function ()
	{
		this.refreshData ();
	},
	
	exportICS: function ()
	{
		var c = {
		   title:     AwareApp.Locale["C_Confirm"],
		   msg:       AwareApp.Locale["C_ExpICSMsg"],
		   btnYes:    true,
		   btnNo:     true
		};
		
		var me = this;
		$.when(AwareApp_MessageBox.show(c)).then(function(b){
			if (b == "yes")
			{
				me.doExportICS (false);
			}
			else if (b == "no")
			{
				me.doExportICS (true);
			}
		});
	},
	
	doExportICS: function (visibleOnly)
	{
		var bounds = null;
		if (visibleOnly)
		{
			var view = this.getWidget().view ();
			bounds = {
				start: view.startDate (),
				end:   view.endDate ()
			};
		}
		
		var a = new AwareApp_ExportICSAction (this, bounds);
		a.run ();
	},

	importICS: function ()
	{
		var a = new AwareApp_GetAppointmentMembersAction (this);
		a.run ();
	},

	displayImportICSForm: function (xmlDoc)
	{
		var p = new AwareApp_ImportICSParser (this, xmlDoc);
		p.parse ();
	},

	doICSImport: function (objName)
	{
		AwareApp.registerListener ("importICSFinished", this);
		
		AwareApp.startProgressBar (
           	AwareApp.Locale["C_Importing"],
           	AwareApp.Locale["C_ImportingW"],
           	true,
			"import_ics_action", 
			"importICSFinished", 
			null,
			function () {}
		);
		
		var action = new AwareApp_ImportICSAction (objName);
		action.run ();		
	},

	importICSFinished: function ()
	{
		this.refreshData ();
	}
});

var AwareApp_GetCalendarsAction = AwareApp_ServerCallAction.extend(
{
	init: function (parser, apiIdAttrName, apiSecretAttrName, syncType, params)
	{
		AwareApp_ServerCallAction.fn.init.call (this);
		
		this.m_parser            = parser;
		this.m_apiIdAttrName     = apiIdAttrName;
		this.m_apiSecretAttrName = apiSecretAttrName; 
		this.m_syncType          = syncType;
		this.m_params            = params;
	},

    buildRequest: function ()
    {
    	var s = "<get_calendars_action";
    	
     	if (this.m_apiIdAttrName)
    	{
    		s += " api_id_attr_name=\"";
    		s += this.m_apiIdAttrName;
    		s += "\"";
    	}
    	if (this.m_apiSecretAttrName)
    	{
    		s += " api_secret_attr_name=\"";
    		s += this.m_apiSecretAttrName;
    		s += "\"";
    	}
    	
    	s += " sync_type=\"";
    	s += this.m_syncType;
    	s += "\"";
    	
    	s += " />";
    	
    	return s;
    },
	
    handleServerResponse: function (xmlDoc)
    {
    	var cals = new Array ();
    	
    	var nodes = xmlDoc.getElementsByTagName ("calendar");
    	if (nodes)
    	{
    		for (var i = 0; i < nodes.length; ++ i)
    		{
    			var id = getAttributeValue (nodes[i], "id", null);
    			if (id)
    			{
    				var provider = getAttributeValue (nodes[i], "provider", "");
    				
    				var summary = "";
    				var sn = nodes [i].getElementsByTagName ("summary");
    				if (sn && sn.length > 0)
    					summary = getTextNodeValue (sn[0]);
    				
    				cals.push ({ value: id + "@" + provider, text: summary });
    			}
    		}
    	}
    	
    	this.m_parser.handleSyncCalendars (cals, this.m_apiIdAttrName, this.m_apiSecretAttrName, this.m_syncType, this.m_params);
    }
});  

var AwareApp_CalendarSyncAction = AwareApp_ServerCallAction.extend(
{
	init: function (parser, calendarId, direction, apiIdAttrName, apiSecretAttrName, syncType, params)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_calendarParser    = parser;
		this.m_calendarId        = calendarId;
		this.m_direction         = direction;
		this.m_apiIdAttrName     = apiIdAttrName;
		this.m_apiSecretAttrName = apiSecretAttrName; 
		this.m_syncType          = syncType;
		this.m_params            = params;
	},

    buildRequest: function ()
    {
    	var s = "<cal_sync_action calendar_id='";
    	s += this.m_calendarId;
    	s += "' sync_type='";
    	s += this.m_syncType;
    	s += "'";
    	
    	if (this.m_direction)
    	{	
			s += " direction='";
			s += this.m_direction;
			s += "'";
    	}
    	if (this.m_apiIdAttrName)
    	{
    		s += " api_id_attr_name=\"";
    		s += this.m_apiIdAttrName;
    		s += "\"";
    	}
    	if (this.m_apiSecretAttrName)
    	{
    		s += " api_secret_attr_name=\"";
    		s += this.m_apiSecretAttrName;
    		s += "\"";
    	}
    	if (this.m_params)
    	{
    		s += " params=\"";
    		s += this.m_params;
    		s += "\"";
    	}
		
		var refAttrName = this.m_calendarParser.getRefAttrName ();
		if (refAttrName)
		{
			s += " ref_owner_name='";
			s += this.m_calendarParser.getRefOwnerName ();
			s += "'";
			
			s += " ref_attr_name='";
			s += refAttrName;
			s += "'";
			
			s += " ref_owner_id='";
			s += this.m_calendarParser.getRefOwnerId ();
			s += "'";
		}
		
		var objectRefNodes = this.m_calendarParser.m_objectRefNodes;
		if (objectRefNodes && objectRefNodes.length > 0)
		{
			var ctx = buildQueryContextString (objectRefNodes);
			s += " query_context='";
			s += ctx;
			s += "'";
		}
		
		var queryStr = this.m_calendarParser.getQueryString ();
		if (queryStr)
		{
			s += " query_str=\"";
			s += htmlEncode (queryStr);
			s += "\"";
		}
						
   		s += "> \r\n";
   		
   		s += "</cal_sync_action> \r\n";
    	return s;
    },
        
    handleServerResponse: function (xmlDoc)
    {
    }
});  

var AwareApp_CalSyncResultsAction = AwareApp_ServerCallAction.extend(
{
	init: function (parser, syncType)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_calendarParser = parser;
		this.m_syncType       = syncType;
	},

    buildRequest: function ()
    {
    	var s = "<cal_sync_results_action sync_type=\"";
    	s += this.m_syncType;
    	s += "\" />";
    		
    	return s;
    },
        
    handleServerResponse: function (xmlDoc)
    {
    	var logUrl = null;
    	
    	var nodes = xmlDoc.getElementsByTagName ("logfile_url");
    	if (nodes && nodes.length > 0)
    		logUrl = getTextNodeValue (nodes [0]);
    	
    	nodes = xmlDoc.getElementsByTagName ("error_msg");
    	if (nodes && nodes.length > 0)
    	{
    		alert (getTextNodeValue (nodes[0]));
    		return;
    	}
    	
    	var errors = false;
    	nodes = xmlDoc.getElementsByTagName ("errors_detected");
    	if (nodes && nodes.length > 0)
    		errors = true;
    	
    	if (errors)
    	{
			var c = {
			   title:     AwareApp.Locale["C_Error"],
			   msg:       AwareApp.Locale["C_GCSErrors"],
			   btnYes:    true,
			   btnNo:     true
			};
			
			var me = this;
			$.when(AwareApp_MessageBox.show(c)).then(function(b){
				if (b == "yes")
				{
					AwareApp.displayDocument (logUrl, false);
				}
			});
    	}
    	else
    	{
			var c = {
			   title:     AwareApp.Locale["C_Success"],
			   msg:       AwareApp.Locale["C_GCSSuccess"],
			   btnYes:    true,
			   btnNo:     true
			};
			
			var me = this;
			$.when(AwareApp_MessageBox.show(c)).then(function(b){
				if (b == "yes")
				{
					AwareApp.displayDocument (logUrl, false);
				}
			});
    	}
    	
    	this.m_calendarParser.syncFinished ();    	
    }
});  

var AwareApp_ExportICSAction = AwareApp_ServerCallAction.extend(
{
	init: function (parser, bounds)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_calendarParser = parser;
		this.m_bounds         = bounds;
	},

    buildRequest: function ()
    {
    	var s = "<export_ics_action";
		
		var refAttrName = this.m_calendarParser.getRefAttrName ();
		if (refAttrName)
		{
			s += " ref_owner_name='";
			s += this.m_calendarParser.getRefOwnerName ();
			s += "'";
			
			s += " ref_attr_name='";
			s += refAttrName;
			s += "'";
			
			s += " ref_owner_id='";
			s += this.m_calendarParser.getRefOwnerId ();
			s += "'";
		}
		
		var objectRefNodes = this.m_calendarParser.m_objectRefNodes;
		if (objectRefNodes && objectRefNodes.length > 0)
		{
			var ctx = buildQueryContextString (objectRefNodes);
			s += " query_context='";
			s += ctx;
			s += "'";
		}
		
		var queryStr = this.m_calendarParser.getQueryString ();
		if (queryStr)
		{
			s += " query_str='";
			s += htmlEncode (queryStr);
			s += "'";
		}
		
		if (this.m_bounds)
		{
			s += " start_date='";
			s += kendo.toString (this.m_bounds.start, 'MM-dd-yyyy');
			s += "' end_date='";
			s += kendo.toString (this.m_bounds.end, 'MM-dd-yyyy');
			s += "'";
		}
						
   		s += "> \r\n";
   		
   		s += "</export_ics_action> \r\n";
    	return s;
    },
        
    handleServerResponse: function (xmlDoc)
    {
    	var url = null;
    	
    	var nodes = xmlDoc.getElementsByTagName ("calfile_url");
    	if (nodes && nodes.length > 0)
    		url = getTextNodeValue (nodes [0]);
    	
    	if (url != null)
    	{
    		AwareApp.downloadFile (url);
    	}    	
   }
});  

var AwareApp_ExportICSEventAction = AwareApp_ServerCallAction.extend(
{
	init: function (objectName, objectId)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_objectName = objectName;
		this.m_objectId   = objectId;
	},

    buildRequest: function ()
    {
    	var s = "<export_ics_event_action object_name=\"";
    	s += this.m_objectName;
    	s += "\" object_id=\"";
    	s += this.m_objectId;
    	s += "\" />";
		
    	return s;
    },
        
    handleServerResponse: function (xmlDoc)
    {
    	var url = null;
    	
    	var nodes = xmlDoc.getElementsByTagName ("calfile_url");
    	if (nodes && nodes.length > 0)
    		url = getTextNodeValue (nodes [0]);
    	
    	if (url != null)
    	{
    		AwareApp.downloadFile (url);
    	}    	
   }
});

var AwareApp_GetAppointmentMembersAction = AwareApp_ServerCallAction.extend(
{
	init: function (calendarParser)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_calendarParser = calendarParser;
	},

     buildRequest: function ()
    {
    	return "<get_appointments_action />";
    },
        
     handleServerResponse: function (xmlDoc)
    {
    	this.m_calendarParser.displayImportICSForm (xmlDoc);
    }
});  

var AwareApp_ImportICSAction = AwareApp_ServerCallAction.extend(
{
	init: function (objectName)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_objectName = objectName;
	},

    buildRequest: function ()
    {
    	var s = "<import_ics_action object_name=\"";
    	s += this.m_objectName;
    	s += "\" />";
		
    	return s;
    }
});

var AwareApp_ImportICSResultsAction = AwareApp_ServerCallAction.extend(
{
	init: function (parser)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_calendarParser = parser;
	},

    buildRequest: function ()
    {
    	return "<import_ics_results_action />"; 
    },
        
    handleServerResponse: function (xmlDoc)
    {
    	var logUrl = null;
    	
    	var nodes = xmlDoc.getElementsByTagName ("logfile_url");
    	if (nodes && nodes.length > 0)
    		logUrl = getTextNodeValue (nodes [0]);
    	
    	nodes = xmlDoc.getElementsByTagName ("error_msg");
    	if (nodes && nodes.length > 0)
    	{
    		alert (getTextNodeValue (nodes[0]));
    		return;
    	}
    	
    	var errors = false;
    	nodes = xmlDoc.getElementsByTagName ("errors_detected");
    	if (nodes && nodes.length > 0)
    		errors = true;
    	
    	if (errors)
    	{
			var c = {
			   title:     AwareApp.Locale["C_Error"],
			   msg:       AwareApp.Locale["C_ImpICSErr"],
			   btnYes:    true,
			   btnNo:     true
			};
			
			var me = this;
			$.when(AwareApp_MessageBox.show(c)).then(function(b){
				if (b == "yes")
				{
					AwareApp.displayDocument (logUrl, false);
				}
			});
    	}
    	else
    	{
			var c = {
			   title:     AwareApp.Locale["C_Success"],
			   msg:       AwareApp.Locale["C_ImpICSSuc"],
			   btnYes:    true,
			   btnNo:     true
			};
			
			var me = this;
			$.when(AwareApp_MessageBox.show(c)).then(function(b){
				if (b == "yes")
				{
					AwareApp.displayDocument (logUrl, false);
				}
			});
    	}
    	
    	this.m_calendarParser.importICSFinished ();    	
    }
});  

var AwareApp_CalendarSyncParser = AwareApp_BaseParser.extend(
{
	init: function (calParser, cals, apiIdAttrName, apiSecretAttrName, syncType, params)
	{
		this.m_calParser         = calParser;
		this.m_cals              = cals;
		this.m_apiIdAttrName     = apiIdAttrName;
		this.m_apiSecretAttrName = apiSecretAttrName; 
		this.m_syncType          = syncType;
		this.m_params            = params;
	},

	getPanelWidth: function ()
	{
		return 350;
	},
	
	parse: function ()
	{
		var widgets = new Array ();
		var markup  = this.getMarkup (this.m_cals, widgets);
		
		this.m_id = "AW_CSA_" + Math.floor (Math.random () * 100001);
		
		var dc = AwareApp.DefaultIcons.getConfig ("query", "gc_sync");
		this.m_widgetInfo = {
		    wrapperId:    this.m_id,
			markup:       markup,
			kendoWidgets: widgets,
			parser:       this,
			title:        AwareApp.Locale["C_GCSSelectCalTitle"],
			iconCls:      dc.iconCls
		};
		
		var me = this;
		AwareApp.startEnclosingWindow (this.m_widgetInfo, {
			okButton: {
				text:    AwareApp.Locale["C_GCSBeginSync"],
				width:   150,
				handler: function ()
				{
					me.startSync ();					
				}
			}
		});
	},

	getMarkup: function (cals, widgets)
	{	    
		var wrapper = $("<div>").attr ("id", this.m_id).addClass ("aw-form aw-form-borders-off");
		var body = $("<div>").addClass ("aw-form-body");
		wrapper.append (body);
		
		var provider = (cals.length > 0 ? cals[0].provider : null);
		if (! provider)
			provider = AwareApp.Locale["C_GCSExternal"];
		
		this.m_dirCombo = new AwareApp_ComboField ({
			choices:    [
			    { text: AwareApp.Locale["C_GCSFromGC"].replace ("{0}", provider), value: "from_gc" },
			    { text: AwareApp.Locale["C_GCSToGC"].replace ("{0}", provider),   value: "from_system" },
			    { text: AwareApp.Locale["C_GCS2W"],     value: "two_way" }
			],
			editable:   false,
			labelAlign: "top",
			label:      AwareApp.Locale["C_GCSDirection"] + ":",
			labelStyle: "font-weight:normal",
			width:      300,
			attrValue:  "from_gc"
		});
		
		var html = this.m_dirCombo.getMarkup (widgets); 
		
		this.m_calCombo = new AwareApp_ComboField ({
			choices:    cals,
			editable:   false,
			labelAlign: "top",
			label:      AwareApp.Locale["C_GCSSelectCal"] + ":",
			labelStyle: "font-weight:normal",
			width:      300,
			attrValue:  cals[0].value
		});
		
		html += this.m_calCombo.getMarkup (widgets);
		
		body.append (html);
		
		return $('<div />').append(wrapper).html();
	},
	    
	startSync: function ()
	{
		var id  = this.m_calCombo.getValue ();
		var dir = this.m_dirCombo.getValue ();
		var text = "";
		for (var i = 0; i < this.m_cals.length; ++ i)
		{
			if (this.m_cals[i].value == id)
			{
				text = this.m_cals[i].text;
				break;
			}
		}
		
		var c = {
		   title:     AwareApp.Locale["C_GCSConfirmTitle"],
		   msg:       AwareApp.Locale["C_GCSConfirmMsg"].replace ("{0}", text),
		   btnYes:    true,
		   btnNo:     true
		};
		
		var me = this;
		$.when(AwareApp_MessageBox.show(c)).then(function(b){
			if (b == "yes")
			{
				me.m_calParser.syncWithCalendar (id, dir, me.m_apiIdAttrName, me.m_apiSecretAttrName, me.m_syncType, me.m_params);
			}
		});
	}
});

var AwareApp_ImportICSParser = AwareApp_BaseParser.extend(
{
	init: function (calParser, xmlDoc)
	{
		this.m_calParser = calParser;
		this.m_xmlDoc    = xmlDoc;
	},

	getPanelWidth: function ()
	{
		return 550;
	},
	
	parse: function ()
	{
		var widgets = new Array ();
		var markup  = this.getMarkup (this.m_cals, widgets);
		
		this.m_id = "AW_ICS_" + Math.floor (Math.random () * 100001);
		
		var dc = AwareApp.DefaultIcons.getConfig ("menu", "import");
		this.m_widgetInfo = {
		    wrapperId:    this.m_id,
			markup:       markup,
			kendoWidgets: widgets,
			parser:       this,
			title:        AwareApp.Locale["C_ImpICSTit"],
			iconCls:      dc.iconCls
		};
		
		var me = this;
		AwareApp.startEnclosingWindow (this.m_widgetInfo, {
			okButton: {
				text:    AwareApp.Locale["C_Import"],
				handler: function ()
				{
					me.doICSImport ();					
				}
			}
		});
	},

	getMarkup: function (cals, widgets)
	{	    
		var wrapper = $("<div>").attr ("id", this.m_id).addClass ("aw-form aw-form-borders-off");
		var body = $("<div>").addClass ("aw-form-body");
		wrapper.append (body);
		
		var choices = AwareApp.FieldCreator.getNameChoices (this.m_xmlDoc, "appointment");
		this.m_objCombo = new AwareApp_ComboField ({
			choices:    choices,
			editable:   false,
			labelAlign: "top",
			label:      AwareApp.Locale["C_ImpICSObj"] + ":",
			labelStyle: "font-weight:normal",
			allowBlank: false,
			width:      490,
			attrValue: (choices.length>0 ? choices[0].text : "")
		});
		
		var html = this.m_objCombo.getMarkup (widgets);
		
		html += "<div class='form-inline'>";
		this.m_docField = new AwareApp_DocumentField ({
			labelAlign: "top",
			label:      AwareApp.Locale["C_ImpICSFile"] + ":",
			labelStyle: "font-weight:normal",
			width:      490,
			name:       "Doc"   // without some name upload doesn't work
		});
		
		html += this.m_docField.getMarkup (widgets);
		html += "</div>";
		
		body.append (html);
		
		return $('<div />').append(wrapper).html();
	},
	
	doICSImport: function ()
	{
		var objName = this.m_objCombo.getValue ();
		this.m_calParser.doICSImport (objName);
	}
});	