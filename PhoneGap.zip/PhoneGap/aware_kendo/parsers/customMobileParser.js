// This parser handles queries that have custom presentation
var AwareApp_CustomMobileParser = AwareApp_BaseParser.extend(
{
	// If entityName and id are not null we are showing presentation for this entity
	init: function (xmlDoc, queryString, inWindow)
	{
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);

		this.m_queryStr = queryString;
		
		this.m_itemsPerPage = 40;
	},

 	// used in preview framework
	reset: function ()
	{
		this.m_tools = null;
		this.m_toolbars = null;
		this.m_panelHeader = null;
		this.m_panelOpers = null;
		this.m_extParams = null;
		
		this.init (this.m_xmlDoc, this.m_queryStr, false);
	},
	
	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName ("custom_mobile_layout");
		if (! mainNodes || mainNodes.length != 1)
			return null;
			
		var mainNode = mainNodes [0];
		
		if (! this.m_queryStr)
		{
			var queryStrNodes = getFirstLevelChildNodes (mainNode, "query_string");
			if (! queryStrNodes || queryStrNodes.length == 0)
				return null;
			
			this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		}
		
		this.m_refreshProcs    = getAttributeValue (mainNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (mainNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue   (mainNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue (mainNode, "refresh_impl_proc", null);
		this.m_refOwnerName    = getAttributeValue (mainNode, "ref_owner_name",null);
		this.m_refAttrName     = getAttributeValue (mainNode, "ref_attr_name", null);
		this.m_refOwnerId      = getAttributeValue (mainNode, "ref_owner_id",  null);
		this.m_formName        = getAttributeValue (mainNode, "form_name",     null);
		this.m_sectionName     = getAttributeValue (mainNode, "section_name",  null);		
		this.m_queryName       = getAttributeValue (mainNode, "query_name",    null);
		this.m_multiSelect     = getBooleanValue   (mainNode, "multi-select",  false);

		if (! this.m_previewMode)
			this.m_previewMode = getBooleanValue (mainNode, "preview_mode", false);
		
		var rsn = mainNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		
		this.m_objectRefNodes = mainNode.getElementsByTagName ("object_reference");
		var dtNodes           = mainNode.getElementsByTagName ("data_template");
		var dtNode            = dtNodes[0];
		
		this.m_itemOpers = this.getItemOperations (mainNode);
		
		var template = this.parseDataTemplate(dtNode, mainNode);
		
		this.m_widgetId   = "AW_CUSTOM_MOB_QUERY_" + Math.floor (Math.random () * 100001);	
		this.m_listViewId = this.m_widgetId + "_lv";
		
		var filter = this.parseFilter (mainNode);
		
		var fields = this.getFields (dtNode);

		this.m_dataSource = new kendo.data.DataSource(this.getDataSourceConfig (mainNode, fields, template));
		var widgetConfig = this.getWidgetConfig (template, this.m_dataSource, filter);
		
		var panelConfig = this.getPanelConfig (mainNode, this.m_widgetId, "mobile_listview");	
		panelConfig.bodyContent = this.getListViewMarkup (template);
						
		this.m_panel = new AwareApp_Panel (panelConfig);
		
    	var widgets = new Array ();
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "mobileScroller",
    		id:     this.m_widgetId,
    		config: {}
    	});
    	widgets.push ({
    		type:   "mobileListView",
    		id:     this.m_listViewId,
    		config: widgetConfig
    	});
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
  	
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        panelConfig.title,
        	icon:         panelConfig.icon,
        	iconCls:      panelConfig.iconCls
        };

		// run init script if any
		this.runInitScript (mainNode, widgetConfig, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;
	},
	
	registerListeners: function ()
	{
		AwareApp.registerListener ("objectsDeleted", this);
		AwareApp.registerListener ("formSaved", this);
		AwareApp.registerListener ("objectUpdated", this);
		AwareApp.registerListener ("processFinished", this);
		AwareApp.registerListener ("processCancelled", this);
		AwareApp.registerListener ("referencesAdded", this);    
		AwareApp.registerListener ("referencesDeleted", this);    	    
	},

	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("objectsDeleted",    this);
		AwareApp.deregisterListener ("formSaved",    this);
		AwareApp.deregisterListener ("objectUpdated", this);
		AwareApp.deregisterListener ("processFinished", this);
		AwareApp.deregisterListener ("processCancelled", this);
		AwareApp.deregisterListener ("referencesAdded", this);    
		AwareApp.deregisterListener ("referencesDeleted", this);
		
		if (this.m_actionSheetId)
		{
			this.getActionSheetWidget().destroy ();
			$("#" + this.m_actionSheetId).remove ();
			
			this.m_actionSheetId = null;
		}

		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	getListViewMarkup: function (template)
	{
		var ulElem = $("<ul>").attr ("id", this.m_listViewId);
		
		return $('<div />').append(ulElem).html();
	},
	
	parseFilter: function (mainNode)
	{
		var fasNodes = mainNode.getElementsByTagName ("filter_attributes");
		if (! fasNodes || fasNodes.length == 0)
			return null;
		
		var fasNode = fasNodes[0];
		var loc = getAttributeValue (fasNode, "location", "top");
		
		var faNodes = fasNode.getElementsByTagName ("filter_attribute");
		if (! faNodes || faNodes.length == 0)
			return null;

		var faNode = faNodes[0];
		var c = { 
			attrName: getAttributeValue (faNode, "name", null)
		};
		
		var emptyText = getBooleanValue (faNode, "empty_text", false);	
		var title = getAttributeValue (faNode, "title", null);
		if (emptyText && title)
			c.emptyText = title;
		
		return c;
	},
	
	getWidgetConfig: function (template, dataSource, filter)
	{
		var widgetConfig = {
			template:   template.body,
			dataSource: dataSource
		};
		if (template.loadMore === true)
		{
			widgetConfig.loadMore = true;
		}
		else if (! template.loadAll)
		{
			widgetConfig.endlessScroll = true;
		}
		if (template.groupTemplate)
		{
			widgetConfig.headerTemplate = template.groupTemplate;
		}
		if (template.fixedHeaders === true)
		{
			widgetConfig.fixedHeaders = true;
		}
		
		if (filter)
		{
			widgetConfig.filterable = {
				field: filter.attrName,
				autoFilter: false,
				placeholder: filter.emptyText
			};
		}
		
		return widgetConfig;
	},
	
	getFields: function (dtNode)
	{
		var fields = {};
		fields ["BAS_REF_VALUE"] = { field: "BAS_REF_VALUE/text()" };
		
		fields ["BAS_OPER_APPLICABILITY"] = { field: "BAS_OPER_APPLICABILITY/text()" };
		
		var cNodes = dtNode.getElementsByTagName ("column");
		if (cNodes)
		{
			for (var i = 0; i < cNodes.length; ++ i)
			{
				var name = getAttributeValue (cNodes [i], "name", null);
				if (name)
					fields [name] = { field: name + "/text()" };
			}
		}
		
		return fields;
	},
	
	getDataSourceConfig: function (mainNode, fields, template)
	{
		if (this.m_previewMode)
		{
			return this.getPreviewStore (mainNode, fields, this.m_itemsPerPage);
		}
		
		var me = this;
		var dsConfig = {
			transport:       this.getTransport (template),
            schema:          this.getSchema (fields),
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true,
            pageSize:        this.m_itemsPerPage
		};
		
		if (template.groupAttr)
		{
			dsConfig.group = { field: template.groupAttr };
		}
		
		// this seems to be the only way we can attach handlers
		dsConfig.change = function ()
		{
        	setTimeout (function () {
        		me.afterStoreLoad ();
        	}, 1000);				
		}
		
		return dsConfig;
	},
		
	getSchema: function (fields)
	{
		var me = this;
        return {
        	type:  "xml",
        	data:  "/root/run_query_action_return/run_query_action_success/dataset/row",
        	total: "/root/run_query_action_return/run_query_action_success/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields
            },
            errors : "/root/run_query_action_return/failure/text()",
            parse: function (response)
            {
            	return me.preprocessResponse (response);
            }
        };
	},
	
	getTransport: function (template)
	{
		var params = { 
			actionType:   'run_query_action', 
			query_string: this.m_queryStr
		};    	
		if (this.m_queryName)
		{
			params.query_name = this.m_queryName;
		}
		if (this.m_refAttrName)
		{
			params.ref_attr_name      = this.m_refAttrName;
			params.ref_owner_name     = this.m_refOwnerName;
			params.ref_owner_id       = this.m_refOwnerId;
			params.form_name          = this.m_formName;
			params.section_name       = this.m_sectionName;
		}

		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}
		
		if (template.loadAll === "true")
		{
			params.force_all = "true";   // will force return of all instances
		}

		var t = AwareApp.createAwareTransport (params);
		var me = this;
		t.parameterMap = function (data, type)
		{
			return me.encodeDataSourceData (data, type);
		}
		
		return t;
	},
	
	encodeDataSourceData: function (data, operType)
	{
		var map = {};
		for (var param in data)
		{
			this.encodeStandardDataParam (map, data, param, operType);
		}
		
		// add filters
		this.addFiltersToParams (map);
		
		if (! this.m_previewMode)
			this.postDataEncode (data, operType, map);
		
		return map;
	},
	
	encodeStandardDataParam: function (map, data, param, operType)
	{
		if (param == "page")
		{
			var page = data [param];
			
			// encode as "start" range
			this.m_curStart = this.m_itemsPerPage * (page - 1);
			map.start = this.m_curStart;
		}
		else 
		{
			if (this.m_curSortAttr && ! map.sort)
			{
				map.sort = this.m_curSortAttr;
				map.dir  = this.m_curSortOrder;
			}
			
			map[param] = data[param];
		}						
	},
	
	parseDataTemplate: function (dtNode, mainNode)
	{
		var tdNodes = dtNode.getElementsByTagName ("template_def");
		if (tdNodes == null || tdNodes.length == 0)
			return null;
			
		var tdNode = tdNodes [0];
		
		this.m_loadAll = getBooleanValue (tdNode, "load_all", false);
		
		var body = "";
		var bNodes = tdNode.getElementsByTagName ("body");
		if (bNodes && bNodes.length > 0)
		{
			body = getTextNodeValue (bNodes [0]);
			body = body.replace (/@/g, "#");
			
			// add checkboxes for selection
			if (this.m_loadAll && this.m_multiSelect)
			{
				this.m_hasCheckboxes = true;
				
				var cb = "<input class='k-checkbox' id='#:BAS_REF_VALUE#' type='checkbox'><label class='k-checkbox-label' for='#:BAS_REF_VALUE#'></label>";
				body = cb + body;
			}
			
			if (this.m_itemOpers && this.m_itemOpers.length > 0)
			{
				var buttonImgSrc = getAttributeValue (mainNode, "iomb_image_path", null);
				var buttonImgCls = getAttributeValue (mainNode, "iomb_image_cls", null);
				if (! buttonImgSrc && ! buttonImgCls)
				{
					var dc = AwareApp.DefaultIcons.getConfig ("query", "custom_mobile_button");
					buttonImgCls = dc.iconCls;
				}
				
				var b = AwareApp.renderLink (null, buttonImgCls, buttonImgSrc, null, [ { attr: "class", value: "aw-mobile-lvb km-primary km-icon-button km-button"}], false);
				body = b + body;
			}
		}
		
		var groupTempl = getAttributeValue(tdNode, "group_template", null);
		if (groupTempl)
		{
			groupTempl = groupTempl.replace (/{/g, "#=").replace (/}/g, "#");			
		}
		
		return { 
			body:          body,
			loadMore:      getBooleanValue  (tdNode, "load_more", false),
			loadAll:       this.m_loadAll,
			fixedHeaders:  getBooleanValue  (tdNode, "fixed_headers", false),
			groupAttr:     getAttributeValue(tdNode, "group_attr", null),
			groupTemplate: groupTempl
		};
	},
	
	getWidget: function ()
	{
		return $("#" + this.m_listViewId).data("kendoMobileListView");		
	},
	
	afterRender: function ()
	{
		// Without setting parent's class to km-view the scroller doesn't work. The rest may or may not be important
		// doing it for the sake of consistency with how mobileDrawer does it (it automatically includes the scroller)
		$("#" + this.m_widgetId).addClass ("km-content").attr("data-role", "content").parent ().addClass ("km-view");
		
		if (this.m_renderScript)
		{
			var widget = this.getWidget ();
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for custom mobile query " + this.getQueryName () + " " + e);
			}
		}
	},
	
	afterStoreLoad: function ()
	{
		// attach even handlers to links
		if (this.m_itemOpers)
		{
			var me = this;
			$("#" + this.m_listViewId).find (".aw-mobile-lvb").click (function () {
				me.onOperationButtonClick ($(this));
			});
		}
	},
	
	onOperationButtonClick: function (link)
	{
		// find the item that was clicked by its uid (in the parent)
		var uid  = link.parent ().attr ("data-uid");
		if (! uid)
			return;
		
		var record = this.m_dataSource.getByUid (uid);
		if (! record)
			return;
		
		if (this.m_itemOpers.length == 1 && this.m_itemOpers[0].isDefault)
		{
			this.runItemOperation (this.m_itemOpers[0], record);
		}
		else
		{
			this.showActionSheet (record);
		}
	},
	
	showActionSheet: function (record)
	{
		this.m_selRecord = record;
		if (! this.m_actionSheetId)
		{
			this.m_actionSheetId = this.m_listViewId + "_ast";
			this.createActionSheet (this.m_actionSheetId);
		}
		
		this.getActionSheetWidget ().open ();
	},
	
	getActionSheetWidget: function ()
	{
		return $("#" + this.m_actionSheetId).data ("kendoMobileActionSheet");
	},
	
	createActionSheet: function (id)
	{
		var ul = $("<ul>").attr ("id", id);
		for (var i = 0; i < this.m_itemOpers.length; ++ i)
		{
			var oper = this.m_itemOpers[i];
			var li = $("<li>").attr ("id", id + "_" + i);
			var a = $("<a>").html (oper.operName);
			li.append (a);
			
			ul.append (li);
		}
		
		$(document.body).append (ul);

		var me = this;
		var wc = {
			cancel:  AwareApp.Locale["CE_Cancel"],
			command: function (o) {
				me.onActionSheetClick (o);
			}
		};
		$("#" + id).kendoMobileActionSheet (wc);
	},
	
	onActionSheetClick: function (o)
	{
		if (! this.m_selRecord)
			return;
		
		var t = $(o.currentTarget);
		var id = t.attr ("id");
		if (! id)
			id = t.parent ().attr ("id");

		if (! id)
		{
			console.log ("Unknown target clicked " + o.currentTarget);
			return;
		}
		
		var idx = id.lastIndexOf ("_");
		var i = parseInt (id.substring (idx + 1));
		this.runItemOperation (this.m_itemOpers [i], this.m_selRecord);		
	},
	
	preprocessResponse: function (response)
	{
		var qsNodes = response.getElementsByTagName ("query_string");
		if (qsNodes && qsNodes.length > 0)
		{
			this.setQueryString (getTextNodeValue (qsNodes [0]));
		}
		
		AwareApp_BaseParser.fn.preprocessResponse.call (this, response);
		return response;
	},
	
	getContextForOperation: function (oper)
	{
		var selection = null;
		if (this.m_hasCheckboxes)
		{
			selection = new Array ();
			var cbs = $("#" + this.m_widgetId).find (".k-checkbox");
			for (var i = 0; i < cbs.length; ++ i)
			{
				var cb = cbs [i];
				if (cb.checked)
				{
					var refValue = $(cb).attr ("id");
					if (refValue)
						selection.push (getObjectReference (refValue));
				}
			}
		}
		
		return oper.operType == "delete_object" ? selection : this.addContext (selection);
	},
	
	runItemOperation: function (oper, record)
	{
		var selection = null;
		if (record)
		{
			selection = new Array ();
			if (! operationApplicable (record, oper.operName))
			{
		        var config = {
	                title:  AwareApp.Locale["C_Error"],
	                msg:    AwareApp.Locale["C_TreeOperApp"],
	                btnOK:  true
	            };
	            	
	     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
				return;
			}
				
			selection.push (getObjectReference (record.id));
		}
		
		selection = this.addContext (selection);

		this.runOperation (selection, oper);
	},
	
	doSort: function (sortAttrName, sortOrder)
	{
		if (sortAttrName)
		{
			if (sortAttrName == "[cancel]")
			{
				this.m_curSortAttr  = null;
				this.m_curSortOrder = null;
			}
			else
			{
				this.m_curSortAttr  = sortAttrName;
				this.m_curSortOrder = (sortOrder ? sortOrder : "asc");
			}
			
			this.refreshData ();
		}		
	},
	
	getEditObjectQueryCtx: function (selection)
	{
		var queryCtx = null;
		if (selection && selection.length > 0)
		{
			var ds = this.m_dataSource;
			var selRecord = ds.get (selection[0].objectName + ":" + selection[0].objectId);
			
			if (selRecord)
			{
				queryCtx = {
					queryString: this.m_queryStr,
					curIdx:      ds.indexOf (selRecord) + (this.m_curStart ? this.m_curStart : 0),
					total:       ds.total (),
					context:     this.getQueryContext ()
				};
			}
		}
		
		return queryCtx;
	},
	
	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_CustomMobileParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	// Interface method to handle events
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "referencesAdded" || eventName == "referencesDeleted")
		{
			if (eventInfo && this.m_refOwnerName && eventInfo.refOwnerName == this.m_refOwnerName &&
				this.m_refOwnerId == eventInfo.refOwnerId && this.m_refAttrName == eventInfo.refAttrName)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processFinished")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				// our process has finished - refresh the grid
				if (this.m_ourProcess.noRefresh !== true)
					this.refreshData ();
				
				this.m_ourProcess = null;
			}
			else if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processCancelled")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				this.m_ourProcess = null;
			}
		}
	}	
});

