var AwareApp_GanttParser = AwareApp_BaseParser.extend(
{
	init: function (xmlDoc, inWindow)
	{
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);
	},

	// used in preview framework
	reset: function ()
	{
		this.m_tools = null;
		this.m_toolbars = null;
		this.m_panelHeader = null;
		this.m_panelOpers = null;
		this.m_extParams = null;
		
		this.init (this.m_xmlDoc, false);
	},
	
	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName ("gantt_layout");
		if (! mainNodes || mainNodes.length != 1)
			return null;
			
		var mainNode = mainNodes [0];
		
		var gdNodes = mainNode.getElementsByTagName ("gantt_data");
		if (! gdNodes || gdNodes.length != 1)
			return null;
		
		var gdNode = gdNodes [0];

		this.m_queryName       = getAttributeValue (mainNode, "query_name",     null);
		this.m_queryOnName     = getAttributeValue (mainNode, "query_on_name",  null);
		this.m_isGroupName     = getBooleanValue   (mainNode, "is_group_name",  false);
		this.m_refreshProcs    = getAttributeValue (mainNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (mainNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue   (mainNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue (mainNode, "refresh_impl_proc", null);
		this.m_taskDateFormat  = getAttributeValue (mainNode, "date_format",    null);
		var showToday          = getBooleanValue   (gdNode,   "show_today",     false);
		var hasAssignments     = getBooleanValue   (gdNode,   "supports_assignments", false);
		var defaultTip         = getBooleanValue   (gdNode,   "default_tip",    true);
		var panelWidth         = getIntegerValue   (mainNode, "panel_width",    null);
		var panelHeight        = getAttributeValue (mainNode, "panel_height",   null);
		if (panelHeight && panelHeight == "Align")
			this.m_alignToBottom = true;
		else
			this.m_panelHeight = panelHeight;

		if (! this.m_previewMode)
			this.m_previewMode = getBooleanValue (mainNode, "preview_mode", false);
		
		this.m_objectRefNodes = mainNode.getElementsByTagName ("object_reference");
		
		var queryStrNodes = mainNode.getElementsByTagName ("query_string");
		if (! queryStrNodes || queryStrNodes.length != 1)
			return null;
		
		this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		
		this.m_dateFormat = getAttributeValue (mainNode, "date_format", "MM/dd/yyyy");
		
		var tipConfig = this.getTipConfig (gdNode, defaultTip);
		
		var columns = new Array (), extraFields = new Array ();
		this.getColumns(mainNode, columns, extraFields);
		
		this.addTipAttributes (mainNode, extraFields);
		
		var rn = mainNode.getElementsByTagName ("resizing_options");
		if (rn && rn.length > 0)
			this.m_resizingNode = rn [0];
		
		var rsn = mainNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		
		if (this.m_isGroupName)
			this.getGroupMembers (mainNode);
		
		var taskDataSourceConfig = this.getTaskDataSourceConfig (extraFields);
		var depDataSourceConfig  = this.getDependencyDataSourceConfig ();
		
		this.m_itemOpers = this.getItemOperations (mainNode);
		
		this.m_widgetId = "AW_GANTT_" + Math.floor (Math.random () * 100001);
		
		var panelConfig = this.getPanelConfig (mainNode, this.m_widgetId, "gantt");	

    	var widgets = new Array ();
    	
		if (this.m_itemOpers && this.m_itemOpers.length > 0)
		{
			panelConfig.bodyContent = this.prepareContextMenu (this.m_itemOpers, this.m_widgetId, widgets);
		}
		
		this.m_panel = new AwareApp_Panel (panelConfig);
		
		var wc = {
			dataSource:   taskDataSourceConfig,
			dependencies: depDataSourceConfig,
			columns:      columns,
			editable:     false,
			resizable:    true,
			toolbar:      [],
			views:        this.setupViews (gdNode)
		};
		if (hasAssignments)
		{
			wc.assignments = this.getAssignmentsConfig ();
			wc.resources   = this.getResourcesConfig();
		}
		if (this.m_panelHeight)
		{
			wc.height = this.m_panelHeight;
		}
		if (! showToday)
		{
			wc.currentTimeMarker = false;
		}
		if (tipConfig)
		{
			wc.tooltip = tipConfig;
		}
		if (this.findOperationByType (this.m_panelOpers, "export_pdf"))
		{
			wc.toolbar = [ "pdf" ];
		}
		
		this.setupEvents (wc);
		
		if (this.m_showSaveSettingsButton)
		{
			this.setState (wc);
		}
		
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "gantt",
    		id:     this.m_widgetId,
    		config: wc
    	});
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
   	
		if (this.m_resizingNode)
		{
			this.addResizeWidgets (this.m_resizingNode, panelMarkup, widgets);
		}
		
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		this.runInitScript (mainNode, wc, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;        
	},
	
	getWidget: function ()
	{
		return $("#" + this.m_widgetId).data("kendoGantt");		
	},
	
	setupEvents: function (wc)
	{
		var me = this;
		wc.dataBound = function (e)
		{
			me.afterStoreLoad (e, this);
		}
	},
	
	setupViews: function (gdNode)
	{
		var viewNodes = gdNode.getElementsByTagName ("gantt_view");
		if (! viewNodes || viewNodes.length == 0)
			return [ "week", { type: "month", selected: true}, "year" ];
		
		var views = new Array ();
		for (var i = 0; i < viewNodes.length; ++ i)
		{
			var node = viewNodes[i];
			var v = {
				type:     getAttributeValue (node, "type", "month"),
				selected: getBooleanValue (node, "is_default", false)
			}
			
			var tf = getAttributeValue (node, "time_format", null);
			if (tf)
			{
				v.timeHeaderTemplate = "#=kendo.toString(start, '" + toKendoDateFormat (tf) + "')#";
			}
			
			var df = getAttributeValue (node, "day_format", null);
			if (df)
			{
				v.dayHeaderTemplate = "#=kendo.toString(start, '" + toKendoDateFormat (df) + "')#";
			}
			
			var mf = getAttributeValue (node, "month_format", null);
			if (mf)
			{
				v.monthHeaderTemplate = "#=kendo.toString(start, '" + toKendoDateFormat (mf) + "')#";
			}
			
			var wf = getAttributeValue (node, "week_format", null);
			if (wf)
			{
				v.weekHeaderTemplate = "#=kendo.toString(start, '" + toKendoDateFormat (wf) + "')#";
			}
			
			var yf = getAttributeValue (node, "year_format", null);
			if (yf)
			{
				v.yearHeaderTemplate = "#=kendo.toString(start, '" + toKendoDateFormat (yf) + "')#";
			}
			
			views.push (v);
		}
		
		return views;
	},
	
	registerListeners: function ()
	{	
	    AwareApp.registerListener ("objectsDeleted",           this);
	    AwareApp.registerListener ("formSaved",                this);
		AwareApp.registerListener ("objectUpdated",            this);
	    AwareApp.registerListener ("processFinished",          this);
	},
	
	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("objectsDeleted",           this);
		AwareApp.deregisterListener ("formSaved",                this);
		AwareApp.deregisterListener ("objectUpdated",            this);
		AwareApp.deregisterListener ("processFinished",          this);
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},

	addField: function (fieldName, fields, editable)
	{
		fields [fieldName] = { field: fieldName + "/text()", editable: editable };
	},
	
	getTaskParams: function (dependenciesOnly, assignmentsOnly)
	{
		var params = { 
			actionType:        'get_gantt_data_action', 
			query_name:        this.m_queryName,
			query_string:      this.m_queryStr, 
			assignments_only:  assignmentsOnly,
			dependencies_only: dependenciesOnly
		};    	
		
		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}	
		
		return params;
	},
	
	getTaskDataSourceConfig: function (extraFields)
	{
		if (this.m_previewMode === true)
			return [];
		
		var fields = {};
		this.addField ("BAS_OPER_APPLICABILITY", fields, false);
		this.addField ("bas_style", fields, false);
		
        fields.id =              { field: "BAS_REF_VALUE/text()", editable: false };
        fields.title =           { field: "Subject/text()", defaultValue: "No title", validation: { required: true } };
        fields.start =           { field: "StartTime/text()", type: "date",  validation: { required: true}};
        fields.end =             { field: "EndTime/text()", type: "date",  validation: { required: true}};
        fields.parentId =        { field: "bas_parentId/text()", editable: false };
        fields.percentComplete = { field: "PercentDone/text()", type: "number" };
        fields.orderId =         { field: "bas_orderId/text()", type: "number" };
        fields.summary =         { field: "bas_hasChildren/text()", type: "boolean" };
        fields.expanded =        { field: "bas_expanded/text()", type: "boolean", defaultValue: true };
         
        // add custom fields from columns
        for (var i = 0; i < extraFields.length; ++ i)
        {
        	fieldName = extraFields [i];
        	this.addField (fieldName, fields, true);
        }
        
		return {
			transport:       AwareApp.createAwareTransport (this.getTaskParams (false, false)),
            schema: {
            	type:  "xml",
            	data:  "/root/get_gantt_data_action_return/Tasks/Task",
            	model: {
            		id:     "id",
            		fields: fields
            	},
            	errors : "/get_gantt_data_action_return/failure/text()",
            },
            batch:           true,
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true,
            serverGrouping:  false,
            error: function (e)
            {
           		alert (e.errors ? e.errors : e.errorThrown);
            }
		};
	},
	
	getDependencyDataSourceConfig: function ()
	{
		if (this.m_previewMode === true)
			return [];
		
		var fields = {};
		
        fields.id =              { field: "BAS_REF_VALUE/text()" };
        fields.predecessorId =   { field: "From/text()" };
        fields.successorId =     { field: "To/text()" };
        fields.type =            { field: "Type/text()" };
        
		return {
			transport:       AwareApp.createAwareTransport (this.getTaskParams (true, false)),
            schema: {
            	type:  "xml",
            	data:  "/root/get_gantt_data_action_return/Links/Link",
            	model: {
            		id:     "id",
            		fields: fields
            	}
            },
            errors : "/get_gantt_data_action_return/failure/text()",
            batch:           true,
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true,
            serverGrouping:  false,
            error: function (e)
            {
            		alert (e.errors ? e.errors : e.errorThrown);
            }
		};
	},
	
	getAssignmentsConfig: function ()
	{
		if (this.m_previewMode === true)
			return [];
		
		var fields = {};
		
        fields.id =         { field: "BAS_REF_VALUE/text()" };
        fields.resourceId = { field: "ResourceId/text()" };
        fields.taskId =     { field: "TaskId/text()" };
        fields.units =      { field: "Units/text()", type: "number" };
        
		var ds = {
			transport:       AwareApp.createAwareTransport (this.getTaskParams (false, true)),
            schema: {
            	type:  "xml",
            	data:  "/root/get_gantt_data_action_return/Assignments/Assignment",
            	model: {
            		id:     "id",
            		fields: fields
            	}
            },
            errors : "/get_gantt_data_action_return/failure/text()",
            serverPaging:    true,
            serverSorting:   true,
            serverGrouping:  false,
            error: function (e)
            {
           		alert (e.errors ? e.errors : e.errorThrown);
            }
		};
		
		return {
			dataSource: ds,
            dataTaskIdField:     "taskId",
            dataResourceIdField: "resourceId",
            dataValueField:      "units"		
		};
	},

	getResourcesConfig: function ()
	{
		if (this.m_previewMode === true)
			return [];
		
		var fields = {};
		
        fields.id =         { field: "BAS_REF_VALUE/text()" };
        fields.Name =       { field: "Name/text()" };
        
		var ds = {
			transport:       AwareApp.createAwareTransport (this.getTaskParams (false, true)),
            schema: {
            	type:  "xml",
            	data:  "/root/get_gantt_data_action_return/Resources/Resource",
            	model: {
            		id:     "id",
            		fields: fields
            	}
            },
            errors : "/get_gantt_data_action_return/failure/text()",
            serverPaging:    true,
            serverSorting:   true,
            serverGrouping:  false,
            error: function (e)
            {
           		alert (e.errors ? e.errors : e.errorThrown);
            }
		};
		
		return {
			dataSource: ds,
            dataTextField: "Name"
		};
	},
	
	afterRender: function ()
	{
		// Kendo bug? For some reason Gantt comes out with the collapsed list, so set the default width (listWidth) of 30%
      	$("#" + this.m_widgetId).find (".k-gantt-treelist").width ("30%");
      	
     	var gantt = this.getWidget ();
        
		if (this.m_renderScript)
		{
			var widget = gantt;
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for Gantt " + this.getQueryName () + " " + e);
			}
		}
		
		if (this.m_alignToBottom)
		{
			this.alignToBottom ();
		}
		else if (! this.m_panelHeight)
		{
			this.resizeToEnclosing ();
		}
	},
	
	resizeToEnclosing: function ()
	{
		var p = this.getResizeToEnclosingPanel ();
		if (p)
		{
			var ep = p.panel;
			
			var widget = this.getWidget();
			var h = ep.height ();
			var wrapperEl = $("#" + this.m_widgetInfo.wrapperId),
				dataArea = widget.element,
				otherElements = wrapperEl.children(),
				otherElementsHeight = 0;
			
			otherElements.each(function() {
				otherElementsHeight += $(this).outerHeight();
			});
			
			dataArea.height(h - otherElementsHeight + d.innerHeight () - 1 /* rounding */);
			
			widget.resize ();  // need to resize internal areas
		}	
	},
	
	doAlignToBottom: function (params)
	{
		// Align to the bottom of the screen determined by the edge of the enclosing frame
		var frame = $("#" + params.frameId);
		if (frame && frame.length > 0)
		{
			var widget = this.getWidget ();
			var dataArea = widget.element;
			
			dataArea.height (frame.offset ().top + frame.innerHeight() - dataArea.offset().top - params.margin);
			widget.resize ();
		}	
	},
	
	prepareContextMenu: function (itemOpers, widgetId, widgets)
	{
		var id = widgetId + "_cm";
		
		var items = new Array ();
		for (var i = 0; i < itemOpers.length; ++ i)
		{
			var oper = itemOpers[i];			
			var b = this.getOperationButton (oper, false);
			if (b)
				items.push (b);
		}
		
		var me = this;
		widgets.push ({
			type: "contextmenu",
			id:   id,
			config: {
				target: "#" + widgetId,
				dataSource: items,
		        filter: ".k-task",
                select: function(e) {
                	e.preventDefault ();
                	me.onContextMenu ($(e.item), $(e.target));
                }
			}
		});
		
		return "<ul id='" + id + "'></ul>";
	},
	
	onContextMenu: function (menuItem, selItem)
	{
		var gantt = this.getWidget ();
		
		var text = menuItem.text ();
		for (var i = 0; i < this.m_itemOpers.length; ++ i)
		{
			var oper = this.m_itemOpers[i];
			if (oper.operName == text)
			{
				var taskRecord = gantt.dataSource.getByUid($(selItem).attr("data-uid"));
				this.runItemOperation(oper, taskRecord);
				break;
			}
		}
	},
	
	getColumns: function (mainNode, columns, extraFields)
	{
		var colNodes = mainNode.getElementsByTagName ("column_description");
		if (colNodes)
		{
			for (var i = 0; i < colNodes.length; ++ i)
			{
				var colNode = colNodes[i];
				
				var attrNodes = colNode.getElementsByTagName ("attribute_column_description");
				if (attrNodes && attrNodes.length > 0)
				{
					var attrNode  = attrNodes [0];
					var dataIndex = getAttributeValue (attrNode, "dataIndex", null);
					var field     = dataIndex;
					if (dataIndex == "Subject")
						field = "title";
					else if (dataIndex == "StartTime")
						field = "start";
					else if (dataIndex == "EndTime")
						field = "end";
					else
						extraFields.push (field);
					
					var format = getAttributeValue (attrNode, "format", null);
					var c = { 
						field:  field, 
						title:  getAttributeValue (attrNode, "title", "")
					};
					if (format)
						c.format = "{0:" + format + "}";
					
					var w = getAttributeValue (attrNode, "width", null);					
					if (w && w.indexOf ("%") < 0)
						c.width = parseInt (w);
					
					columns.push (c);
				}
			}
		}
	},
	
	getTipConfig: function (gdNode, defaultTip)
	{
		if (defaultTip)
			return null;
		
		var tipTemplate = null;
		var ttNodes = getFirstLevelChildNodes (gdNode, "tip_template");
		if (ttNodes && ttNodes.length > 0)
		{
			tipTemplate = getTextNodeValue (ttNodes [0]);
			if (this.m_taskDateFormat)
			{
				tipTemplate = tipTemplate.replace (/#/g,            "\\#");
				tipTemplate = tipTemplate.replace (/{StartTime}/g,  "#=kendo.toString(task.start,'" + this.m_taskDateFormat + "')#");
				tipTemplate = tipTemplate.replace (/{EndTime}/g,    "#=kendo.toString(task.end,'" + this.m_taskDateFormat + "')#");
				tipTemplate = tipTemplate.replace (/{Subject}/g,    "#=task.title#");
				tipTemplate = tipTemplate.replace (/PercentDone/g,  "percentComplete");
				tipTemplate = tipTemplate.replace (/{/g,            "#=task.");
				tipTemplate = tipTemplate.replace (/}/g,            "#");
			}
		}
		
		return tipTemplate ? { template: tipTemplate } : { visible: false };
	},
	
	addTipAttributes: function (mainNode, extraFields)
	{
		var tnodes = mainNode.getElementsByTagName ("tip_attributes");
		if (tnodes && tnodes.length > 0)
		{
			var tn = tnodes[0];
			var attrNamesStr = getAttributeValue (tn, "attrNames", null);
			if (attrNamesStr)
			{
				var attrNames = attrNamesStr.split (",");
				for (var i = 0; i < attrNames.length; ++ i)
					extraFields.push (attrNames[i]);
			}
		}
	},
	
	afterStoreLoad: function (e, gantt)
	{
		// This is picked up in Kendo How To
		gantt.element.find(".k-task").each(function(e) {
			var taskRecord = gantt.dataSource.getByUid($(this).attr("data-uid"));

			var style = taskRecord.get ("bas_style");
            if (style)
            {
            	var existing = $(this).attr ("style");
            	$(this).attr ("style", existing ? existing + ";" + style : style);
            }
        });
		
		if (this.m_defaultOper)
		{
			// I don't fully understand it but apparently this only needs to be done once, otherwise event handlers will keep accumulating. Maybe Kendo UI
			// does not regenerate the element after store load (although it seems that it does)
			if (! this.m_defaultOperSet)
			{
				this.m_defaultOperSet = true;
				
				var me = this;
				gantt.element.find (".k-task").on ("click", function (e) {
					e.preventDefault();
					var taskRecord = gantt.dataSource.getByUid($(this).attr("data-uid"));
					me.onTaskClick (taskRecord);
				});
			}
		}
	},

	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_GanttParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "processFinished")
		{
			if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				// the process has been explicitly mentioned in refresh processes
				this.refreshData ();
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (this.ourObject (eventInfo.objectName) || containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
	},
	
	refreshData: function ()
	{
		// do not refresh if Gantt is part of a collapsed row in an expansion - it will not be redrawn correctly
		var expandElem = $("#" + this.m_widgetId).closest ("[id^=" + AwareApp.strExpansionPrefix + "]");
		if (expandElem.length > 0)
		{
			var dr = expandElem.closest (".k-detail-row");
			if (dr.length > 0 && dr.css ("display") == "none")
				return;
		}
		
		AwareApp_BaseParser.fn.refreshData.call (this);
	},
	
	onTaskClick: function (taskRecord)
	{
		this.runItemOperation (this.m_defaultOper, taskRecord);
	},
    
	runItemOperation: function (operation, taskRecord)
	{
		if (taskRecord && ! operationApplicable (taskRecord, operation.operName))
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_SchedOperApplicable"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return;
		}
		
		var selection = new Array ();		
		if (taskRecord)
		{
			selection.push (getObjectReference (taskRecord.id));
		}
		
		selection = this.addContext (selection);
		this.runOperation (selection, operation);
	},
	
	getContextForOperation: function (oper)
	{
		return this.addContext (null);
	},
	
	ourObject: function (objectName)
	{
		if (this.m_isGroupName)
		{
			if (this.m_groupMembers)
			{
				for (var i = 0, len = this.m_groupMembers [i].length; i < len; ++ i)
				{
					if (this.m_groupMembers [i] == objectName)
						return true;
				}
			}
			
			return false;
		}
		else
		{
			return objectName == this.m_queryOnName;
		}
	},
	
	getGroupMembers: function (mainNode)
	{
		var nodes = mainNode.getElementsByTagName ("group_member");
		if (nodes && nodes.length > 0)
		{
			this.m_groupMembers = new Array ();
			for (var i = 0, len = nodes.length; i < len; ++ i)
			{
				var name = getAttributeValue (nodes [i], "name", null);
				if (name)
					this.m_groupMembers.push (name);
			}
		}
	}
});
