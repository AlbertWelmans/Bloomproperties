// This class parses XML document representing the layout of a reference tree (tree_layout)
var AwareApp_TreeGridParser = AwareApp_QueryLayoutParser.extend(
{
	strRefresh: "Reload the tree",
	
	init: function (xmlDoc)
	{
		AwareApp_QueryLayoutParser.call(this, xmlDoc, "dummy", false, null);

		this.m_expanded = false;
	},

	getMainNodeName: function ()
	{
		return "tree_layout";
	},
	
	getActionType: function ()
	{
		return "get_kendo_ref_tree_nodes_action";
	},
	
	getWidget: function ()
	{
		if (! this.m_widgetInfo)
			return null;
		
		return $("#" + this.m_widgetInfo.markupId).data("kendoTreeList");		
	},
	
	getSchema: function (fields)
	{
		var me = this;
        return {
        	type:  "xml",
        	data:  "/root/get_kendo_ref_tree_nodes_action_return/dataset/row",
        	total: "/root/get_kendo_ref_tree_nodes_action_return/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields
            },
            errors : "/root/get_kendo_ref_tree_nodes_action_return/failure/text()",
            parse: function (response)
            {
            	me.preprocessResponse (response);
            	return response;
            }
        };
	},
	
	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName (this.getMainNodeName());
		if (! mainNodes || mainNodes.length != 1)
			return null;
			
		var treeNode = mainNodes [0];
		
		this.m_expanded = getBooleanValue   (treeNode, "expanded",  false);
		
		return AwareApp_QueryLayoutParser.fn.parse.call (this);
	},
	
	getWidgetConfig: function (wc)
	{
		if (! wc.editable)
		{
			wc.editable = { move: true };
		}
		else
		{
			wc.editable.move = true;
		}
		
		var me = this;
		wc.dragStart = function (e)
		{
			me.onDragStart (e);
		};
		wc.drop = function (e)
		{
			me.onDrop (e);
		};
		
    	return {
	    	config: wc,
	    	type:   "treelist",
	    	id:     this.m_gridId 
    	};		
	},
	
	getEditingMode: function (rowEditor)
	{
		// only supports inline and popup
		return rowEditor ? "popup" : "inline";	
	},
	
	getNewRowIndex: function (grid)
	{
		// Tree list doesnt seem to support adding new row at bottom
		return 0;
	},
	
	getTransportParams: function ()
	{
		var params = AwareApp_QueryLayoutParser.fn.getTransportParams.call (this);
		params.from_tree = "true";
		
		return params;
	},
	
	setPaging: function (gridConfig, showPaging)
	{
		// paging not supported in this widget
	},
	
	setupSelectAllColumnTitle: function (selCol)
	{
		// setting the title doesn't work here
	},
	
	buildColumns: function (mainNode, fields, columns)
	{
		AwareApp_QueryLayoutParser.fn.buildColumns.call (this, mainNode, fields, columns);
		
		this.addSpecialField ("bas_ownerRefAttrName", fields);
		this.addSpecialField ("bas_ownerName", fields);
		this.addSpecialField ("bas_ownerId", fields);
		this.addSpecialField ("bas_childRefAttrName", fields);
		this.addSpecialField ("bas_childReferredName", fields);
		this.addSpecialField ("bas_childReferredIsGroup", fields);
		this.addSpecialField ("bas_acceptsDropOf", fields);
		this.addSpecialField ("bas_allowDrag", fields);
		
		// defaultValue here is essential - this is how the server marks null parentId
		fields.parentId = { field: "bas_parentId/text()", nullable: false, defaultValue: "-1" };
		fields.hasChildren = { field: "bas_hasChildren/text()", type: "boolean", nullable: false };
		
		// mark the first "field" column as expandable
		for (var i = 0; i < columns.length; ++ i)
		{
			if (columns[i].field)
			{
				columns[i].expandable = true;
				break;
			}
		}
	},
	
	onTableClick: function (target, grid)
	{	
		var t = $(target);
		if (t.hasClass ("k-i-collapse") || t.hasClass ("k-i-expand") || t.hasClass ("k-i-none"))
		{
			return;  // this is tree collapse/expand icon
		}
		
		AwareApp_QueryLayoutParser.fn.onTableClick.call (this, target, grid);
	},
		
	onDragStart: function (e)
	{
        var record = e.source;
        /*
		if (this.m_dragDrop)
		{
	        if (! this.m_dragDrop.canHandleRecords ([record]))
	        	e.preventDefault ();	
		}
		else
		*/
		{
			var allowDrag = record.get ("bas_allowDrag");
			if (allowDrag == "false")
				e.preventDefault ();
		}
	},
	
	onDrop: function (e)
	{
		var srcRecord    = e.source;
		var parentRecord = e.destination;
		var ds           = e.sender.dataSource;
		
		var parentRefAttrName = null;
		if (e.position != "over")
		{
			// use parent of the destRecord
			parentRefAttrName = parentRecord.get ("bas_ownerRefAttrName");
			parentRecord = ds.parentNode (parentRecord);
		}
		else
		{
			parentRefAttrName = parentRecord.get ("bas_childRefAttrName");
			if (! parentRefAttrName && parentRecord.children && parentRecord.children.at)
			{
				// try the first child
				var childRecord = parentRecord.children.at (0);
				if (childRecord)
					parentRefAttrName = childRecord.get ("bas_ownerRefAttrName");
			}
		}
		
		if (! AwareApp_DragDrop.prototype.allowDrop (srcRecord, parentRecord, parentRefAttrName))
		{
			e.setValid (false); 
			//e.preventDefault ();
		}
		else
		{
			AwareApp_DragDrop.prototype.performDrop (srcRecord, parentRecord, parentRefAttrName);
		}
	},
	
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "referencesAdded" || eventName == "referencesDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
		else
		{
			AwareApp_QueryLayoutParser.fn.handleEvent.call (this, eventName, eventInfo);
		}
	},
	
	setDragDrop: function (grid)
	{
		// TODO - cannot use Sortable
	},
	
	shouldIncludeInlineEditing: function (attrName)
	{
		// Need to preserve all special fields, so that the server returns them
		if (attrName.indexOf ("bas_") == 0 || attrName == "parentId" || attrName == "hasChildren")
			return true;
			
		var rc = AwareApp_QueryLayoutParser.fn.shouldIncludeInlineEditing.call (this, attrName);
		if (! rc)
			return false;
		
		return attrName != "expanded";
	},
	
	encodeInlineEditingValue: function (map, attrName, i, value, grid, culture)
	{
		var an = attrName;
		if (an == "parentId")
			an = "bas_parentId";
		if (an == "hasChildren")
			an = "bas_hasChildren";
			
		AwareApp_QueryLayoutParser.fn.encodeInlineEditingValue.call (this, map, an, i, value, grid, culture);
	},
		
	getRecordForId: function (id)
	{
		var data = this.getWidget ().dataSource.data ();
		for (var i = 0; i < data.length; ++ i)
		{
			if (data[i].id == id)
				return data[i];
		}
		
		return null;
	},
	
	getContextForOper: function ()
	{
		var refOwnerName = this.m_refOwnerName;
		var refAttrName  = this.m_refAttrName;
		var refOwnerId   = this.m_refOwnerId;
		var formName     = this.m_formName;
		var sectionName  = this.m_sectionName;
		
		var selection = this.getSelection (false);		
		if (selection && selection.length > 0)
		{
			var record = this.getRecordForId (selection[0].objectName + ":" + selection[0].objectId);
			if (record)
			{
				var childRefAttrName = record.get ("bas_childRefAttrName");
				if (childRefAttrName)
				{
					refOwnerName = selection[0].objectName;
					refAttrName  = childRefAttrName;
					refOwnerId   = selection[0].objectId;
					formName     = null;
					sectionName  = null;
				}
			}
		}
		return {
			refOwnerName: refOwnerName,
			refOwnerId:   refOwnerId,
			refAttrName:  refAttrName,
			formName:     formName,
			sectionName:  sectionName
		};
	},
	
	doAddReference: function (oper)
	{
		var ctx = this.getContextForOper ();
		var action = new AwareApp_AddReferenceLayoutAction (
							ctx.refOwnerName, 
							ctx.refAttrName, 
							ctx.refOwnerId, 
							ctx.formName, 
							ctx.sectionName,
							null, 
							oper,
							false,
							this);
		action.run ();
	},
	
	// override
	doAddNew: function ()
	{
		var action = new AwareApp_NewReferenceLayoutAction (
							objName,
							isGroupName, 
							this.m_refOwnerName, 
							this.m_refAttrName, 
							this.m_refOwnerId, 
							this.m_formName,
							this.m_sectionName,
							this);

		action.run ();
	},
	
	deleteAllReferences: function ()
	{
		if (! window.confirm (AwareApp.Locale["C_GridConfDelA"]))
			return;

		var ctx = this.getContextForOper ();
		var action = new AwareApp_DeleteReferencesAction (
							ctx.refOwnerName, 
							ctx.refOwnerId, 
							ctx.refAttrName, 
							null);
		action.run ();
	},
	
	doDeleteObject: function (objectName, objectId, rowIdx, oper)
	{
		if (! window.confirm (this.m_refOwnerName ? AwareApp.Locale["C_GridConfDelList"] : AwareApp.Locale["C_GridConfDel"]))
			return;
			
		this.m_pendingSave = { rowIdx: this.m_curEditedRowIdx, ctx: [ { objectName: objectName, objectId: objectId }] };		
		this.m_recalcAttrName = null;
		
		if (oper.operand && oper.operand == "true")
		{
			this.m_pendingSave.mode = "deleteObj";
		}
		else
		{
			var record = this.getRecordForId (objectName + ":" + objectId);
			if (record)
			{
				this.m_treeOperCtx = {
					refOwnerName: record.get ("bas_ownerName"),
					refAttrName:  record.get ("bas_ownerRefAttrName"),
					refOwnerId:   record.get ("bas_ownerId")
				}
			}
			
			this.m_pendingSave.mode = "deleteRefs";
		}
		
		// this will sync automatically
		var grid = this.getWidget ();
		grid.removeRow (this.getGridRow(grid, rowIdx));
	},
	
	encodeStandardDataParam: function (map, data, param, operType)
	{
		AwareApp_QueryLayoutParser.fn.encodeStandardDataParam.call (this, map, data, param, operType);
		
		if (this.m_treeOperCtx)
		{
			if (param == "ref_owner_name")
				map [param] = this.m_treeOperCtx.refOwnerName;
			else if (param == "ref_owner_id")
				map [param] = this.m_treeOperCtx.refOwnerId;
			else if (param == "ref_attr_name")
				map [param] = this.m_treeOperCtx.refAttrName;
		}
		else if (operType == "destroy" && this.m_pendingSave && this.m_pendingSave.mode == "deleteObj")
		{
			map.force_delete_object = "true";
		}
	},
	
	postDataEncode: function (data, operType, map)
	{
		this.m_treeOperCtx = null;
		
		if (this.m_inRefresh)
			map ["in_refresh"] = true;
	}
});

var AwareApp_MoveTreeNodeAction = AwareApp_ServerCallAction.extend(
{
	init: function (srcInstanceName, srcInstanceId, srcOwnerName, srcOwnerId, srcRefAttrName, destOwnerName, destOwnerId, destRefAttrName)
	{
		AwareApp_ServerCallAction.fn.init.call (this);

		this.m_srcInstanceName = srcInstanceName;
		this.m_srcInstanceId   = srcInstanceId;
		this.m_srcOwnerName    = srcOwnerName;
		this.m_srcOwnerId      = srcOwnerId;
		this.m_srcRefAttrName  = srcRefAttrName;
		this.m_destOwnerName   = destOwnerName;
		this.m_destOwnerId     = destOwnerId;
		this.m_destRefAttrName = destRefAttrName;
	},

	buildRequest: function ()
	{
		var s = "<move_tree_node_action src_instance_name=\"";
			s += this.m_srcInstanceName;
			s += "\" src_instance_id=\"";
			s += this.m_srcInstanceId;
			s += "\" src_owner_name=\"";
			s += this.m_srcOwnerName;
			s += "\" src_owner_id=\"";
			s += this.m_srcOwnerId;
			s += "\" src_ref_attr_name=\"";
			s += this.m_srcRefAttrName;
			s += "\" dest_owner_name=\"";
			s += this.m_destOwnerName;
			s += "\" dest_owner_id=\"";
			s += this.m_destOwnerId;
			s += "\"";
			if (this.m_destRefAttrName)
			{
				s += " dest_ref_attr_name=\"";
				s += this.m_destRefAttrName;
				s += "\"";
			}

			s += "/>\r\n";
		return s;
	},

	handleServerResponse: function (xmlDoc)
	{
	}
});    
