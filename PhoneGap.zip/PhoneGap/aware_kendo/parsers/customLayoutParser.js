// This parser handles queries that have custom presentation
var AwareApp_CustomLayoutParser = AwareApp_BaseParser.extend(
{
	// If entityName and id are not null we are showing presentation for this entity
	init: function (xmlDoc, entityName, entityId, queryString, extParams, inWindow)
	{
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);

		this.m_entityName     = entityName;
		this.m_entityId       = entityId;
		this.m_queryStr       = queryString;
		this.m_extParams      = extParams;
		this.m_firstLoad      = true;
	},
	
	// used in preview framework
	reset: function ()
	{
		this.m_tools = null;
		this.m_toolbars = null;
		this.m_panelHeader = null;
		this.m_panelOpers = null;
		this.m_extParams = null;
		
		this.init (this.m_xmlDoc, this.m_entityName, this.m_entityId, this.m_queryStr, null, false);
		
		this.m_gmUsed = null;
	},

 	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName ("custom_layout");
		if (! mainNodes || mainNodes.length != 1)
			return null;
			
		var mainNode = mainNodes [0];
		
		if (! this.m_queryStr)
		{
			var queryStrNodes = getFirstLevelChildNodes (mainNode, "query_string");
			if (! queryStrNodes || queryStrNodes.length == 0)
				return null;
			
			this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		}
		
		this.m_presName        = getAttributeValue (mainNode, "presentation_name", null);
		this.m_refreshProcs    = getAttributeValue (mainNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (mainNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue (mainNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue(mainNode, "refresh_impl_proc", null);
		this.m_refOwnerName    = getAttributeValue (mainNode, "ref_owner_name",null);
		this.m_refAttrName     = getAttributeValue (mainNode, "ref_attr_name", null);
		this.m_refOwnerId      = getAttributeValue (mainNode, "ref_owner_id",  null);
		this.m_formName        = getAttributeValue (mainNode, "form_name",     null);
		this.m_sectionName     = getAttributeValue (mainNode, "section_name",  null);		
		this.m_queryName       = getAttributeValue (mainNode, "query_name",     null);
		var showPaging         = getBooleanValue   (mainNode, "show_paging", true);
		this.m_selectFirst     = getBooleanValue   (mainNode, "select_first",   false);
		this.m_execDefault     = getBooleanValue   (mainNode, "execute_default", true);
		this.m_itemsPerPage    = getIntegerValue   (mainNode, "items_per_page", 20);
		var multiSelect        = getBooleanValue   (mainNode, "multi-select", false);
		this.m_displayMsg      = getAttributeValue (mainNode, "display_msg",  AwareApp.Locale["CE_PGDisplay"]);
		this.m_panelWidth      = getIntegerValue   (mainNode, "panel_width", null);
		var height             = getAttributeValue (mainNode, "panel_height", null);
		if (height && height == "Align")
			this.m_alignToBottom = true;
		else
			this.m_panelHeight = height;

		if (! this.m_previewMode)
			this.m_previewMode = getBooleanValue (mainNode, "preview_mode", false);
		
		var rn = mainNode.getElementsByTagName ("resizing_options");
		if (rn && rn.length > 0)
			this.m_resizingNode = rn [0];
			
		var rsn = mainNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		if (! this.m_refAttrName)
		{
			var tn = getFirstLevelChildNodes (mainNode, "tour");
			if (tn && tn.length > 0)
				this.m_tourNode = tn [0];
		}
		
		this.m_objectRefNodes = mainNode.getElementsByTagName ("object_reference");
		var dtNodes           = mainNode.getElementsByTagName ("data_template");
		var dtNode            = (! this.m_presName && dtNodes && dtNodes.length > 0 ? dtNodes[0] : null);
		
		this.m_itemOpers = this.getItemOperations (mainNode);
		
		this.m_widgetId = "AW_CUSTOM_QUERY_" + Math.floor (Math.random () * 100001);	
		
		var filters = this.parseFilterFields (mainNode, this.m_widgetId);
		
		var fields = this.getFields (dtNode);

		var dataSource = new kendo.data.DataSource(this.getDataSourceConfig (mainNode, fields));
		var widgetConfig = {
			template:   this.getTemplate (dtNode),
			dataSource: dataSource
		};
		if (! this.m_presName)
		{
			if (multiSelect)
				widgetConfig.selectable = "multiple";
			else if (this.m_itemOpers.length > 0 || this.m_selectFirst)
				widgetConfig.selectable = "single";
			
			this.m_selectable = widgetConfig.selectable;
		}
		
		this.setupEvents (widgetConfig);
		
		var panelConfig = this.getPanelConfig (mainNode, this.m_widgetId, "grid", filters && filters.loc != "header" ? filters : null);
		if (this.m_panelWidth)
			panelConfig.width = this.m_panelWidth;
		if (this.m_panelHeight)
			panelConfig.height = this.m_panelHeight;
		else if (this.m_presName)
			panelConfig.height = AwareApp.getDefaultFormHeight ();  // without the height the panel will have some very narrow default height
		
    	var widgets = new Array ();
		
		if (this.m_showSaveSettingsButton)
		{
			this.setState (panelConfig);
		}
		
		if (this.m_itemOpers && this.m_itemOpers.length > 0 && ! this.m_presName && (this.m_itemOpers.length != 1 || ! this.m_defaultOper))
		{
			panelConfig.bodyContent = this.prepareContextMenu (this.m_itemOpers, this.m_widgetId, widgets);
		}
		
		var extraElems = new Array ();
		if (filters && filters.loc == "header")
		{
			extraElems = filters.elems.concat (extraElems);
		}
		
		if (extraElems.length > 0)
			panelConfig.extraHeaderElems = extraElems;
				
		this.m_panel = new AwareApp_Panel (panelConfig);
		
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "listview",
    		id:     this.m_widgetId,
    		config: widgetConfig
    	});
		if (filters)
		{
			for (var i = 0; i < filters.widgets.length; ++ i)
				widgets.push (filters.widgets[i]);
		}
  	
		var pagerMarkup = "", ppw = null;
		if (! this.m_entityName && showPaging)
		{
			pagerMarkup = this.createPagingBar (dataSource, widgets);
			ppw = $("<div>");
			if (this.m_panelWidth)
				ppw.css ("width", this.m_panelWidth);
			
			if (panelConfig.minWidth && panelConfig.minWidth > 0)
				ppw.css ("min-width", panelConfig.minWidth);
			if (panelConfig.maxWidth && panelConfig.maxWidth > 0)
				ppw.css ("max-width", panelConfig.maxWidth);
		}
		
		// has to be after pager widget has been created otherwise resizeToEnclosing will not work
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
		
		if (this.m_resizingNode)
		{
			this.addResizeWidgets (this.m_resizingNode, panelMarkup, widgets);
		}
		
		if (dtNode)
		{
			var ddNodes = getFirstLevelChildNodes (mainNode, "drag_drop");
			if (ddNodes && ddNodes.length > 0)
			{
				this.m_ddNode = ddNodes[0];
			}
		}
		
		var markup = panelMarkup.html, wrapperId = panelMarkup.id;
		if (ppw)
		{
		    // move id to the top level, otherwise standard margins will be assigned incorrectly
			var m = $(markup), outerM = null;
			if (panelConfig.preventHeader === true)
			{
				// panel doesn't generate a wrapper. ppw must become a wrapper
				wrapperId = this.m_widgetId + "_ppw";
				ppw.attr (id, wrapperId);
				outerM = $('<div />').append(m).html()
			}
			else
			{
				var id = m.attr ("id");
				m.removeAttr ("id");
				ppw.attr ("id", id);
			}
			
			if (panelConfig.cls)
				ppw.addClass (panelConfig.cls);

			ppw.append (outerM ? outerM : m.html());
			
			ppw.append (pagerMarkup);
			markup = $('<div />').append(ppw).html();
		}
		
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    wrapperId,
        	markup:       markup,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		// run init script if any
		this.runInitScript (mainNode, widgetConfig, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;
	},
	
	registerListeners: function ()
	{
		AwareApp.registerListener ("objectsDeleted", this);
		AwareApp.registerListener ("formSaved", this);
		AwareApp.registerListener ("objectUpdated", this);
		AwareApp.registerListener ("processFinished", this);
		AwareApp.registerListener ("processCancelled", this);
		AwareApp.registerListener ("gm_initialised", this);    
		AwareApp.registerListener ("referencesAdded", this);    
		AwareApp.registerListener ("referencesDeleted", this);    	    
	},

	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("objectsDeleted",    this);
		AwareApp.deregisterListener ("formSaved",    this);
		AwareApp.deregisterListener ("objectUpdated", this);
		AwareApp.deregisterListener ("processFinished", this);
		AwareApp.deregisterListener ("processCancelled", this);
		AwareApp.deregisterListener ("gm_initialised", this);    
		AwareApp.deregisterListener ("referencesAdded", this);    
		AwareApp.deregisterListener ("referencesDeleted", this);    

		if (this.m_dragDrop)
			this.m_dragDrop.destroy ();
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	// Can be used as static method
	getFields: function (dtNode)
	{
		var fields = {};
		fields ["BAS_REF_VALUE"] = { field: "BAS_REF_VALUE/text()" };
		
		if (dtNode)
		{
			fields ["BAS_OPER_APPLICABILITY"] = { field: "BAS_OPER_APPLICABILITY/text()" };
			
			var cNodes = dtNode.getElementsByTagName ("column");
			if (cNodes)
			{
				for (var i = 0; i < cNodes.length; ++ i)
				{
					var name = getAttributeValue (cNodes [i], "name", null);
					if (name)
						fields [name] = { field: name + "/text()" };
				}
			}
		}
		
		return fields;
	},
	
	getDataSourceConfig: function (mainNode, fields)
	{
		if (this.m_previewMode && ! this.m_presName)
		{
			return this.getPreviewStore (mainNode, fields, this.m_itemsPerPage);
		}
		
		var me = this;
		var dsConfig = {
			transport:       this.getTransport (),
            schema:          this.getSchema (fields),
			pageSize:        this.m_itemsPerPage,
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true
		};
		if (this.m_extParams && this.m_extParams.currentPage)
		{
			dsConfig.page = this.m_extParams.currentPage;
		}
		
		return dsConfig;
	},
		
	getSchema: function (fields)
	{
		var me = this;
        return {
        	type:  "xml",
        	data:  "/root/run_query_action_return/run_query_action_success/dataset/row",
        	total: "/root/run_query_action_return/run_query_action_success/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields
            },
            errors : "/root/run_query_action_return/failure/text()",
            parse: function (response)
            {
            	return me.preprocessResponse (response);
            }
        };
	},
	
	getTransport: function ()
	{
		var params = { 
			actionType:   'run_query_action', 
			query_string: this.m_queryStr, 
			widgetId:     this.m_widgetId         // this will be used by the server to prepare proper links
		};    	
		if (this.m_formParent && this.m_formParent.getFormId)
		{
			params.parentFormId = this.m_formParent.getFormId ();
		}
		if (this.m_presName)
		{
			params.presentation = this.m_presName;
		}
		if (this.m_queryName)
		{
			params.query_name = this.m_queryName;
		}
		if (this.m_refAttrName)
		{
			params.ref_attr_name      = this.m_refAttrName;
			params.ref_owner_name     = this.m_refOwnerName;
			params.ref_owner_id       = this.m_refOwnerId;
			params.form_name          = this.m_formName;
			params.section_name       = this.m_sectionName;
		}

		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}

		// add our entity to the context
		if (this.m_entityName && this.m_entityId)
		{
			if (params.queryContext)
				params.queryContext += ("," + this.m_entityName + ":" + this.m_entityId);
			else
				params.queryContext = this.m_entityName + ":" + this.m_entityId;
		}	
		
		var t = AwareApp.createAwareTransport (params);
		var me = this;
		t.parameterMap = function (data, type)
		{
			return me.encodeDataSourceData (data, type);
		}
		
		return t;
	},
	
	encodeDataSourceData: function (data, operType)
	{
		var map = {};
		for (var param in data)
		{
			this.encodeStandardDataParam (map, data, param, operType);
		}
		
		// add filters
		this.addFiltersToParams (map);
		
		if (! this.m_previewMode)
			this.postDataEncode (data, operType, map);
		
		return map;
	},
	
	encodeStandardDataParam: function (map, data, param, operType)
	{
		if (param == "page")
		{
			var page = data [param];
			
			// encode as "start" range
			this.m_curStart = this.m_itemsPerPage * (page - 1);
			map.start = this.m_curStart;
		}
		else 
		{
			if (this.m_curSortAttr && ! map.sort)
			{
				map.sort = this.m_curSortAttr;
				map.dir  = this.m_curSortOrder;
			}
			
			map[param] = data[param];
		}						
	},
	
	getTemplate: function (dtNode)
	{
		if (dtNode)
		{
			var t = AwareApp.FieldCreator.parseDataTemplate (dtNode);
			if (t)
				return t.template;
		}
		
		var container = $("<div>").addClass ("aw-pres-wrapper");
		return $('<div />').append(container).html();
	},
	
	createPagingBar: function (dataSource, widgets)
	{
		var wc = { 
			dataSource: dataSource,
			refresh:    true,
			messages:   {}
		};
		if (this.m_panelWidth && this.m_panelWidth < 400)
			wc.messages.display = "";
		else if (this.m_displayMsg)
			wc.messages.display = this.m_displayMsg;
		
		var id = this.m_widgetId + "_pager";
		widgets.push ({
			type:   "pager",
			id:     id,
			config: wc 
		});
		
		var d = $("<div>").attr ("id", id).addClass ("k-pager-wrap");
		
		return $('<div />').append(d).html();
	},
	
	setupEvents: function (widgetConfig)
	{
		var me = this;
		widgetConfig.dataBound = function ()
		{
			me.afterStoreLoad ();
		}
		widgetConfig.change = function ()
		{
			me.onSelectionChange ();
		}
	},
	
	getWidget: function ()
	{
		if (! this.m_widgetInfo)
			return null;
		
		return $("#" + this.m_widgetInfo.markupId).data("kendoListView");		
	},
	
	afterRender: function ()
	{		
		var widget = this.getWidget ();
		// This is needed for resizeToEnclosing to work properly - for some reason it is not setup by default
		if (widget && widget.element)
			widget.element.css ("overflow", "auto");
		
		if (this.m_ddNode && ! kendo.support.mobileOS)
		{
			this.setupDragDrop ();
		}
			
		if (this.m_renderScript)
		{
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for custom query " + this.getQueryName () + " " + e);
			}
		}
		
		if (this.m_alignToBottom)
		{
			this.alignToBottom ();
		}
		else if (! this.m_panelHeight)
		{
			this.resizeToEnclosing ();
		}
	},
	
	resizeToEnclosing: function ()
	{
		var p = this.getResizeToEnclosingPanel ();
		if (p)
		{
			var ep = p.panel;
			
			var h = ep.height ();
			var wrapperEl = $("#" + this.m_widgetInfo.wrapperId),
				dataArea = this.getWidget().element,
				otherElements = wrapperEl.children(),
				otherElementsHeight = 0;
			
			otherElements.each(function() {
				otherElementsHeight += $(this).outerHeight();
			});
			
			// pager is created at the parent's level
			var pager = wrapperEl.parent ().find(".k-pager-wrap");
			var pagerHeight = 0;
			if (pager.length > 0)
				pagerHeight = pager.outerHeight ();
			
			dataArea.height(h - otherElementsHeight + dataArea.innerHeight () - pagerHeight - 1 /* rounding */);
		}	
	},
	
	doAlignToBottom: function (params)
	{
		// Align to the bottom of the screen determined by the edge of the enclosing frame
		var frame = $("#" + params.frameId);
		if (frame && frame.length > 0)
		{
			var wrapperEl = $("#" + this.m_widgetInfo.wrapperId);
			var dataArea = this.getWidget ().element;
			// pager is created at the parent's level
			var pager = wrapperEl.parent ().find(".k-pager-wrap");
			
			var pagerHeight = 0;
			if (pager.length > 0)
				pagerHeight = pager.outerHeight () + 1;
			
			dataArea.height (parseInt (frame.offset ().top + frame.outerHeight() - dataArea.offset().top - pagerHeight - params.margin));
		}	
	},
	
	getKeyForState: function ()
	{
		var key =  this.m_refAttrName ?
		           AwareApp.STATE_PREFIX + "R" + "@" + this.m_refOwnerName + "@" + this.m_refAttrName + "@" + this.m_formName + "@" + this.m_sectionName :
		           AwareApp.STATE_PREFIX + "Q" + "@" + this.m_queryName;
		           
		// size has to be less than the length in the database
		return key.length <= 240 ? key : key.substring (0, 240);
	},

	prepareContextMenu: function (itemOpers, widgetId, widgets)
	{
		var id = widgetId + "_cm";
		
		var items = new Array ();
		for (var i = 0; i < itemOpers.length; ++ i)
		{
			var oper = itemOpers[i];			
			var b = this.getOperationButton (oper, false);
			if (b)
				items.push (b);
		}
		
		var me = this;
		widgets.push ({
			type: "contextmenu",
			id:   id,
			config: {
				target: "#" + widgetId,
				dataSource: items,
                filter: ".aw-pres-wrapper",
                select: function(e) {
                	e.preventDefault ();
                	me.onContextMenu ($(e.item), $(e.target));
                }
			}
		});
		
		return "<ul id='" + id + "'></ul>";
	},
	
	onContextMenu: function (menuItem, selItem)
	{
		var text = menuItem.text ();
		for (var i = 0; i < this.m_itemOpers.length; ++ i)
		{
			var oper = this.m_itemOpers[i];
			if (oper.operName == text)
			{
				var selection = this.getSelection ([ this.getWidget ().dataItem (selItem) ], oper);
				this.runOperation(selection, oper);
				break;
			}
		}
	},
	
	onSelectionChange: function ()
	{
		if (this.m_defaultOper)
		{
			if (this.m_selectFirst && ! this.m_execDefault)
			{
				// do not execute default operation on first selection
				this.m_execDefault = true;
			}
			else
			{
				var w = this.getWidget ();
				var selRecord = w.dataItem (w.select ());
				
				if (this.m_defaultOper.operName && operationApplicable (selRecord, this.m_defaultOper.operName))
				{
					this.runPanelOperation (this.m_defaultOper);
				}
			}
		}
	},
	
	setupDragDrop: function ()
	{
		this.m_dragDrop = new AwareApp_DragDrop (this.m_ddNode);
		
		var me = this;
	    $("#" + this.m_widgetId).kendoSortable ({
	        filter: ">div.aw-pres-wrapper",
	        autoScroll: true,
            cursor: "move",
            placeholder:function(element) 
            {
                return element.clone().css("opacity", 0.1);
            },
            hint: function(element) {
                return element.clone().removeClass("k-state-selected");
            },
            start: function (e)
            {
                var dataItem = me.getWidget().dataSource.getByUid(e.item.data("uid"));
                if (! me.m_dragDrop.canHandleRecords ([dataItem]))
                	e.preventDefault ();
            },
            change: function(e) 
            {
            	var ds = me.getWidget().dataSource;
                var dataItem = ds.getByUid(e.item.data("uid"));
                me.m_dragDrop.onDrop (dataItem, ds.at(e.newIndex), function () {
                    ds.remove(dataItem);
                    ds.insert(e.newIndex, dataItem);                	
                });
            }
	    });		
	},
	
	getTourElementSelector: function (sectionId)
	{
		var tourElem = this.m_tourElements [sectionId];
		if (! tourElem)
			return null;
		
		if (tourElem.type == "oper" || tourElem.type == "filter")	
		{
			return "#" + tourElem.id;
		}
		if (tourElem.type == "tool")
		{
			return this.m_panel.getToolTourSelector (tourElem.imgCls);
		}
		
		return null;
	},	
	
	afterStoreLoad: function ()
   	{
		var children = $("#" + this.m_widgetId).children ();
		children.addClass ("aw-pres-wrapper");
		
		var firstItem = $(children [0]);
   		if (this.m_presName)
   		{
   			if (this.m_htmlText && firstItem.length > 0)
   			{
   				firstItem.html (this.m_htmlText);
   			}
	   		
	   		// Google maps if any
	   		if (this.m_gmUsed && this.m_gmUsed.length > 0)
	   		{
				AwareApp.initGoogleMaps ();
	   		}
	   	}
   		else if (this.m_selectFirst && this.m_firstLoad)
		{
			if (firstItem.length > 0)
			{
				var me = this;
	    		setTimeout (function () {
	    			me.getWidget ().select (firstItem);
	    		}, 500);
			}
		}
   		
		this.m_firstLoad = false;		
   	},
   	
	doSort: function (sortAttrName, sortOrder)
	{
		if (sortAttrName)
		{
			if (sortAttrName == "[cancel]")
			{
				this.m_curSortAttr  = null;
				this.m_curSortOrder = null;
			}
			else
			{
				this.m_curSortAttr  = sortAttrName;
				this.m_curSortOrder = (sortOrder ? sortOrder : "asc");
			}
			
			this.refreshData ();
		}		
	},
	
	preprocessResponse: function (response)
	{
		var qsNodes = response.getElementsByTagName ("query_string");
		if (qsNodes && qsNodes.length > 0)
		{
			this.setQueryString (getTextNodeValue (qsNodes [0]));
		}
		
		if (this.m_presName)
		{
			this.preprocessPresentation (response);
		}
		
		AwareApp_BaseParser.fn.preprocessResponse.call (this, response);
		return response;
	},
	
	getContextForOperation: function (oper)
	{		
		var selection = null;
		if (this.m_selectable)
		{
			var selRecords = new Array ();
			
			var widget   = this.getWidget ();
			var selItems = widget.select ();
			if (selItems)
			{
				selRecords = new Array ();
				for (var i = 0; i < selItems.length; ++ i)
					selRecords.push (widget.dataItem (selItems [i]));
			}
			
			selection = this.getSelection(selRecords, oper);
		}
		
		return oper && oper.operType == "delete_object" ? selection : this.addContext (selection);
	},
	
	getSelection: function (selRecords, oper)
	{
		var selection = null;
		if (selRecords)
		{
			selection = new Array ();
			for (var i = 0; i < selRecords.length; ++ i)
			{
				if (oper && ! operationApplicable (selRecords [i], oper.operName))
				{
  			        var config = {
		                title:  AwareApp.Locale["C_Error"],
		                msg:    AwareApp.Locale["C_TreeOperApp"],
		                btnOK:  true
		            };
		            	
		     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
					return;
				}
				
				selection.push (getObjectReference (selRecords[i].id));
			}
		}	
		
		return selection.length == 0 ? null : selection;		
	},
		
	getEditObjectQueryCtx: function (selection)
	{
		var queryCtx = null;
		if (selection && selection.length > 0)
		{
			var ds = this.getWidget().dataSource;
			var selRecord = ds.get (selection[0].objectName + ":" + selection[0].objectId);
			
			if (selRecord)
			{
				queryCtx = {
					queryString: this.m_queryStr,
					curIdx:      ds.indexOf (selRecord) + (this.m_curStart ? this.m_curStart : 0),
					total:       ds.total (),
					sortAttr:    (this.m_extParams && this.m_extParams.sortAttribute ? this.m_extParams.sortAttribute : null),
					sortDir:     (this.m_extParams && this.m_extParams.sortDirection ? this.m_extParams.sortDirection : null),
					context:     this.getQueryContext ()
				};
			}
		}
		
		return queryCtx;
	},
	
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "objectsDeleted")
		{
			if (this.m_entityName && this.m_entityId)
			{
				// check if our object has been deleted
				for (var i = 0, len = eventInfo.length; i < len; ++ i)
				{
					if (eventInfo [i].objectName == this.m_entityName &&
						eventInfo [i].objectId   == this.m_entityId)
					{
						AwareApp.closeComponent (this.m_widgetInfo, false, true);
						return;
					}
				}
			}
			
			this.refreshData ();
		}
		else if (eventName == "referencesAdded" || eventName == "referencesDeleted")
		{
			if (eventInfo && this.m_refOwnerName && eventInfo.refOwnerName == this.m_refOwnerName &&
				this.m_refOwnerId == eventInfo.refOwnerId && this.m_refAttrName == eventInfo.refAttrName)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if ((this.m_entityName && this.m_entityId &&
				 eventInfo &&
				 eventInfo.objectName == this.m_entityName &&
				 eventInfo.objectId == this.m_entityId
				 ) ||
				containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs)
				)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processFinished")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				// our process has finished - refresh the grid
				if (this.m_ourProcess.noRefresh !== true)
					this.refreshData ();
				
				this.m_ourProcess = null;
			}
			else if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processCancelled")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				this.m_ourProcess = null;
			}
		}
		else if (eventName == "gm_initialised")
		{
			if (this.m_gmUsed)
				this.startMaps ();
		}
	},
	
	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_CustomLayoutParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	// ----------------------------------------------------------------------------------------------------------
	
	// The following functions are called from hyperlinks on presentations
	deleteEntity: function (entityName, entityId)
	{
		if (! window.confirm (AwareApp.Locale["C_GridConfDel"]))
			return;
			
		var action = new AwareApp_DeleteObjectsAction ([ { objectName: entityName, objectId: entityId } ]);
		action.run ();
	},
	
	displayDocument: function (entityName, entityId, docAttrName)
	{
		AwareApp.viewDocument (entityName, entityId, docAttrName, false, false);
	},
	
	displayError: function (errorMsg)
	{
   		alert (errorMsg);
	},
	
	displayUrl: function (url, target)
	{
		if (target == "default" || target == "popup")
			AwareApp.displayURL (url);
		else if (target == "new_tab")
			AwareApp.displayURLInMain (url, target);
	},
	
	getPresLinksTarget: function (operTarget)
	{
		var target = (operTarget && operTarget == "default" ? null : operTarget);
		return this.getLinksTarget (target);
	},
	
	runQuery: function (queryName, target, contextEntityName, contextEntityId)
	{
		var action = new AwareApp_RunQueryAction (
							null,
							queryName, 
							(contextEntityName && contextEntityId ?
							   [ { objectName: contextEntityName, objectId: contextEntityId } ] : null
							), 
							this.getPresLinksTarget (target),
							null);
		action.run ();
	},
	
	startProcess: function (processName, target)
	{
		// if there are other aruments they are parameters of the process. They are in couples, object name and 
		// then object id
		var params = null;
		if (arguments.length > 2)
		{
			params = new Array ();
			for (var i = 2, len = arguments.length; i < len; i += 2)
			{
				if (i + 1 < len)
				{
					params.push ({ objectName: arguments [i], objectId: arguments [i + 1] });
				}
			}
		}
		
		var selection = this.addContext (params);
		var action = new AwareApp_StartProcessExecutionAction (
							processName, 
							params, 
							null,
							this.getPresLinksTarget (target),
							null,
							null);
		action.run ();
	},
	
	navigateToEntity: function (entityName, entityId, target)
	{
		var action = new AwareApp_GetFormDataAction (
						entityName, 
						entityId, 
						"edit", 
						null, 
						null,
						this.getPresLinksTarget (target));
		action.run ();		
	},
	
	viewEntity: function (entityName, entityId, presentation, target)
	{
		var action = new AwareApp_ViewObjectAction (
						entityName, 
						entityId,
						presentation, 
						this.getPresLinksTarget (target));
		action.run ();
	},
	
	startMaps: function ()
	{
		if (! this.m_gmUsed)
			return;
		
		// We have to recreate new maps all the time as we keep changing HTML all the time and maps are attached to their DOM elements
		for (var i = 0; i < this.m_gmUsed.length; ++ i)
		{
			var map = new AwareApp_Map (this.m_gmUsed [i]);
		}
	},
	
	preprocessPresentation : function (response)
	{
    	var htmlNodes = response.getElementsByTagName ("html");
        if (! htmlNodes || htmlNodes.length == 0) 
        {
            return;
        }
        
        this.m_htmlText = getTextNodeValue (htmlNodes[0]);
    	
        // if there are any GoogleMaps replace them with the appropriate script
        this.handleGoogleMaps ();        
    },
    
    handleGoogleMaps: function ()
    {
    	// Google maps are represented with a special XML text (see GoogleMapScriptlet). We will be replacing
    	// this XML with div's and attach the appropriate GM script to these <div>s
    	var startIdx = 0;
    	var gmNmb = 0;
    	while (1)
    	{
    		var idx = this.m_htmlText.indexOf ("&lt;Google_Map", startIdx);
    		if (idx < 0)
    			break;
    			
    		var idx2 = this.m_htmlText.indexOf ("&lt;/Google_Map&gt;", idx + 10);
    		if (idx2 < 0)
    		{
    			startIdx = idx + 10;
    		}
    		else
    		{
    			if (this.handleGoogleMap (idx, idx2 + 19, gmNmb))
    			{
    				++ gmNmb;
    				startIdx = idx + 5;
    			}
    			else
    			{
    				// remove the google map markup
    				this.m_htmlText = this.m_htmlText.substring (0, idx) + this.m_htmlText.substring (idx2 + 19);
    				startIdx = idx + 1;
    			}
    		}
    	}
    },
    
    handleGoogleMap: function (startIdx, endIdx, gmNmb)
    {
    	// the string between the indexes must be a valid XML
    	var xmlStr = this.m_htmlText.substring (startIdx, endIdx);
    	xmlStr = "<?xml version='1.0' encoding='UTF-8' ?>" + htmlDecode (xmlStr);
    	
    	// parse it 
		var xmlDoc = parseXMLDocument ($.trim (xmlStr));
		if (xmlDoc == null)
		{
			alert (AwareApp.Locale["C_DVParseGM"]);
			return false;
		}
		if (xmlDoc.parseError && xmlDoc.parseError.reason && xmlDoc.parseError.reason != '')
		{
			alert (AwareApp.Locale["C_DVParseGMError"].replace ("{0}", xmlDoc.parseError.reason).replace ("{1}", xmlDoc.parseError.line).replace ("{2}", xmlDoc.parseError.srcText));
			return false;
		}
		
		var gmNodes = xmlDoc.getElementsByTagName ("Google_Map");
		if (! gmNodes || gmNodes.length != 1)
			return false;
			
		var gmPropsStr = getAttributeValue (gmNodes [0], "props", null);
		if (! gmPropsStr)
		{
			alert (AwareApp.Locale["C_DVParseErrorGMProp"]);
			return false;
		}
		
		if (! this.m_gmUsed)
			this.m_gmUsed = new Array ();
		
		var addressValues = AwareApp_Map.prototype.parseAddressValues (xmlDoc);
		
		var gm = { 
			id:                 this.m_widgetId + "_GM_" + gmNmb,
			gmPropsStr:         gmPropsStr, 
			addressValues:      addressValues,
			operContext:        this.getContextForOperation(null),
			operTargetResolver: { func: this.getLinksTarget, scope: this}
		};
		
		var centerNodes = xmlDoc.getElementsByTagName ("CenterPoint");
		if (centerNodes && centerNodes.length > 0)
			gm.center = getTextNodeValue (centerNodes[0]);
		
		gm.operations = AwareApp_Map.prototype.parseOperations (xmlDoc);
		
		// save everything
		this.m_gmUsed.push (gm);
		
    	var s = gmPropsStr.split ("@");
    	var w = 400, h = 300;
    	if (s.length > 2)
    	{
    		w = s [1];
    		h = s [2];
    	}
    	
		// replace XML with div
		var div = "<div id='" + gm.id + "' style='width:" + w + "px; height:" + h + "px' ></div>";
		this.m_htmlText = this.m_htmlText.substring (0, startIdx) + div + this.m_htmlText.substring (endIdx);
		
		return true;
    }
});

