// This parser handles queries that have custom presentation
var AwareApp_ScrollViewParser = AwareApp_BaseParser.extend(
{
	// If entityName and id are not null we are showing presentation for this entity
	init: function (xmlDoc, queryString, inWindow)
	{
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);

		this.m_queryStr = queryString;
	},

 	// used in preview framework
	reset: function ()
	{
		this.m_tools = null;
		this.m_toolbars = null;
		this.m_panelHeader = null;
		this.m_panelOpers = null;
		this.m_extParams = null;
		
		this.init (this.m_xmlDoc, this.m_queryStr, false);
	},
	
    // Override the parent
	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName ("scroll_view_layout");
		if (! mainNodes || mainNodes.length != 1)
			return null;
			
		var mainNode = mainNodes [0];
		
		if (! this.m_queryStr)
		{
			var queryStrNodes = getFirstLevelChildNodes (mainNode, "query_string");
			if (! queryStrNodes || queryStrNodes.length == 0)
				return null;
			
			this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		}
		
		this.m_refreshProcs    = getAttributeValue (mainNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (mainNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue   (mainNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue (mainNode, "refresh_impl_proc", null);
		this.m_refOwnerName    = getAttributeValue (mainNode, "ref_owner_name",null);
		this.m_refAttrName     = getAttributeValue (mainNode, "ref_attr_name", null);
		this.m_refOwnerId      = getAttributeValue (mainNode, "ref_owner_id",  null);
		this.m_formName        = getAttributeValue (mainNode, "form_name",     null);
		this.m_sectionName     = getAttributeValue (mainNode, "section_name",  null);		
		this.m_queryName       = getAttributeValue (mainNode, "query_name",     null);
		this.m_itemsPerPage    = getIntegerValue   (mainNode, "items_per_page", 1);
		this.m_showPaging      = getBooleanValue   (mainNode, "show_paging", true);
		this.m_panelWidth      = getIntegerValue   (mainNode, "panel_width", null);
		this.m_panelHeight     = getIntegerValue   (mainNode, "panel_height", null);
		if (! this.m_panelHeight)
			this.m_panelHeight = 300;

		if (! this.m_previewMode)
			this.m_previewMode = getBooleanValue (mainNode, "preview_mode", false);
		
		var rsn = mainNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		
		this.m_objectRefNodes = mainNode.getElementsByTagName ("object_reference");
		var dtNodes           = mainNode.getElementsByTagName ("data_template");
		var dtNode            = dtNodes[0];
		
		var template = AwareApp.FieldCreator.parseDataTemplate (dtNode);
		
		var baseId = "AW_CUSTOM_SCV_QUERY_" + Math.floor (Math.random () * 100001);	
		
		var fields = this.getFields (dtNode);

		this.m_dataSource = new kendo.data.DataSource(this.getDataSourceConfig (mainNode, fields));
		var widgetConfig = this.getWidgetConfig (template, this.m_dataSource);
		
		var panelConfig = this.getPanelConfig (mainNode, baseId, "scroll_view");
		
		if (this.m_panelWidth)
			panelConfig.width = this.m_panelWidth;
		
		panelConfig.height = this.m_panelHeight;
		
		// Widget must not have children, otherwise datasource is not initialised, so put it on the body content
		this.m_widgetId = baseId + "_w";
		var b = $("<div>").attr ("id", this.m_widgetId).css ("height", this.m_panelHeight + "px");
		panelConfig.bodyContent = $('<div />').append(b).html();
		
		this.m_panel = new AwareApp_Panel (panelConfig);
		
    	var widgets = new Array ();
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "mobileScrollView",
    		id:     this.m_widgetId,
    		config: widgetConfig
    	});
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
  	
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		// run init script if any
		this.runInitScript (mainNode, widgetConfig, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;
	},
	
	registerListeners: function ()
	{
		AwareApp.registerListener ("objectsDeleted", this);
		AwareApp.registerListener ("formSaved", this);
		AwareApp.registerListener ("objectUpdated", this);
		AwareApp.registerListener ("processFinished", this);
		AwareApp.registerListener ("processCancelled", this);
		AwareApp.registerListener ("referencesAdded", this);    
		AwareApp.registerListener ("referencesDeleted", this);    	    
	},

	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("objectsDeleted",    this);
		AwareApp.deregisterListener ("formSaved",    this);
		AwareApp.deregisterListener ("objectUpdated", this);
		AwareApp.deregisterListener ("processFinished", this);
		AwareApp.deregisterListener ("processCancelled", this);
		AwareApp.deregisterListener ("referencesAdded", this);    
		AwareApp.deregisterListener ("referencesDeleted", this);
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	getWidgetConfig: function (template, dataSource)
	{
		return {
			template:      template.template,
			dataSource:    dataSource,
			itemsPerPage:  this.m_itemsPerPage,
			enablePager:   this.m_showPaging,
			// We have to specify this, otherwise the widget doesn't work
			contentHeight: "100%"
		};
	},
	
	getFields: function (dtNode)
	{
		var fields = {};
		fields ["BAS_REF_VALUE"] = { field: "BAS_REF_VALUE/text()" };
		
		fields ["BAS_OPER_APPLICABILITY"] = { field: "BAS_OPER_APPLICABILITY/text()" };
		
		var cNodes = dtNode.getElementsByTagName ("column");
		if (cNodes)
		{
			for (var i = 0; i < cNodes.length; ++ i)
			{
				var name = getAttributeValue (cNodes [i], "name", null);
				if (name)
					fields [name] = { field: name + "/text()" };
			}
		}
		
		return fields;
	},
	
	getDataSourceConfig: function (mainNode, fields)
	{
		if (this.m_previewMode)
		{
			return this.getPreviewStore (mainNode, fields, this.m_itemsPerPage);
		}
		
		var me = this;
		var dsConfig = {
			transport:       this.getTransport (),
            schema:          this.getSchema (fields),
            serverPaging:    true,
            serverFiltering: true,
            serverSorting:   true,
            pageSize:        this.m_itemsPerPage * 6  // This is what Kendo recommend
		};
		
		return dsConfig;
	},
		
	getSchema: function (fields)
	{
		var me = this;
        return {
        	type:  "xml",
        	data:  "/root/run_query_action_return/run_query_action_success/dataset/row",
        	total: "/root/run_query_action_return/run_query_action_success/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields
            },
            errors : "/root/run_query_action_return/failure/text()",
            parse: function (response)
            {
            	return me.preprocessResponse (response);
            }
        };
	},
	
	getTransport: function ()
	{
		var params = { 
			actionType:   'run_query_action', 
			query_string: this.m_queryStr
		};    	
		if (this.m_queryName)
		{
			params.query_name = this.m_queryName;
		}
		if (this.m_refAttrName)
		{
			params.ref_attr_name      = this.m_refAttrName;
			params.ref_owner_name     = this.m_refOwnerName;
			params.ref_owner_id       = this.m_refOwnerId;
			params.form_name          = this.m_formName;
			params.section_name       = this.m_sectionName;
		}

		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}
		
		var t = AwareApp.createAwareTransport (params);
		var me = this;
		t.parameterMap = function (data, type)
		{
			return me.encodeDataSourceData (data, type);
		}
		
		return t;
	},
	
	encodeDataSourceData: function (data, operType)
	{
		var map = {};
		for (var param in data)
		{
			this.encodeStandardDataParam (map, data, param, operType);
		}
		
		if (! this.m_previewMode)
			this.postDataEncode (data, operType, map);
		
		return map;
	},
	
	encodeStandardDataParam: function (map, data, param, operType)
	{
		if (param == "skip")
		{
			map.start = data[param];
		}
		else 
		{
			map[param] = data[param];
		}						
	},
	
	getWidget: function ()
	{
		return $("#" + this.m_widgetId).data("kendoMobileScrollView");		
	},
	
	afterRender: function ()
	{
		if (this.m_renderScript)
		{
			var widget = this.getWidget ();
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for scroll view query " + this.getQueryName () + " " + e);
			}
		}
	},
	
	preprocessResponse: function (response)
	{
		var qsNodes = response.getElementsByTagName ("query_string");
		if (qsNodes && qsNodes.length > 0)
		{
			this.setQueryString (getTextNodeValue (qsNodes [0]));
		}
		
		return response;
	},
	
	getContextForOperation: function (oper)
	{
		return this.addContext (null);
	},
	
	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_ScrollViewParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	// Interface method to handle events
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "referencesAdded" || eventName == "referencesDeleted")
		{
			if (eventInfo && this.m_refOwnerName && eventInfo.refOwnerName == this.m_refOwnerName &&
				this.m_refOwnerId == eventInfo.refOwnerId && this.m_refAttrName == eventInfo.refAttrName)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processFinished")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				// our process has finished - refresh the grid
				if (this.m_ourProcess.noRefresh !== true)
					this.refreshData ();
				
				this.m_ourProcess = null;
			}
			else if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "processCancelled")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				this.m_ourProcess = null;
			}
		}
	}	
});

