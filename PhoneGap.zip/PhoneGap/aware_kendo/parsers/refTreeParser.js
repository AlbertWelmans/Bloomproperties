// This class parses XML document representing the layout of a reference tree (tree_layout)
var AwareApp_ReferenceTreeParser = AwareApp_BaseParser.extend(
{
	init: function (xmlDoc)
	{
		AwareApp_BaseParser.call(this, xmlDoc, false);

		this.m_isGroupName = false;
		this.m_expanded    = false;
	},

	parse: function ()
	{
		var nodes = this.m_xmlDoc.getElementsByTagName ("tree_layout");
		if (! nodes || nodes.length != 1)
			return null;
			
		var treeNode = nodes [0];
		this.m_refOwnerName    = getAttributeValue (treeNode, "ref_owner_name", null);
		this.m_refOwnerId      = getAttributeValue (treeNode, "ref_owner_id", null);
		this.m_refAttrName     = getAttributeValue (treeNode, "ref_attr_name", null);
		this.m_formName        = getAttributeValue (treeNode, "form_name", null);
		this.m_sectionName     = getAttributeValue (treeNode, "section_name", null);
		this.m_queryOnName     = getAttributeValue (treeNode, "query_on_name", null);
		this.m_isGroupName     = getAttributeValue (treeNode, "is_group_name", null);
		this.m_inlineEditing   = getBooleanValue   (treeNode, "inline_editing",  false);
		this.m_expanded        = getBooleanValue   (treeNode, "expanded",  false);
		var panelTitle         = getAttributeValue (treeNode, "panel_title",  "");
		this.m_refreshProcs    = getAttributeValue (treeNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (treeNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue (treeNode, "refresh_interval",   -1);
		this.m_refreshImplProc = getAttributeValue (treeNode, "refresh_impl_proc", null);
		
		var width  = getIntegerValue (treeNode, "panel_width",  -1);
		var height = getIntegerValue (treeNode, "panel_height", 300);
		
		// generate unique id of the tree
		var treeId = "AW_TREE_" + Math.floor (Math.random () * 100001);
	
		this.m_itemOpers = this.getItemOperations(treeNode);
		
		/*
		var ddNodes = getFirstLevelChildNodes (treeNode, "drag_drop");
		if (ddNodes && ddNodes.length > 0 && ! kendo.support.mobileOS)
		{
			this.m_dragDrop = new AwareApp_DragDrop (ddNodes [0]);
		}
		*/
		
		var rsn = treeNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}
		
		var dsConfig = {
			transport: this.getTransport (),
			schema:    this.getSchema (),
			// without this datasource is not refreshed when fetch is called
            serverPaging:    true,
            serverSorting:   true
		};
			
		var me = this;
		var treeConfig = {
			dataSource:              dsConfig,
			dataTextField:           "BAS_DISPLAYED_FIELD",
			dataImageUrlField:       "bas_icon",
			dataSpriteCssClassField: "bas_sprite_icon",
			loadOnDemand:            ! this.m_expanded,
			dragAndDrop:             true,
			dataBound: function ()
			{
				me.afterStoreLoad ();
			},
			dragstart: function (e)
			{
				me.onDragStart (e);
			},
			drop: function (e)
			{
				me.onDrop (e);
			},
			select: function (e)
			{
				me.onItemSelect (e.node);
			}
		};
		
    	var widgets = new Array ();
    	
		var panelConfig = this.getPanelConfig (treeNode, treeId, "tree");		
		if (width > 0)
			panelConfig.width = width;
		if (height > 0)
			panelConfig.height = height;
		
		if (this.m_itemOpers && this.m_itemOpers.length > 0)
		{
			panelConfig.bodyContent = this.prepareContextMenu (this.m_itemOpers, treeId, widgets);
		}
				
		this.m_panel = new AwareApp_Panel (panelConfig);
		
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "treeview",
    		id:     treeId,
    		config: treeConfig
    	});
		
		this.m_widgetInfo = {
          	markupId:     treeId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		// run init script if any
		this.runInitScript (treeNode, treeConfig, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;
	},
	
	registerListeners: function ()
	{
		AwareApp.registerListener ("actionFailed",      this);
		AwareApp.registerListener ("referencesAdded",   this);
		AwareApp.registerListener ("referencesDeleted", this);
		AwareApp.registerListener ("objectsDeleted",    this);
		AwareApp.registerListener ("processFinished",   this);
		AwareApp.registerListener ("processCancelled",  this);
	},
	
	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("actionFailed",      this);
		AwareApp.deregisterListener ("referencesAdded",   this);
		AwareApp.deregisterListener ("referencesDeleted", this);
		AwareApp.deregisterListener ("objectsDeleted",    this);
		AwareApp.deregisterListener ("processFinished",   this);
		AwareApp.deregisterListener ("processCancelled",  this);
		
		/*
		if (this.m_dragDrop)
			this.m_dragDrop.destroy ();
		*/
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	getTransport: function ()
	{
		var params = {
			actionType:      "get_kendo_ref_tree_nodes_action",
			ref_owner_name:  this.m_refOwnerName,
			ref_owner_id:    this.m_refOwnerId,
			ref_attr_name:   this.m_refAttrName,
			form_name:       this.m_formName,
			section_name:    this.m_sectionName,
			from_tree:       "true"
		};
		
		return AwareApp.createAwareTransport (params);		
	},
	
	getSchema: function ()
	{
		var fields = {};
		
		this.addField ("BAS_REF_VALUE", fields);
		this.addField ("BAS_DISPLAYED_FIELD", fields);
		this.addField ("BAS_OPER_APPLICABILITY", fields);
		this.addField ("bas_ownerRefAttrName", fields);
		this.addField ("bas_ownerName", fields);
		this.addField ("bas_ownerId", fields);
		this.addField ("bas_childRefAttrName", fields);
		this.addField ("bas_childReferredName", fields);
		this.addField ("bas_childReferredIsGroup", fields);
		this.addField ("bas_acceptsDropOf", fields);
		this.addField ("bas_icon", fields);
		this.addField ("bas_sprite_icon", fields);
		this.addField ("bas_allowDrag", fields);
		
		// defaultValue here is essential - this is how the server marks null parentId
		fields.parentId = { field: "bas_parentId/text()", nullable: false, defaultValue: "-1" };
		fields.hasChildren = { field: "bas_hasChildren/text()", type: "boolean", nullable: false };
		
        return {
        	type:  "xml",
        	data:  "/root/get_kendo_ref_tree_nodes_action_return/dataset/row",
        	total: "/root/get_kendo_ref_tree_nodes_action_return/dataset/total/text()",
            model: {
            	id:     "BAS_REF_VALUE",
                fields: fields,
                encoded: false,
                hasChildren: { field: "bas_hasChildren/text()", type: "boolean", nullable: false }
            },
            errors : "/root/get_kendo_ref_tree_nodes_action_return/failure/text()"
        };
	},
	
	addField: function (fieldName, fields)
	{
		fields [fieldName] = { field: fieldName + "/text()" };
	},
	
	afterStoreLoad: function ()
	{
		if (this.m_expanded === true)
		{
			this.getTreeWidget ().expand(".k-item");
		}
	},
	
	getTreeWidget: function ()
	{
		if (! this.m_widgetInfo)
			return null;
		
		return $("#" + this.m_widgetInfo.markupId).data("kendoTreeView");		
	},
	
	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "referencesAdded" || eventName == "referencesDeleted")
		{
			//if (eventInfo && this.m_refOwnerName && eventInfo.refOwnerName == this.m_refOwnerName &&
			//	this.m_refOwnerId == eventInfo.refOwnerId && this.m_refAttrName == eventInfo.refAttrName)
			{
				this.refreshData ();
			}
		}
		else if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
		else if (eventName == "actionFailed")
		{
			this.m_ourProcess = null;
		}
		else if (eventName == "processFinished")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				// our process has finished - refresh the tree
				if (this.m_ourProcess.noRefresh !== true)
					this.refreshData ();
				
				this.m_ourProcess = null;
			}
			else if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				// the process has been explicitly mentioned in refresh processes
				this.refreshData ();
			}
		}
		else if (eventName == "processCancelled")
		{
			if (this.m_ourProcess && eventInfo && eventInfo.processId && eventInfo.processId == this.m_ourProcess.processId)
			{
				this.m_ourProcess = null;
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
	},
	
	// interface method
	refreshData: function ()
	{
		this.doRefreshData (true);
	},
	
	doRefreshData: function (restorePath)
	{
		if (this.m_refreshImplProc)
		{
			var a = new AwareApp_StartProcessExecutionAction (this.m_refreshImplProc, null, null, this.getEnclosingTarget (), null, null);
			a.setCallContext ("refresh");
			a.run ();
		}
		else
		{
			var tree = this.getTreeWidget ();
			var curPath = (restorePath && ! this.m_expanded ? this.getCurrentPath (tree) : null);
			
			var me = this;
			tree.dataSource.read().then(function() {
				if (curPath)
				{
					me.restorePath (curPath, curPath.length - 1, tree.dataSource, tree);
				}
			});
		}
	},
	
	getCurrentPath: function (tree)
	{
		var curPath = new Array ();
		
		var curNode = tree.select ();
		while (curNode && curNode.length > 0)
		{
			curPath.push (tree.dataItem (curNode).id);
			curNode = tree.parent (curNode);
		}
		
		return curPath.length == 0 ? null : curPath;
	},
	
	restorePath: function (curPath, pathIdx, curDataSource, tree)
	{
		var id = curPath [pathIdx];
		var found = false;
		var j = 0;
		while (true)
		{
			var record = curDataSource.at (j);
			if (! record)
				break;
			
			if (record.id == id)
			{
				found = true;
				
				var me = this;
				record.load().done (function () {
					if (pathIdx > 0)
					{
						if (! me.restorePath (curPath, --pathIdx, record.children, tree))
							me.expandToPath (record, tree);							
					}
					else
					{
						me.expandToPath (record, tree);
					}
				})
				break;
			}
			
			++j;
		}
		
		return found;
	},
	
	expandToPath: function (record, tree)
	{
		tree.expandTo(record.id);
		var node = tree.findByUid (record.uid);
		tree.expand (node);		
	},
	
	onDragStart: function (e)
	{
        var record = this.getTreeWidget ().dataItem(e.sourceNode);
        /*
		if (this.m_dragDrop)
		{
	        if (! this.m_dragDrop.canHandleRecords ([record]))
	        	e.preventDefault ();	
		}
		else
		*/
		{
			var allowDrag = record.get ("bas_allowDrag");
			if (allowDrag == "false")
				e.preventDefault ();
		}
	},

	onDrop: function (e)
	{
		var tree = this.getTreeWidget ();
		var srcRecord    = tree.dataItem (e.sourceNode);
		var parentRecord = tree.dataItem (e.destinationNode);
		
		var parentRefAttrName = null;
		if (e.dropPosition != "over")
		{
			// use parent of the destRecord
			parentRefAttrName = parentRecord.get ("bas_ownerRefAttrName");
			parentRecord = tree.dataItem (tree.parent (e.destinationNode));
		}
		else
		{
			parentRefAttrName = parentRecord.get ("bas_childRefAttrName");
			if (! parentRefAttrName && parentRecord.children && parentRecord.children.at)
			{
				// try the first child
				var childRecord = parentRecord.children.at (0);
				if (childRecord)
					parentRefAttrName = childRecord.get ("bas_ownerRefAttrName");
			}
		}
		
		if (! AwareApp_DragDrop.prototype.allowDrop (srcRecord, parentRecord, parentRefAttrName))
		{
			// e.setValid (false); doesn't work
			e.preventDefault ();
		}
		else
		{
			AwareApp_DragDrop.prototype.performDrop (srcRecord, parentRecord, parentRefAttrName);
		}
	},
	
	onItemSelect: function (node)
	{
		if (this.m_defaultOper)
		{
			// Kendo sends this even BEFORE the item is actually selected, so wait a bit
			var me = this;
			setTimeout (function () {
				me.runItemOperation(me.m_defaultOper);
			}, 500);
		}
	},
	
	getItemOperations: function (mainNode)
	{
		var itemOpers = new Array ();
		
		var columnNodes = mainNode.getElementsByTagName ("column_description");
		if (! columnNodes || columnNodes.length == 0)
			return null;
		
		for (var i = 0; i < columnNodes.length; ++i)
		{
			var operNodes = columnNodes [i].getElementsByTagName ("operation");
			if (operNodes && operNodes.length == 1)
			{
				var oper = this.parseOperation (operNodes [0]);
				if (oper)
				{
					if (oper.isDefault)
						this.m_defaultOper = oper;
					
					itemOpers.push (oper);
				}
			}
		}
		
		return itemOpers;
	},
	
	prepareContextMenu: function (itemOpers, widgetId, widgets)
	{
		var id = widgetId + "_cm";
		
		var items = new Array ();
		for (var i = 0; i < itemOpers.length; ++ i)
		{
			var oper = itemOpers[i];			
			var b = this.getOperationButton (oper, false);
			if (b)
				items.push (b);
		}
		
		var me = this;
		widgets.push ({
			type: "contextmenu",
			id:   id,
			config: {
				target: "#" + widgetId,
				dataSource: items,
                // show when node text is clicked
                filter: ".k-in",
                select: function(e) {
                	e.preventDefault ();
                	me.onContextMenu ($(e.item), $(e.target));
                }
			}
		});
		
		// placeholder for context menu
		return "<ul id='" + id + "'></ul>";
	},
	
	onContextMenu: function (item, node)
	{
		this.getTreeWidget ().select (node);
		
		var text = item.text ();
		for (var i = 0; i < this.m_itemOpers.length; ++ i)
		{
			var oper = this.m_itemOpers[i];
			if (oper.operName == text)
			{
				this.runItemOperation(oper);
				break;
			}
		}
	},
	
	getSelectedRecord: function ()
	{
		var tree = this.getTreeWidget ();
		
		var selNode = tree.select ();
		return (selNode && selNode.length > 0 ? tree.dataItem (selNode) : null);
	},
		
	addReference: function (oper)
	{
		var refOwnerName = this.m_refOwnerName;
		var refAttrName  = this.m_refAttrName;
		var refOwnerId   = this.m_refOwnerId;
		var formName     = this.m_formName;
		var sectionName  = this.m_sectionName;
		
		var selRecord = this.getSelectedRecord ();
		if (selRecord)
		{
			var selRef = getObjectReference (selRecord.id);
			var childRefAttrName = selRecord.get ("bas_childRefAttrName");
			if (childRefAttrName && selRef)
			{
				refOwnerName = selRef.objectName;
				refAttrName  = childRefAttrName;
				refOwnerId   = selRef.objectId;
				formName     = null;
				sectionName  = null;
			}
		}

		var action = new AwareApp_AddReferenceLayoutAction (
							refOwnerName, 
							refAttrName, 
							refOwnerId, 
							formName, 
							sectionName,
							null, 
							oper,
							false,
							this);
		action.run ();
	},
	
	addNew: function ()
	{
		var refOwnerName = this.m_refOwnerName;
		var refAttrName  = this.m_refAttrName;
		var refOwnerId   = this.m_refOwnerId;
		var formName     = this.m_formName;
		var sectionName  = this.m_sectionName;
		var objName      = this.m_queryOnName;
		var isGroupName  = this.m_isGroupName;
		
		var action = new AwareApp_NewReferenceLayoutAction (
							objName,
							isGroupName, 
							refOwnerName, 
							refAttrName, 
							refOwnerId, 
							formName,
							sectionName,
							this);

		action.run ();
	},
	
	deleteAllReferences: function ()
	{
		if (! window.confirm (AwareApp.Locale["C_GridConfDelA"]))
			return;
			
		var refOwnerName = this.m_refOwnerName;
		var refAttrName  = this.m_refAttrName;
		var refOwnerId   = this.m_refOwnerId;
		
		var selRecord = this.getSelectedRecord ();
		if (selRecord)
		{
			var selRef = getObjectReference (selRecord.id);
			var childRefAttrName = selRecord.get ("bas_childRefAttrName");
			if (childRefAttrName && selRef)
			{
				refOwnerName = selRef.objectName;
				refAttrName  = childRefAttrName;
				refOwnerId   = selRef.objectId;
			}
		}

		var action = new AwareApp_DeleteReferencesAction (
							refOwnerName, 
							refOwnerId, 
							refAttrName, 
							null);
		action.run ();
	},
	
	operationApplicable: function (record, operName)
	{
		return isOperationApplicable (record.get ("BAS_OPER_APPLICABILITY"), operName);
	},
	
	runItemOperation: function (operation)
	{
		var selRecord = this.getSelectedRecord ();
		if (! selRecord)
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_TreeNoSel"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return;
		}
		
		var selRef = getObjectReference (selRecord.id);
		if (! selRef)
		{
			console.log ("Invalid selection");
			return;
		}
		
		if (! this.operationApplicable (selRecord, operation.operName))
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_TreeOperApp"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return;
		}
		
		if (operation.operType == "delete_object")
		{
			this.deleteTreeSelection (operation, selRef, selRecord);
		}
		else
		{
			var selection = this.getTreeContext(selRef, operation);
			this.runOperation (selection, operation);
		}
	},
	
	deleteTreeSelection: function (oper, selRef, selRecord)
	{
		if (! window.confirm (AwareApp.Locale["C_GridConfDel2"]))
			return;
		
		var action  = null;
		if (oper.operand && oper.operand == "true")
		{
			action = new AwareApp_DeleteObjectsAction ([ selRef ]);
		}
		else
		{
			// delete reference						
			action = new AwareApp_DeleteReferencesAction (
								selRecord.get ("bas_ownerName"), 
								selRecord.get ("bas_ownerId"),
								selRecord.get ("bas_ownerRefAttrName"),
								[ selRef ]
						 );		
		}
		
		action.run ();
	},
	
	// Overrides parent
	deleteSelection: function (selection)
	{
		var selRecord = this.getSelectedRecord ();
		if (! selRecord)
		{
	        var config = {
                title:  AwareApp.Locale["C_Error"],
                msg:    AwareApp.Locale["C_TreeNoSel"],
                btnOK:  true
            };
            	
     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
			return;
		}
		
		if (! window.confirm (AwareApp.Locale["C_GridConfDel2"]))
			return;

		var selRef = getObjectReference (selRecord.id);
		var action = new AwareApp_DeleteReferencesAction (
						selRecord.get ("bas_ownerName"), 
						selRecord.get ("bas_ownerId"),
						selRecord.get ("bas_ownerRefAttrName"),
						[ selRef ]
				 );		
		action.run ();
	},
	
	getContextForOperation: function (operation)
	{
		var selRecord = this.getSelectedRecord ();
		if (! selRecord)
		{
			return;
		}
		
		var selRef = getObjectReference (selRecord.id);
		if (! selRef)
		{
			console.log ("Invalid selection");
			return;
		}
		
		return this.getTreeContext(selRef, operation);
	},
	
	getTreeContext: function (selRef, operation)
	{
		var ctx = new Array ();
		if (selRef)
			ctx.push ({ objectName: selRef.objectName, objectId: selRef.objectId });
		
		var isDelete = (operation && operation.operType == "delete_object");
		if (this.m_refOwnerName && this.m_refOwnerId && ! isDelete)
			ctx.push ({ objectName: this.m_refOwnerName, objectId: this.m_refOwnerId });
		
		return ctx.length == 0 ? null : ctx;
	},
	
	// called by the action started in startProcessForSelection if process requires parameters which haven't been provided
	procParamsNotProvided: function ()
	{
        var config = {
            title:  AwareApp.Locale["C_Error"],
            msg:    AwareApp.Locale["C_TreeNoSel"],
            btnOK:  true
        };
        	
 		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
	},
	
	getLinksTarget: function (operTarget)
	{
		return this.m_formParent && this.m_formParent.getLinksTarget ? this.m_formParent.getLinksTarget (operTarget) : null;
	}
});
