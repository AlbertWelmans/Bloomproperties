var AwareApp_ChartParser = AwareApp_BaseParser.extend(
{
	strRefresh:   "Refresh the chart",

	init: function (xmlDoc, queryStr, extParams, inWindow)
	{
		AwareApp_BaseParser.call(this, xmlDoc, inWindow);

		this.m_queryStr  = queryStr;
		this.m_extParams = extParams;
	},

	parse: function ()
	{
		var mainNodes = this.m_xmlDoc.getElementsByTagName ("chart_layout");
		if (! mainNodes || mainNodes.length != 1)
			return null;

		var mainNode = mainNodes [0];

		var cdNodes = mainNode.getElementsByTagName ("chart_data");
		if (! cdNodes || cdNodes.length != 1)
			return null;

		var chartNode = cdNodes [0];

		if (! this.m_queryStr)
		{
			var queryStrNodes = getFirstLevelChildNodes (mainNode, "query_string");
			if (! queryStrNodes || queryStrNodes.length == 0)
				return null;

			this.m_queryStr = getTextNodeValue (queryStrNodes [0]);
		}

		this.m_queryName       = getAttributeValue (mainNode, "query_name",     null);
		this.m_queryOnName     = getAttributeValue (mainNode, "query_on_name",  "");
		this.m_refreshProcs    = getAttributeValue (mainNode, "refresh_procs",  null);
		this.m_refreshObjs     = getAttributeValue (mainNode, "refresh_objs",   null);
		this.m_refreshInterval = getIntegerValue   (mainNode, "refresh_interval",   -1);
		this.m_refOwnerName    = getAttributeValue (mainNode, "ref_owner_name", null);
		this.m_refOwnerId      = getAttributeValue (mainNode, "ref_owner_id", null);
		this.m_refAttrName     = getAttributeValue (mainNode, "ref_attr_name", null);
		this.m_formName        = getAttributeValue (mainNode, "form_name",     null);
		this.m_sectionName     = getAttributeValue (mainNode, "section_name",  null);
		this.m_elemId          = getAttributeValue (chartNode, "elem_id",       null);
		this.m_panelWidth      = getIntegerValue   (mainNode, "panel_width",    null);
		var height             = getAttributeValue (mainNode, "panel_height",   null);
		if (height && height == "Align")
			this.m_alignToBottom = true;
		else
			this.m_panelHeight = height;

		if (! this.m_previewMode)
			this.m_previewMode = getBooleanValue   (mainNode, "preview_mode", false);
		
		var rn = mainNode.getElementsByTagName ("resizing_options");
		if (rn && rn.length > 0)
			this.m_resizingNode = rn [0];

		this.m_objectRefNodes  = mainNode.getElementsByTagName ("object_reference");

		var rsn = mainNode.getElementsByTagName ("render_script");
		if (rsn && rsn.length > 0)
		{
			this.m_renderScript = getTextNodeValue (rsn[0]);
		}

		var tn = getFirstLevelChildNodes (mainNode, "tour");
		if (tn && tn.length > 0)
			this.m_tourNode = tn [0];
		
		this.m_attrNames = new Array ();
		var xAttrName = getAttributeValue (chartNode, "x_attr_name", null);
		if (! xAttrName)
			return null;

		this.m_attrNames.push (xAttrName);

		var seriesNodes = chartNode.getElementsByTagName ("chart_series");
		if (! seriesNodes)
			return null;

	    var yAttrNames = new Array ();
		for (var i = 0; i < seriesNodes.length; ++ i)
		{
			var yAttrName = getAttributeValue (seriesNodes [i], "y_attr_name", null);
			if (yAttrName)
			{
				yAttrNames.push (yAttrName);
				this.m_attrNames.push (yAttrName);
			}
		}
		
		this.m_groupAttrName = getAttributeValue (chartNode, "series_group_attr_name", null);
		if (this.m_groupAttrName)
			this.m_attrNames.push (this.m_groupAttrName);

		this.m_widgetId = "AW_CHART_" + Math.floor (Math.random () * 100001);
		
		var filters = this.parseFilterFields (mainNode, this.m_widgetId);
		
		var wc = {
			theme: AwareApp.getTheme ()
		};
		
		var bgndImg = this.parseChart (chartNode, seriesNodes, xAttrName, yAttrNames, wc);
		
		// has to be after parseChart because of this.m_xAxisIsDate and series group attr
		wc.dataSource = this.getDataSourceConfig(mainNode, yAttrNames);
		
		this.setupEvents (mainNode, wc);
		
		var panelConfig = this.getPanelConfig (mainNode, this.m_widgetId, "chart", filters && filters.loc != "header" ? filters : null);	
		panelConfig.borders = (this.m_panelHeader && this.m_panelHeader.caption);
		
		if (bgndImg)
		{
			panelConfig.style = "background: center no-repeat url('" + bgndImg + "')";
		}
		if (filters && filters.loc == "header")
		{
			panelConfig.extraHeaderElems = filters.elems;
		}

		if (this.m_showSaveSettingsButton)
		{
			this.setState (wc);
		}
		
		this.m_panel = new AwareApp_Panel (panelConfig);
		
    	var widgets = new Array ();    	
		var panelMarkup = this.m_panel.generateMarkup (widgets);
		
    	widgets.push ({
    		type:   "chart",
    		id:     this.m_widgetId,
    		config: wc
    	});
		widgets.push ({
			type: "callback",
			callback: function ()
			{
				this.afterRender ();
			},
			scope: this
		});
		
		if (filters)
		{
			for (var i = 0; i < filters.widgets.length; ++ i)
				widgets.push (filters.widgets[i]);
		}
   	
		if (this.m_resizingNode)
		{
			this.addResizeWidgets (this.m_resizingNode, panelMarkup, widgets);
		}
		
		this.m_widgetInfo = {
          	markupId:     this.m_widgetId,
          	wrapperId:    panelMarkup.id,
        	markup:       panelMarkup.html,
        	kendoWidgets: widgets,
        	parser:       this,
        	title:        this.getPanelHeaderTitle (),
        	icon:         this.getPanelHeaderIcon (),
        	iconCls:      this.getPanelHeaderIconCls ()
        };

		this.runInitScript (mainNode, wc, widgets, panelMarkup.html);
		
		this.setupAutoRefresh ();
		
		this.registerListeners ();

        return this.m_widgetInfo;        
	},
	
	getWidget: function ()
	{
		return $("#" + this.m_widgetId).data("kendoChart");		
	},
	
	setupEvents: function (mainNode, wc)
	{
		var operNode  = null, me = this;
		var ioNodes = getFirstLevelChildNodes (mainNode, "item_operations");
		if (ioNodes && ioNodes.length > 0)
		{
			var operNodes = ioNodes [0].getElementsByTagName ("operation");
			if (operNodes && operNodes.length == 1)
				operNode = operNodes [0];
	
			if (operNode && wc.series)
			{
				wc.seriesClick = function (e) {
					me.executeOperation (e.dataItem, operNode);				
				};
			}
		}
	},
	
	registerListeners: function ()
	{
	    AwareApp.registerListener ("formSaved",         this);
		AwareApp.registerListener ("objectUpdated", this);
	    AwareApp.registerListener ("processFinished",   this);
	    AwareApp.registerListener ("objectsDeleted",    this);
	},

	beforeDestroy: function ()
	{
		AwareApp.deregisterListener ("formSaved",         this);
		AwareApp.deregisterListener ("objectUpdated",     this);
		AwareApp.deregisterListener ("processFinished",   this);
		AwareApp.deregisterListener ("objectsDeleted",    this);
		
		AwareApp_BaseParser.fn.beforeDestroy.call (this);
	},
	
	getDataSourceConfig: function (mainNode, yAttrNames)
	{
		var fields = {};
		
        fields ["BAS_REF_VALUE"] =          { field: "BAS_REF_VALUE/text()" };
        fields ["BAS_OPER_APPLICABILITY"] = { field: "BAS_OPER_APPLICABILITY/text()" };
        
        if (this.m_attrNames)
        {
        	for (var i = 0; i < this.m_attrNames.length; ++ i)
        	{
        		var attrName = this.m_attrNames[i];
        		fields [attrName] = { field: attrName + "/text()" };
        		
        		if (i == 0)
        		{
        			// XAttrName
        			if (this.m_xAxisIsDate)
        			{
        				// Need to convert to date
        				var format = (this.m_xAxisIsDate.dataType == "date_time" ? "dd/MM/yyyy HH:mm" : "dd/MM/yyyy");  // server format
        				fields[attrName].type = "date";
        				fields[attrName].parse = function (v) {
							return kendo.parseDate (v, format);  
						};
        			}
        		}
        		else
        		{
	        		for (var j = 0; j < yAttrNames.length; ++ j)
	        		{
						if (yAttrNames[j] == attrName)
						{
							fields[attrName].type = "number";
							break;
						}
					}
        		}
        	}
        }
         
		if (this.m_previewMode)
		{
			return this.getPreviewStore (mainNode, fields);
		}
		
		var me = this;
		var t  =  AwareApp.createAwareTransport (this.getChartParams ());
		t.parameterMap = function (data, type)
		{
			return me.encodeDataSourceData (data, type);
		};
		
		var c = {
			transport:  t,
            schema: {
            	type:  "xml",
            	data:  "/root/get_chart_data_action_return/dataset/row",
            	model: {
            		id:     "BAS_REF_VALUE",
            		fields: fields
            	},
                errors : "/get_chart_data_action_return/failure/text()",
	            parse: function (response)
	            {
	            	me.preprocessResponse (response);
	            	return response;
	            }
           },
           serverPaging:    true,
           serverFiltering: true,
           serverSorting:   true,
           serverGrouping:  false,
           error: function (e)
           {
            	alert (e.errors ? e.errors : e.errorThrown);
           }
		};
		
		if (this.m_groupAttrName)
			c.group = this.m_groupAttrName;
		
		return c;
	},
	
	getChartParams: function ()
	{
		var params = {
			actionType: 'get_chart_data_action'
		};
		if (this.m_queryStr)
		{
			params.query_string = this.m_queryStr;
		}
		if (this.m_objectRefNodes && this.m_objectRefNodes.length > 0)
		{
			params.query_context = buildQueryContextString (this.m_objectRefNodes);
		}
		if (this.m_refAttrName)
		{
			params.ref_attr_name      = this.m_refAttrName;
			params.ref_owner_name     = this.m_refOwnerName;
			params.ref_owner_id       = this.m_refOwnerId;
			params.form_name          = this.m_formName;
			params.section_name       = this.m_sectionName;
		}
		else
		{
			params.query_name = this.m_queryName;
		}
		return params;
	},

	encodeDataSourceData: function (data, operType)
	{
		var map = {};
		for (var param in data)
		{
			map [param] = data[param];
		} 
		
		// add filters
		this.addFiltersToParams (map);
		
		if (this.m_inRefresh)
			map ["in_refresh"] = true;
		
		return map;
	},
	
	preprocessResponse: function (doc)
	{
		// look for a new query string and summary
		var qsNodes = doc.getElementsByTagName ("query_string");
		if (qsNodes && qsNodes.length > 0)
		{
			this.setQueryString (getTextNodeValue (qsNodes [0]));
		}
		
		AwareApp_BaseParser.fn.preprocessResponse.call (this, doc);
	},
	
	getKeyForState: function ()
	{
		var key =  this.m_refAttrName ?
		           AwareApp.STATE_PREFIX + "R" + "@" + this.m_refOwnerName + "@" + this.m_refAttrName + "@" + this.m_formName + "@" + this.m_sectionName :
		           AwareApp.STATE_PREFIX + "Q" + "@" + this.m_queryName;

		// size has to be less than the length in the database
		return key.length <= 240 ? key : key.substring (0, 240);
	},

	getTourElementSelector: function (sectionId)
	{
		var tourElem = this.m_tourElements [sectionId];
		if (! tourElem)
			return null;
		
		if (tourElem.type == "oper" || tourElem.type == "filter")	
		{
			return "#" + tourElem.id;
		}
		
		return null;
	},	
	
	afterRender: function ()
	{
      	var chart = this.getWidget ();
        
		if (this.m_renderScript)
		{
			var widget = chart;
			var parser = this;

			try
			{
				eval (this.m_renderScript);
			}
			catch (e)
			{
				console.log ("Exception running render script for chart " + this.getQueryName () + " " + e);
			}
		}
		
		if (this.m_alignToBottom)
		{
			this.alignToBottom ();
		}
		else if (! this.m_panelHeight)
		{
			this.resizeToEnclosing ();
		}
	},
	
	resizeToEnclosing: function ()
	{
		var p = this.getResizeToEnclosingPanel ();
		if (p)
		{
			var w = this.getWidget ();
			var ep = p.panel;
			var wrapperEl = $("#" + this.m_widgetInfo.wrapperId),
				dataArea = w.element;

			// for some reason calculations are 3 pixels off
			dataArea.height(dataArea.innerHeight () + ep.innerHeight() - wrapperEl.innerHeight() - 3);
			w.resize ();
		}
	},
	
	doAlignToBottom: function (params)
	{
		// Align to the bottom of the screen determined by the edge of the enclosing frame
		var frame = $("#" + params.frameId);
		if (frame && frame.length > 0)
		{
			var w = this.getWidget ();
			var dataArea = w.element;
			
			dataArea.height (frame.offset ().top + frame.innerHeight() - dataArea.offset().top - params.margin);
			
			w.resize ();
		}	
	},
	
	getElementId: function ()
	{
		return this.m_elemId;
	},

	saveChart: function (callback)
	{
	    this.getWidget ().exportImage().done(function(data) {
	    	callback (data);
	    });
	},

	parseChart: function (chartNode, seriesNodes, xAttrName, yAttrNames, config)
	{
		var type = getAttributeValue (chartNode, "type", "column");
		
		var title = getAttributeValue (chartNode, "chart_title", null);
		if (title)
		{
			config.title = {
				text:     title,
				position: getAttributeValue (chartNode, "title_position", "top"),
				align:    getAttributeValue (chartNode, "title_alignment", "center")
			};
			
			var tfNodes = chartNode.getElementsByTagName ("chart_title_font");
			if (tfNodes && tfNodes.length > 0)
			{
				var fontNodes = tfNodes[0].getElementsByTagName ("font_info");
				if (fontNodes && fontNodes.length > 0)
				{
					var fontConfig = this.getFontConfig (fontNodes [0]);
					config.title.font   = fontConfig.font;
					config.title.color  = fontConfig.color;
				}				
			}
		}
		
		config.chartArea = {};
		if (this.m_panelWidth)
			config.chartArea.width = this.m_panelWidth;
		if (this.m_panelHeight)
			config.chartArea.height = parseInt (this.m_panelHeight);
		
		var pt = getIntegerValue (chartNode, "padding_top", null);
		var pb = getIntegerValue (chartNode, "padding_bottom", null);
		var pl = getIntegerValue (chartNode, "padding_left", null);
		var pr = getIntegerValue (chartNode, "padding_right", null);

		config.chartArea.margin = {
			top:    (pt ? pt : 5),
			bottom: (pb ? pb : 5),
			left:   (pl ? pl : 5),
			right:  (pr ? pr : 5)
		};

		var bgndImage = null;
		var bgndColor = getAttributeValue (chartNode, "bgnd_color", null);
		if (bgndColor)
		{
			config.chartArea.background = this.toColorCode(bgndColor);
		}
		else
		{
			bgndImage = getAttributeValue (chartNode, "bgnd_image", null);
		}

		var borderColor = getAttributeValue (chartNode, "border_color", null);
		if (borderColor)
			config.chartArea.border = { color: this.toColorCode (borderColor), width: 1 };
		
		var bgndOpacity = getAttributeValue (chartNode, "bgnd_opacity", null);
		if (bgndOpacity)
			config.chartArea.opacity = parseFloat (bgndOpacity);
		
		var panZoom = getBooleanValue (chartNode, "pan_zoom", false);
		if (panZoom)
		{
            config.pannable = {
                lock: "y"
            };
            config.zoomable = {
                mousewheel: {
                    lock: "y"
                },
                selection: {
                    lock: "y"
                }
            };
		}

		var tipConfig = this.getTipConfig (chartNode, xAttrName, type);
		if (tipConfig)
			config.tooltip = tipConfig;

		if (type == "pie")
		{
			// doesn't have axis and only one series
			this.parsePieChart (config, chartNode, xAttrName, yAttrNames, seriesNodes);
		}
		else
		{
			config.categoryAxis = {
				field: xAttrName
			};
			config.valueAxis = {};
			
			var xAxisNodes = chartNode.getElementsByTagName ("x_axis");
			if (xAxisNodes && xAxisNodes.length > 0)
			{
				this.applyAxisConfig (config.categoryAxis, xAxisNodes [0], type, true);				
			}

			var yAxisNodes = chartNode.getElementsByTagName ("y_axis");
			if (yAxisNodes && yAxisNodes.length > 0)
			{
				this.applyAxisConfig (config.valueAxis, yAxisNodes [0], type, false);
			}
			
			config.series = this.getSeries (seriesNodes, xAttrName, config);
		}

		var legend = this.getLegendConfig (chartNode);
		if (legend)
			config.legend = legend;

		return bgndImage;
	},
	
	parsePieChart: function (cConfig, chartNode, xAttrName, yAttrNames, seriesNodes)
	{
		var colors = this.getColorArray (seriesNodes);
		// We will map category values to indices in the color array
		var colorMapping = {
			bas_lastIdx: 0
		};
		
		var sNode = (seriesNodes && seriesNodes.length > 0 ? seriesNodes[0] : null);
		var sConfig = {
			type:          "pie",
			field:         yAttrNames[0],
			categoryField: xAttrName,
			color: function (item) {
				var idx = colorMapping [item.category];
				if (! idx)
				{
					idx = colorMapping.bas_lastIdx++;
					colorMapping [item.category] = idx;
				}
				
				return colors[idx];
			}
		};

		if (sNode)
		{
			var hc = this.getHighlightConfig (sNode);
			if (hc)
				sConfig.highlight = hc;
			
			var labelConfig = this.getLabelConfig (sNode, xAttrName);
			if (labelConfig)
			{
				sConfig.labels = labelConfig;
			}
		}

		cConfig.series = [sConfig];
	},
	
	getSeries: function (seriesNodes, xAttrName, chartConfig)
	{
		var series = new Array ();
		for (var i = 0; i < seriesNodes.length; ++ i)
		{
			var sn = seriesNodes [i];
			var type = getAttributeValue (sn, "type", "column");			
			if (type == "column")
			{
				var flipXY = getBooleanValue (sn, "flip_xy", false);
				if (flipXY)
					type = "bar";
			}
			else if (type == "radar")
			{
				var fill = getBooleanValue (sn, "fill_area", false);
				type = (fill ? "radarArea" : "radarLine");
			}

			var yField = getAttributeValue (sn, "y_attr_name", null);
			var name   = getAttributeValue (sn, "name", "Series " + (i + 1));
			var s = {
				field: yField,
				name:  name,
				type:  type
			};
			
			var yAttrFormat = getAttributeValue (sn, "y_attr_format", null);
			if (yAttrFormat)
			{
				if (! this.m_seriesFormats)
					this.m_seriesFormats = {};
				
				this.m_seriesFormats [name] = yAttrFormat;
			}
			
			var aggregate = getAttributeValue (sn, "aggregate", null);
			if (aggregate)
			{
				s.categoryField = xAttrName;
				s.aggregate = aggregate;
			}
			
			var color = null;
			var c = getAttributeValue (sn, "color", null);
			if (c)
			{
				s.color = this.toColorCode (c);
			}

			/* Only seems to be supported for pie
			var highlightConfig = this.getHighlightConfig (seriesNodes[i]);
			*/

			var labelConfig = this.getLabelConfig (sn);
			if (labelConfig)
			{
				s.labels = labelConfig;
			}
			
			var opacity = getAttributeValue (sn, "opacity", null);
			if (opacity)
			{
				s.opacity = parseFloat(opacity);
			}
			
			var stacked = getBooleanValue (sn, "stacked", false);
			if (stacked)
			{
				s.stack = true;
			}
			
			this.setSeriesSpecific (s, sn, chartConfig);
			
			series.push (s);
		}

		return series;
	},

	setSeriesSpecific: function (s, seriesNode, chartConfig)
	{
		if (s.type == "line" || s.type.indexOf ("radar") == 0)
		{
			var smooth = getBooleanValue (seriesNode, "smooth", false);
			if (smooth)
				s.style = "smooth";

			var m = getBooleanValue (seriesNode, "show_markers", true);
			s.markers = { visible: m };

			var dash = getBooleanValue (seriesNode, "dash", false);
			if (dash)
			{
				s.dashType = "longDash";
			}

			var w = getAttributeValue (seriesNode, "line_width", null);
			if (w)
			{
				s.width = parseFloat (w);
			}
		}
		else if (s.type == "bar" || s.type == "column")
		{
			var gap = getAttributeValue (seriesNode, "min_value", null);
			if (gap)
			{
				var g = parseFloat (gap);
				if (g > 0 && g < 100)
					s.gap = g;
			}
			
			var spacing = getAttributeValue (seriesNode, "max_value", null);
			if (spacing)
			{
				var g = parseFloat (spacing);
				if (g > 0 && g < 100)
					s.spacing = g;
			}
		}
	},

	toColorCode: function (color)
	{
		var c = color;
		if (c.indexOf ("#") != 0)
			c = "#" + c;

		return c;
	},

	getColorArray: function (seriesNodes)
	{
		if (! seriesNodes || seriesNodes.length == 0)
			return null;

		var results = new Array ();
		for (var i = 0; i < seriesNodes.length; ++ i)
		{
			var c = getAttributeValue (seriesNodes [i], "color", null);
			if (c)
			{
				results.push (this.toColorCode(c));
			}
		}

		return results;
	},

	getHighlightConfig: function (seriesNode)
	{
		var hn = seriesNode.getElementsByTagName ("highlight_info");
		if (! hn || hn.length == 0)
			return null;

		var c = {};
		var fc = getAttributeValue (hn[0], "fill_color", null);
		if (fc)
		{
			c.color   = this.toColorCode (fc);
			c.opacity = 1;
		}

		var bc = getAttributeValue (hn[0], "border_color", null);
		if (bc)
			c.border = { color: this.toColorCode (bc), opacity: 1, width: 2 };

		return c;
	},
	
	getLabelConfig: function (seriesNode)
	{
		var labelNodes = seriesNode.getElementsByTagName ("label_info");
		if (! labelNodes || labelNodes.length == 0)
			return null;

		var labelNode = labelNodes [0];

		var pos = getAttributeValue (labelNode, "position", "none");
		var labelConfig = {
			visible: (pos != "none")
		};
		if (pos != "none")
			labelConfig.position = pos;

		var yAttrFormat = getAttributeValue (seriesNode, "y_attr_format", null);
		if (yAttrFormat)
		{
			labelConfig.format = "{0:" + yAttrFormat + "}";
		}
		
		var fontNodes = labelNode.getElementsByTagName ("font_info");
		if (fontNodes && fontNodes.length > 0)
		{
			var fontConfig = this.getFontConfig (fontNodes [0]);
			labelConfig.font   = fontConfig.font;
			labelConfig.color  = fontConfig.color;
		}

		return labelConfig;
	},

	getFontConfig: function (fontNode)
	{
		var name = getAttributeValue (fontNode, "name", null);
		var size = getIntegerValue   (fontNode, "size", null);

		var color = getAttributeValue (fontNode, "color", null);

		var bold      = getBooleanValue (fontNode, "bold", false);
		var italic    = getBooleanValue (fontNode, "italic", false);
		var underline = getBooleanValue (fontNode, "underline", false);

		// CSS string
		var fontStr = null;
		if (name != null && size != null)
			fontStr = size + "px " + name;
		if (bold)
			fontStr = "bold " + fontStr;
		if (underline)
			fontStr = "underline " + fontStr;
		if (italic)
			fontStr = "italic " + fontStr;

		return { font: fontStr, color: this.toColorCode(color) };
	},

	getLegendConfig: function (chartNode)
	{
		var legendNodes = chartNode.getElementsByTagName ("legend");
		if (! legendNodes || legendNodes.length == 0)
			return { visible: false };

		var legendNode = legendNodes [0];
		var c = {};
		c.position = getAttributeValue (legendNode, "position", "bottom");
		var p = getIntegerValue (legendNode, "padding", -1);
		if (p >= 0)
			c.padding = p;
		
		return c;
	},
	
	getTipConfig: function (chartNode, xAttrName, chartType)
	{
		var c = { visible: false };
		var tipNodes = chartNode.getElementsByTagName ("data_tip");
		if (tipNodes && tipNodes.length > 0)
		{	
			var tipNode = tipNodes [0];
			var msg = getAttributeValue (tipNode, "msg", null);
			if (msg)
			{
				c.visible = true;
				
				var me = this;
				c.template = function (item)
				{
					return me.getTipToRender (item.dataItem, msg, item.category, item.value, item.series.name, chartType, xAttrName);
				}
			}
		}

		return c;
	},

	applyAxisConfig: function (axisConfig, axisNode, chartType, isXAxis)
	{
		var dataType = getAttributeValue (axisNode, "data_type", null);
		var format   = getAttributeValue (axisNode, "format", null);
		
		if (isXAxis)
		{
			var baseUnit = getAttributeValue (axisNode, "base_unit", null);
			if (baseUnit)
			{
				axisConfig.type = "date";
				axisConfig.baseUnit = baseUnit;
				this.m_xAxisIsDate = { dataType: dataType, format: format };
			}
		}
		
		axisConfig.minorGridLines = { visible: false };
		var showGrid = getBooleanValue (axisNode, "show_gridlines", true);
		if (showGrid)
		{
			axisConfig.majorGridLines = { visible: true };
			
			var gColor = getAttributeValue (axisNode, "grid_color", null);
			if (gColor)
			{
				axisConfig.majorGridLines.color = this.toColorCode(gColor);
			}
		}
		else
		{
			axisConfig.majorGridLines = { visible: false };
		}

		var visible = getBooleanValue (axisNode, "visible", true);
		if (! visible)
		{
			axisConfig.visible = false;
		}
		else
		{
			var title = getAttributeValue (axisNode, "label", null);
			if (title)
			{
				axisConfig.title = { text: title };
				
				var tfn = axisNode.getElementsByTagName ("tick_font");
				if (tfn && tfn.length > 0)
				{
					var fontNodes = tfn[0].getElementsByTagName ("font_info");
					if (fontNodes && fontNodes.length > 0)
					{
						var fc = this.getFontConfig (fontNodes [0]);
						if (fc && fc.font)
							axisConfig.title.font = fc.font;
						if (fc && fc.color)
							axisConfig.title.color = fc.color;
					}
				}
			}
	
			var min = getAttributeValue (axisNode, "minimum", null);
			if (min)
				axisConfig.min = parseFloat (min);
	
			var max = getAttributeValue (axisNode, "maximum", null);
			if (max)
				axisConfig.max = parseFloat (max);
	
			var ticks = getIntegerValue (axisNode, "ticks", -1);
			if (ticks > 0)
				axisConfig.majorTicks = { step: ticks };
			
			var showLabels = getBooleanValue (axisNode, "show_labels", true);
			if (showLabels)
			{
				axisConfig.labels = { visible: true };

				var angle = getIntegerValue (axisNode, "label_angle", 0);
				if (angle != 0)
				{
					axisConfig.labels.rotation = { angle: angle };
				}

				var lfn = axisNode.getElementsByTagName ("label_font");
				if (lfn && lfn.length > 0)
				{
					var fontNodes = lfn[0].getElementsByTagName ("font_info");
					if (fontNodes && fontNodes.length > 0)
					{
						var fc = this.getFontConfig (fontNodes [0]);
						if (fc && fc.font)
							axisConfig.labels.font = fc.font;
						if (fc && fc.color)
							axisConfig.labels.color = fc.color;
					}
				}
			}
			else
			{
				axisConfig.labels = { visible : false };
			}

			if (chartType.indexOf ("radar") != 0)
			{
				if (dataType == "number")
				{
					if (format)
					{
						axisConfig.labels.format = "{0:" + format + "}";
					}
				}
				else if (dataType == "date" || dataType == "date_time")
				{
					if (format)
					{
						format = toKendoDateFormat (format);
						// At the moment field type is string, not date, (unless this.m_xAxisIsDate) so we need to do the conversion ourselves
						axisConfig.labels.template = function (item) {
							// Server returns dates in a particular format
							var d = item.value;
							if (! (d instanceof Date))
								d = kendo.parseDate (item.value, (dataType == "date" ? "dd/MM/yyyy" : "dd/MM/yyyy HH:mm"));
							return kendo.toString (d, format);
						}
					}
				}
			}
		}
	},
	
	executeOperation: function (record, operNode)
	{
		var oper = this.parseOperation (operNode, false);
		if (oper)
		{
			if (record && ! operationApplicable (record, oper.operName))
			{
		        var config = {
	                title:  AwareApp.Locale["C_Error"],
	                msg:    AwareApp.Locale["C_SchedOperApplicable"],
	                btnOK:  true
	            };
	            	
	     		$.when(AwareApp_MessageBox.show(config)).then(function(b){});
				return;
			}
			
			var selection = (record ? [ getObjectReference (record.id) ] : null);
			this.runOperation (selection, oper);
		}
	},

	handleEvent: function (eventName, eventInfo)
	{
		if (eventName == "processFinished")
		{
			if (containedInDelimitedString (eventInfo.processName, this.m_refreshProcs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "formSaved" || eventName == "objectUpdated")
		{
			if (containedInDelimitedString (eventInfo.objectName, this.m_refreshObjs))
			{
				this.refreshData ();
			}
		}
		else if (eventName == "objectsDeleted")
		{
			this.refreshData ();
		}
	},

	// Called by the framework to compare whether the given parser represents the same tab info as our parser
	representsSameTab: function (parser)
	{
		return parser instanceof AwareApp_ChartParser && this.m_queryName && parser.m_queryName == this.m_queryName;
	},
	
	getTipToRender: function (record, msg, xValue, yValue, seriesName, chartType, xAttrName)
	{
		var inTag = false, curTag = null, msgDisp = "";
		for (var i = 0; i < msg.length; ++ i)
		{
			if (msg[i] == "{")
			{
				inTag = true;
			}
			else if (inTag)
			{
				if (msg[i] == "}")
				{
					if (curTag)
					{
						var tagValue = this.getTagValue (record, curTag, xValue, yValue, seriesName, chartType, xAttrName);
						msgDisp += tagValue;
					}

					inTag = false;
					curTag = null;
				}
				else
				{
					if (! curTag)
						curTag = "";
					curTag += msg[i];
				}
			}
			else
			{
				msgDisp += msg [i];
			}
		}

		return msgDisp;
	},

	getTagValue: function (record, curTag, xValue, yValue, seriesName, chartType, xAttrName)
	{
		if (curTag == "SeriesName")
			return seriesName;

		if (curTag == "XValue")
		{
			// for some reason for donuts we have to take it from record
			if (chartType == "donut" && xAttrName)
				return record.get (xAttrName);
			
			if (this.m_xAxisIsDate)
				xValue = kendo.toString (xValue, this.m_xAxisIsDate.format ? this.m_xAxisIsDate.format : "MM/dd/yyyy");
			
			return xValue;
		}

		if (curTag == "YValue")
		{
			var format = (seriesName && this.m_seriesFormats ? this.m_seriesFormats[seriesName] : null);
			return format ? kendo.toString (yValue, format) : yValue;
		}

		return record.get (curTag);
	}
});
