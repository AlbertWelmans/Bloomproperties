MobileNative = {
	cameraSnapGet: function (objectName, objectId, attrName, props, isSnap, successCallback, errorCallback)
	{
		var me = this;
		var options = { 
		    	destinationType:    Camera.DestinationType.FILE_URI,
		    	correctOrientation: true,
		    	sourceType: (isSnap ? Camera.PictureSourceType.CAMERA : Camera.PictureSourceType.PHOTOLIBRARY)
		};
		
		if (props)
		{
			for (var key in props)
			{
				var v = this.convertCameraPropertyValue (key, props[key]);
				if (v)
					options[key] = v;
			}
		}
		
		navigator.camera.getPicture(
			function (fileURI) {
				me.uploadImage (fileURI, objectName, objectId, attrName, successCallback, errorCallback);
			}, 
			function (msg) {
				alert (msg);
				errorCallback ();
			}, 
			options
		);
	},
	
	convertCameraPropertyValue: function (key, value)
	{
		if (key == "destinationType" || key == "sourceType")
			return null;
			
		if (key == "allowEdit" || key == "correctOrientation" || key == "saveToPhotoAlbum")
			return value == "true" ? true : false;
			
		if (key == "quality" || 
			key == "encodingType" || 
			key == "targetWidth" || 
			key == "targetHeight" || 
			key == "cameraDirection" ||
			key == "mediaType")
		{
			return parseInt (value);
		}
			
		return value;
	},
		
	uploadImage: function (fileURI, objectName, objectId, attrName, successCallback, errorCallback) 
	{
		// use file transfer plugin to upload image to the server
		
		var options = new FileUploadOptions();
		options.fileName = fileURI.substr(fileURI.lastIndexOf('/') + 1);
		
		options.params = {
			object_name: objectName,
			object_id:   objectId,
			attr_name:   attrName
		};
		
		var ft = new FileTransfer();
		ft.upload(fileURI, 
				  encodeURI(AwareApp.m_serverUrl + "uploadRequest.awdu"), 
				  function (r) {
		    			//console.log("Code = " + r.responseCode);
		    			// console.log("Response = " + r.response);
		    			// console.log("Sent = " + r.bytesSent);
		    			navigator.camera.cleanup ();
		    			successCallback ();
				  }, 
				  function error() {
						alert("An error has occurred: Code = " + error.code);
		    			//console.log("upload error source " + error.source);
		    			//console.log("upload error target " + error.target);
		    			navigator.camera.cleanup ();
		    			errorCallback();
				  }, 
				  options);
	},
	
	subscribeToPushNotif: function (senderId)
	{
		var push = PushNotification.init({
		    android: {
		        senderID: senderId
		    },
		    ios: {
		        alert: "true",
		        badge: true,
		        sound: "true"
		    },
		    windows: {}
		});
		
		push.on('registration', function(data) {
		    var a = new AwareApp_MobilePNRegistrationAction(data.registrationId);
		    a.run ();
		});	
				
		push.on('notification', function(data) {
			// this is called if an app is in the foreground
			/* See the details here: https://github.com/phonegap/phonegap-plugin-push/blob/master/docs/API.md */
			if (data.message)
				alert (data.message);
			else
				alert (data.title);
		/*
		    console.log(data.count);
		    console.log(data.sound);
		    console.log(data.image);
		    console.log(data.additionalData);
		*/
		});
	}	
};

var MobileNative_LoginAction = kendo.Class.extend({
	
	init: function (userName, password, domain, remember, serverURL)
	{
		this.m_userName  = userName;
		this.m_password  = password;
		this.m_domain    = domain;
		this.m_remember  = remember;
		this.m_serverURL = serverURL;
	},

    buildRequest: function ()
    {
    	var s = "<mobile_native_login";
    	if (this.m_userName)
    	{
    		s += " userName=\"";
    		s += this.m_userName;
    		s += "\"";
    	}
    	if (this.m_password)
    	{
    		s += " password=\"";
    		s += this.m_password;
    		s += "\"";
    	}
    	s += " domain=\"";
    	s += this.m_domain;
    	s += "\" remember=\"";
    	s += (this.m_remember ? "true" : "false");
    	s += "\" />";
    	
    	return s;
    },
    
    handleServerResponse: function (xmlDoc)
    {
    	var rNodes = xmlDoc.getElementsByTagName ("response");
    	if (! rNodes || rNodes.length == 0)
    	{
    		alert ("Invalid format of response: no root node");
    	}
    	else
    	{
    		var rtl = getBooleanValue (rNodes[0], "rtl", false);
    	
    		var lrNodes = rNodes[0].getElementsByTagName ("login_response");
	    	if (! lrNodes || lrNodes.length == 0)
	    	{
	    		alert ("Invalid format of response");
	    	}
	    	
	    	var xml = getTextNodeValue (lrNodes[0]);
	    	
	    	// save it in local storage
		 	try
			{
				localStorage.setItem ("AwareIMLoginXML", xml);
				localStorage.setItem ("AwareIMServerURL", this.m_serverURL);
			}
			catch (e)
			{
				alert ("This device must support local storage");
			}
			
			// go to startup page
			if (rtl)
				window.location = "startupMobileNativeRTL.html";
			else
				window.location = "startupMobileNative.html";
    	}
    },
    
    handleXMLResponse: function (xmlDoc)
    {
    	var failureNodes = xmlDoc.getElementsByTagName ("failure");
    	if (failureNodes && failureNodes.length == 1)
    	{
    		// failure
    		var msg = getTextNodeValue (failureNodes [0]);
			alert (msg);
    	}
		else
		{    		
    		this.handleServerResponse (xmlDoc);
    	}
    },
    
    run : function ()
    {
    	var xmlStr = this.buildRequest ();
        var h = {};
        h ["Content-Type"] = "application/x-www-form-urlencoded; charset=UTF-8";
        
		kendo.ui.progress ($(document.body), true);
		
        var me = this;
        $.ajax ({
        	 url:    this.m_serverURL + 'request.awmn',
             method: 'POST',
             data:    xmlStr,
             headers: h,           	
             success: function (xmlDoc, status, response){
            	 me.success (xmlDoc);
             },
             error: function (response, status, error){
        		me.failure (response, status);
             },
             timeout: 3600000
       });
    },

    success : function (xmlDoc)
    {
		kendo.ui.progress ($(document.body), false);
			
        this.handleXMLResponse (xmlDoc);
    },

    // default connection failure
    failure : function (response, status)
    {
		kendo.ui.progress ($(document.body), false);
			
 		alert ("Connection failure. Status:" + status); 
    }
});
